import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';

@Component({
  selector: 'app-diarywishlist',
  templateUrl: './diarywishlist.page.html',
  styleUrls: ['./diarywishlist.page.scss'],
  providers:[Idle]
})
export class DiarywishlistPage implements OnInit {
  dataresp: any = [];
  data: any = {};
  data1: any = {};
  dataloan: any = [];
  dataresp1: any = [];
  showUpdatePage: boolean = false;
  custID: any;
  FiYear: any;
  relativeList: any;
  customerType: any;
  ccid: any;
  userType: any;
  idleState: string;
  constructor(private apiService: ApiServiceService,private router: Router, 
    private alertService: AlertServiceService,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    this. userType = window.localStorage['userType'];
    this.getAssignedlist();
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
 
  getAssignedlist() {
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    if (this.data.customerid == undefined) {
      var custID = 0;
      this.custID = 0;
    } else {
      custID = this.data.customerid;
      this.custID = this.data.customerid;
    }
    this.apiService.getassignedGridWishlist(userid, branchid, userType).then(response => {
      var res = JSON.stringify(response.data);
      debugger
      res = JSON.parse(res);
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      this.dataresp = res['Table'];
      this.dataresp1 = res['Table'];
      console.log(this.dataresp)
    });

  }
  getCustomer(){
    // console.log($scope.data.mobile);
    // console.log($scope.dataresp);
    if(this.data.mobile != undefined && this.data.mobile !=''){
    var filterdata = [];
    this.dataresp.forEach(element => {
      console.log(this.data.mobile);
      if(element.Mobile==this.data.mobile){
         filterdata.push(element);
         console.log(filterdata);
         this.dataresp = filterdata;
      }
    });
    if(filterdata.length == 0) this.dataresp = [];
  }else{
   this.getAssignedlist();
  }
  }
  filteredwishlist() {
    console.log(this.data.mobile);
    console.log(this.dataresp);
    if (this.data.mobile != undefined && this.data.mobile != '') {
      var filterdata = [];
      this.dataresp1.forEach(element => {
        console.log(this.data.mobile);
        if (element.Mobile == this.data.mobile) {
          filterdata.push(element);
          console.log(filterdata);
          this.dataresp = filterdata;
        }
      });
      if (filterdata.length == 0) this.dataresp = [];
    } else {
      this.getAssignedlist();
    }
  }
  RNPartAModel(item) {
    console.log(item);
    debugger
    this.ccid =item?.CCID
    this.showUpdatePage = true;
    this.data1.mobileNo = "N";
    this.data1.emailId = "N";
    this.data1.panNo = "N";
    this.data1.netBanking = "N";
    this.data1.mobileBanking = "N";
    this.data1.debit = "N";
    this.data1.aadhar = "N";
    this.data1.gas = "N";
    this.data1.creditCard = "N";
    this.data1.mutual = "N";
    this.data1.insur = "N";
    this.data1.health = "N";
    this.data1.group = "N";
    this.data1.pos = "N";
    this.data1.bharat = "N";
    this.data1.fastag = "N";
    this.data1.gold = "N";
    this.data1.demat = "N";
    this.data1.asba = "N";
    this.data1.fd = "N";
    this.data1.locker = "N";
    this.getloan();
  }
  getloan() {
    this.apiService.getloan().then(response => {
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      this.dataloan = res;
      debugger
    })
  }
  goToMyplannerPage() {
    if(this.userType=='14'){
      this.router.navigateByUrl('/regionsummary')
    }else if(this.userType=='17'){
    
        this.router.navigateByUrl('/newsummary');
      }else{
        this.router.navigateByUrl('/myplanner');
      }

    // this.router.navigateByUrl('/myplanner');
  }

  calendarEntrySave() {
    // this.showspin();
    // this.updateScreen = false;
    console.log(this.custID);
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    var CustomerID = this.custID;
    if (this.data.facility == undefined) {
      var loanreq = 'N';
      var loantype = null;
    } else {
      var loanreq = 'Y';
      var loantype = this.data.facility;
    }
    if (this.data.amount == undefined) {
      var loanamount = 0;
    } else {
      loanamount = this.data.amount;
    }

    if (this.data.remarks == undefined) {
      var remarks = null;
    } else {
      var remarks = this.data.remarks;
    }
debugger
    if (this.data.diarygiven == undefined || this.data.diarygiven == "") {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the No of Diary Given");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Diary Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var diarygiven = this.data.diarygiven;
    }
    debugger
    if (this.data.mangementBroch == undefined) {
      // this.hidespin();
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Diary Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // return false;
      var managementbrochure = 'N';
    } else {
      var managementbrochure = 'Y';
    }
    debugger
    if (this.data.calendargiven == undefined || this.data.calendargiven == "") {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the No of Calendar Given");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Calendar Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var calendargiven = this.data.calendargiven;
    }
    debugger
    if (this.data.paymentBroch == undefined) {
      // this.hidespin();
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Diary Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // return false;
      var paymentBrochure = 'N';
    } else {
      var paymentBrochure = 'Y';
    }

    if (this.data.CustFeedback == undefined || this.data.CustFeedback == "") {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Remarks");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Remarks</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var CustFeedback = this.data.CustFeedback;
    }

    var manageUser = 0;
debugger


    this.apiService.wishlistSave(Number(this.ccid), loantype,loanamount, remarks,diarygiven, calendargiven, managementbrochure, paymentBrochure, CustFeedback, 'C', userid,'NULL').then(response=> {
     debugger
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      // res = JSON.parse(res);
      // res = JSON.parse(res);
      res = res;
      // res = response.replace('-','');

      // response = JSON.parse(res);
      // response = JSON.parse(res);
debugger
      // var result = JSON.stringify(res);
      // result = JSON.parse(result);
      // result = result;
      // if (res == 'S' || res == "") { 
        if(res) {
        debugger
        this.alertService.presentAlert('Success',"Saved Successfully");
        this.data = {};
            this.data1 = {};
            // this.relativeList = {};
            this.showUpdatePage = false;
            this.getAssignedlist();
            
      }
      // this.apiService.calendarDiaryEntryData(CustomerID, this.data.creditCard, this.data.mutual, this.data.insur, this.data.health, this.data.group, this.data.pos, this.data.bharat, this.data.fastag, this.data.gold, this.data.demat, this.data.asba, this.data.fd, this.data.locker, loanreq, loantype, loanamount, remarks, diarygiven, calendargiven, CustFeedback).then(response => {
      //   var res = JSON.stringify(response.data);
      //   debugger
      //   res = JSON.parse(res);
      //   debugger
      //   res = JSON.parse(res);
      //   if (res == 'S') {

      //     // var alertPopup = $ionicPopup.alert({
      //     //   title: 'Success',
      //     //   template: 'Saved Successfully',
      //     //   onTap: function (e) {
      //     //   }


      //     // });
      //     this.alertService.presentAlert('Success',"Saved Successfully");
      //     this.data = {};
      //     this.data1 = {};
      //     this.relativeList = {};

      //     // alertPopup.then(function (res) {
      //     //   // this.RNPartAaction.hide();
      //     //   this.data = {};
      //     //   this.data1 = {};
      //     //   this.relativeList = {};
      //     //   // Custom functionality....
      //     // });
      //   }
      // })
    })
  }
  insertRelative() {
    // this.relativeList=[];
    // this.rel.name = this.data1.name;
    // this.rel.mobile = this.data1.leadMobile;
    // this.rel.age = this.data1.age;
    //  this.relativeList.push(this.rel);

    //  console.log(this.relativeList)
    // this.showspin();
    if (this.data1.name == undefined) {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Name");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Name</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var name = this.data1.name;
    }

    if (this.data1.leadMobile == undefined) {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Mobile No");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Mobile No</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var leadmobile = this.data1.leadMobile;
    }

    if (this.data1.age == undefined) {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Age");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Age</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var age = this.data1.age;
    }

    if (this.data1.docAttach == undefined) {
      var docAttach = 'N';
    } else {
      docAttach = this.data1.docAttach;
    }
    var staus = 'A';
    var mode = 'Insert';
    var rowid = null
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];

    this.apiService.saveleadcust(branchid, userid, this.custID, name, leadmobile, age, docAttach, staus, mode, rowid).then(response => {
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      this.alertService.presentAlert('Success',"Saved Successfully");
      // var alertPopup = $ionicPopup.alert({
      //   title: 'Success',
      //   template: 'Saved Successfully',
      //   onTap: function (e) {
      //   }
      // });
      this.getRelative();
      this.data1 = {};
    })
  }
  getRelative() {
    // this.relativeList = {};
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    var staus ='A';
    var mode = 'Insert';
    var rowid = null
    var name= this.data1.name;
    var leadmobile= this.data1.leadMobile;
    var age= this.data1.age;
    var  docAttach= this.data1.docAttach;
    // var userid = window.localStorage['userID'];;
    // var branchid = window.localStorage['branchID'];
    // var userType = window.localStorage['userType'];
    var actionby = userid;
    // var ccid = "404650"

    this.apiService.saveleadcust(branchid, userid, Number(this.ccid), name, leadmobile, age, docAttach, staus, mode, rowid).then(response => {
    debugger
      var res = JSON.stringify(response.data);
      this.getRelatives();
      res = JSON.parse(res);
      res = JSON.parse(res);
      res = JSON.parse(res);
  
      // this.relativeList = res;
      // this.relativeList = this.relativeList.Table;
    })

  }

 getRelatives (){
   debugger
    // this.relativeList={};
    // this.showspin();
    // var ccid = "404650"
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
  
    this.apiService.getleadcust( Number(this.ccid), 'NULL').then(response => {
      debugger
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      res = JSON.parse(res);
      res = JSON.parse(res);
      this.relativeList = res;
      this.relativeList = this.relativeList.Table;
    });
  }

// calendarEntrySave  (){
//     // $scopshowspin();
//     console.log(this.custID);
//     console.log(this.data);
//     console.log(this.data1);
//     var userid = window.localStorage['userID'];;
//     var branchid = window.localStorage['branchID'];
//     var userType = window.localStorage['userType'];
//     var CustomerID = this.custID;
//     if(this.data.facility == undefined){
//       var loanreq = 'N';
//       var loantype = null;
//     }else{
//       var loanreq = 'Y';
//       var loantype = this.data.facility;
//     }
//     if(this.data.amount == undefined){
//       var loanamount = 0;
//     }else{
//       loanamount = this.data.amount;
//     }

//     if(this.data.remarks == undefined){
//       var remarks = null;
//     }else{
//       var remarks = this.data.remarks;
//     }

//     if(this.data.diarygiven == undefined){
//       // this.hidespin();
//       // var myPopup = $ionicPopup.show({
//       //   template: '<center>Enter the No of Diary Given</center>',
//       //   title: 'Alert',
//       //   scope: this,
//       //   buttons: [{
//       //     text: 'OK',
//       //     type: 'button button-clear button-assertive'
//       //   }]
//       // });
//       return false;
//     }else{
//       var diarygiven = this.data.diarygiven;
//     }

//     if(this.data.mangementBroch == undefined){
//       // this.hidespin();
//       // var myPopup = $ionicPopup.show({
//       //   template: '<center>Enter the No of Diary Given</center>',
//       //   title: 'Alert',
//       //   scope: this,
//       //   buttons: [{
//       //     text: 'OK',
//       //     type: 'button button-clear button-assertive'
//       //   }]
//       // });
//       // return false;
//       var managementbrochure = 'N';
//     }else{
//       var managementbrochure = 'Y';
//     }
   
//     if(this.data.calendargiven == undefined){
//       // this.hidespin();
//       // var myPopup = $ionicPopup.show({
//       //   template: '<center>Enter the No of Calendar Given</center>',
//       //   title: 'Alert',
//       //   scope: this,
//       //   buttons: [{
//       //     text: 'OK',
//       //     type: 'button button-clear button-assertive'
//       //   }]
//       // });
//       return false;
//     }else{
//       var calendargiven = this.data.calendargiven;
//     }

//     if(this.data.paymentBroch == undefined){
//       // this.hidespin();
//       // var myPopup = $ionicPopup.show({
//       //   template: '<center>Enter the No of Diary Given</center>',
//       //   title: 'Alert',
//       //   scope: this,
//       //   buttons: [{
//       //     text: 'OK',
//       //     type: 'button button-clear button-assertive'
//       //   }]
//       // });
//       // return false;
//       var paymentBrochure = 'N';
//     }else{
//       var paymentBrochure = 'Y';
//     }

//     if(this.data.CustFeedback == undefined){
//       // this.hidespin();
//       // var myPopup = $ionicPopup.show({
//       //   template: '<center>Enter the Remarks</center>',
//       //   title: 'Alert',
//       //   scope: this,
//       //   buttons: [{
//       //     text: 'OK',
//       //     type: 'button button-clear button-assertive'
//       //   }]
//       // });
//       return false;
//     }else{
//       var CustFeedback = this.data.CustFeedback;
//     }

//     var manageUser = 0;


//         this.apiService.wishlistSave(localStorage.getItem('ccid'), loantype,loanamount, remarks,diarygiven, calendargiven, managementbrochure, paymentBrochure, CustFeedback, 'C', userid,'NULL').then(response=> {
//          var res = JSON.stringify(response.data);
         
//     res = JSON.parse(res);
//     res = JSON.parse(res);
//     res = JSON.parse(res);
//     res = JSON.parse(res);

//         });
//         // .success(function(response) {
//         //   console.log(response);
//         //   this.hidespin();
//         //   response = JSON.parse(response);
          
          
//         //   var alertPopup = $ionicPopup.alert({
//         //     title: 'Success',
//         //     template: 'Saved Successfully',
//         //     onTap: function(e) {
//         //     }
//         //   });

//         //   alertPopup.then(function(res) {
//         //     this.RNPartAaction.hide();
//         //     this.getAssignedlist();
//         //     this.data={};
//         //     this.data1={};  
//         //     this.relativeList={};
//         //     // Custom functionality....
//         //   });
        
//         // })  
//         // .error(function(response) {
//         //   console.log(response);
//         //   this.hidespin();
//         //   $ionicPopup.alert({
//         //     title: 'Error',
//         //     template: 'An Error Occured! Please try again after some time.',
//         //     onTap: function(e) {
//         //     }
//         //   });
//         // });
     
//         localStorage.removeItem('ccid');
   
//   }
}
