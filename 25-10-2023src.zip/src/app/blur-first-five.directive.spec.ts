import { BlurFirstFiveDirective } from './blur-first-five.directive';

describe('BlurFirstFiveDirective', () => {
  it('should create an instance', () => {
    const directive = new BlurFirstFiveDirective();
    expect(directive).toBeTruthy();
  });
});
