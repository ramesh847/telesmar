import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';

import { MyfollowupcallconnectPage } from '../modal/myfollowupcallconnect/myfollowupcallconnect.page';
import { PlaneercallconnectPage } from '../modal/myplannerupdate/planeercallconnect/planeercallconnect.page';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
@Component({
  selector: 'app-checkmyplanner',
  templateUrl: './checkmyplanner.page.html',
  styleUrls: ['./checkmyplanner.page.scss'],
providers:[Idle]
})
export class CheckmyplannerPage implements OnInit {
  getnummmm:any;
  ins_type: any;
  ins_ref: any;
  ins_source: any;
  ClickAccess: boolean = false;
  accessResp: any;
  todayfollowupdata: any =[1];
  todayassigneddata: any =[];
  callOutCome: any;
  businessunit: any;
  productGroup: any;
  product: any;
  premiumPayTerm: any;
  premiumPayMode: any;
  TodaysAssigned: boolean = true;
  TodaysFollowup: boolean = false;
  firstWords: any[];
  idleState: string;
  constructor(private router: Router,private apiService: ApiServiceService,
    private modalController: ModalController,private loader:ToastServiceService,
    private AlertService:AlertServiceService,private idle:Idle
   ) { 
     
 // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
        // (this.idleState = countdown.toString() )
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
    );
   }

  ngOnInit() {
    debugger
    alert("hi")
    this.clickCallAccess();
    this.getInsuranceType();
    this.getInsuranceSource();
    this.getInsurancedata();
    this.getTodayAssignData();
    // this.reset()
  }
  clicknumberstar(num:any){
    debugger
   this.getnummmm= this.apiService.firstfivexxxx(num)
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  CheckBoxTodaysAssigned(value, checked) {
    debugger
    console.log(value, checked);
    if (value == 'TodaysAssigned' && checked == true) {
      this.TodaysFollowup = false;
    
      this.TodaysAssigned = true;
      this.getTodayAssignData();
    }
    else if (value == 'TodaysAssigned' && checked == false) {
      this.TodaysFollowup = true;
    
      this.TodaysAssigned = false;
      this.getTodayFollowData();
    }
  }

  CheckBoxTodaysFollowup(value, checked) {
    debugger
    if (value == 'TodaysFollowup' && checked == true) {
      this.TodaysFollowup = true;
      this.TodaysAssigned = false;
      this.getTodayFollowData();
    }
    else if (value == 'TodaysFollowup' && checked == false) {
      this.TodaysFollowup = false;
      this.TodaysAssigned = true;
      this.getTodayAssignData();
    }
  }
  clickCallAccess() {

    var userid = window.localStorage['userID'];
    this.apiService.AccesstoClick(userid).then(response => {
      this.accessResp = JSON.parse(response.data);
      if (this.accessResp == 'A') {
        console.log(this.accessResp);
        this.ClickAccess = true;
      } else {
        this.ClickAccess = false;
      }
    })
  }
  getTodayFollowData() {
debugger
    var CUSTID = window.localStorage['customerID'];
    console.log(CUSTID);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var customerid = null;
  
    this.apiService.todayfollowdata(userid, branchid, customerid).then(res => {
  debugger
      // $scope.hidespin();
      this.todayfollowupdata = [];
      console.log("todayfollowupdata---",res);
      var response = JSON.stringify(res.data);
      this.todayfollowupdata = JSON.parse(response);
      console.log("todayfollowupdata-34--",res);
      this.todayfollowupdata = JSON.parse(this.todayfollowupdata);
      this.todayfollowupdata = JSON.parse(this.todayfollowupdata);
      this.todayfollowupdata = this.todayfollowupdata;
     
      // this.todayfollowupdata = response;
      this.firstWords = [];
      var firstname = [];
      for (let i = 0; i < this.todayfollowupdata.length; i++) {
        firstname = this.todayfollowupdata[i].CUSTOMER_NAME.split(" ");
        this.firstWords.push(firstname[0]);
        this.todayfollowupdata[i].firstname = this.firstWords[i];

      }
      this.todayassigneddata = [1]
      console.log("todayfollowupdata", this.todayfollowupdata);
      // $scope.username = window.localStorage['userName'];   
    }).catch((error)=>{
      this.AlertService.presentAlert('failed',console.error(error));
      
    });
  }

  getTodayAssignData() {
    debugger
this.todayassigneddata = [];
    var CUSTID = window.localStorage['customerID'];
    console.log(CUSTID);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var customerid = null;
   
// this.loader.presentLoading('')
    this.apiService.todayassigndata(userid, branchid, customerid).then(res => {
      // $scope.hidespin();
      // this.loader.dismissLoading()
     
      console.log("todayassigndata---",res);
      console.log("todayassigndata---",res.data);
      var response = JSON.stringify(res.data);
      this.todayassigneddata = JSON.parse(response);
      this.todayassigneddata = JSON.parse(this.todayassigneddata);
      this.todayassigneddata = JSON.parse(this.todayassigneddata);
      this.todayassigneddata = this.todayassigneddata;
      console.log("todayassigneddata", this.todayassigneddata, this.todayassigneddata.length);
      // this.todayassigneddata = response;
      this.todayfollowupdata = [1];
      this.firstWords = [];
      var firstname = [];
      for (let i = 0; i < this.todayassigneddata.length; i++) {
        firstname = this.todayassigneddata[i].CUSTOMER_NAME.split(" ");
        this.firstWords.push(firstname[0]);
        this.todayassigneddata[i].firstname = this.firstWords[i];
      }
      // $scope.username = window.localStorage['userName'];

    }).catch((error)=>{
      this.AlertService.presentAlert('failed',console.error(error));
      
    });;





  }

  getInsuranceType() {
    this.apiService.getInsuranceType().then(response => {
      var Value = JSON.stringify(response.data)
      console.log(Value);
      // Value = JSON.parse(Value);
      // Value = JSON.parse(Value);
      this.ins_type = JSON.parse(Value);
      this.ins_type = JSON.parse(this.ins_type);
      this.ins_type = JSON.parse(this.ins_type);
      this.ins_type = this.ins_type;
      console.log(this.ins_type);
      // this.ins_type  = JSON.parse(response.data);
    });
    // .success(function(response) {
    //   console.log(response);
    //   $scope. = JSON.parse(response);
    // }).error(function(response) {
    //   $scope.hidespin();
    //   console.log(response);
    // });
  }
  getInsuranceSource() {
    this.apiService.getInsuranceSource().then(response => {
      var Value = JSON.stringify(response.data)
      console.log(Value);
      // Value = JSON.parse(Value);
      // Value = JSON.parse(Value);
      this.ins_source = JSON.parse(Value);
      this.ins_source = JSON.parse(this.ins_source);
      this.ins_source = JSON.parse(this.ins_source);
      this.ins_source = this.ins_source;
      console.log(this.ins_source);
      // this.ins_source = JSON.parse(response.data);
    });
    // callAPI.getInsuranceSource()
    // .success(function(response) {
    //   console.log(response);
    //   $scope.ins_source = JSON.parse(response);
    // }).error(function(response) {
    //   $scope.hidespin();
    //   console.log(response);
    // });
  }

  getInsurancedata() {

    this.apiService.getinsurancedetails('Refferals').then(response => {

      var Value = JSON.parse(response.data);
      console.log(Value);
      // Value = JSON.parse(Value);
      // Value = JSON.parse(Value);
      this.ins_ref = JSON.parse(Value);
      console.log(this.ins_ref);
      // this.ins_ref = JSON.parse(this.ins_ref);
      console.log(this.ins_ref);
      // this.ins_ref = JSON.parse(this.ins_ref);
      this.ins_ref = this.ins_ref.Table;
      console.log(this.ins_ref);
      // this.ins_ref = itemrefarr.Table;
    });
    // console.log(val);
    //Insurance Source
    //  callAPI.getinsurancedetails('Refferals')
    // .success(function(response) {
    //   $scope.hidespin();
    //   console.log(response);
    //   var itemrefarr = JSON.parse(response);
    //   $scope.ins_ref = itemrefarr.Table;
    // }).error(function(response) {
    //   $scope.hidespin();
    //   console.log(response);
    // });
  }
  doRefresh(event) {
    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);
  }

  startmyplanner(item){
    debugger
    alert("You have started the Meeting")
      // console.log(item);
      // var timestart = new Date();
      // console.log(timestart);
      // this.startmeetingtime = this.datepipe.transform(timestart,'h.mm a')
      // window.localStorage['startmeetingtime']=this.startmeetingtime
      // $filter('date')(timestart, 'h.mm s a');
      
      //console.log(this.startmeetingtime);
  }

  async startNavigationplanner(items){
    debugger
this.apiService.followupleadmodalarray=[]
    this.apiService.followupleadmodalarray.push(items,{model:"Navigationrootleads"},{close:"planner"})
    this.router.navigateByUrl('/followupleadmodal')

    // const modal = await this.modalController.create({
     // component: FollowupleadmodalPage,
    //   componentProps: { Data: items,model: "Navigationrootleads" }
    //   });
    //   return await modal.present();
  }

  async myfollowupActionModal(item) {
    debugger
    console.log(item);
    this.apiService.myfollowupvisitary=[]
    this.apiService.myfollowupvisitary.push(item,{close:"planner"})


    this.router.navigateByUrl('/myfollowupvisitendmodel')
   
    // const modal = await this.modalController.create({
    //   component:MyfollowupvisitendmodelPage ,
    //   componentProps: { Data: item }
    // });
    // return await modal.present();

  }

 async openfollowupconnectModel(item) {
    debugger
    // console.log(item);
alert("hi")
    // MyfollowupcallconnectPage
    const modal = await this.modalController.create({
      component:PlaneercallconnectPage ,
      componentProps: { Data: item ,model:"planner"}
    });
    return await modal.present();
  }
  

  myassignActionModal(item) {
    debugger
    this.apiService.todayassignedarray=[]
    this.apiService.todayassignedarray.push(item,{close:"planner"})


    this.router.navigateByUrl('/myplannerupdate');

    // const modal = await this.modalController.create({
    // component: MyassigncallmodalPage,
    // componentProps: { Data: item }
    // });
    // return await modal.present();

   }

   goToMyplannerPage() {
    this.router.navigateByUrl('/myplanner');
  }
 async openassignedconnectModel(items){

    const modal = await this.modalController.create({
    component: PlaneercallconnectPage,
    componentProps: { Data: items }
    });
    return await modal.present();
  }
}
