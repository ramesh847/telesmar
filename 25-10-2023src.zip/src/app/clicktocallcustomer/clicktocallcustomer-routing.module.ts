import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ClicktocallcustomerPage } from './clicktocallcustomer.page';

const routes: Routes = [
  {
    path: '',
    component: ClicktocallcustomerPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ClicktocallcustomerPageRoutingModule {}
