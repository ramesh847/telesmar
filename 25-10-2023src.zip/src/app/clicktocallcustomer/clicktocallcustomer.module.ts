import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ClicktocallcustomerPageRoutingModule } from './clicktocallcustomer-routing.module';

import { ClicktocallcustomerPage } from './clicktocallcustomer.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ClicktocallcustomerPageRoutingModule
  ],
  declarations: [ClicktocallcustomerPage]
})
export class ClicktocallcustomerPageModule {}
