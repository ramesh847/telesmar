import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
// import { NavParams } from '@ionic/angular';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Pipe, PipeTransform } from "@angular/core";
import { ApiServiceService } from 'src/app/service/api-service.service';
// import {UserprofilePage} from'./../userprofile/userprofile.page';
import { UserprofilePage } from './../userprofile/userprofile.page';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { DatePipe } from '@angular/common';
import {Router } from '@angular/router';
import { NativeGeocoder, NativeGeocoderOptions, NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-entryscreen',
  templateUrl: './entryscreen.page.html',
  styleUrls: ['./entryscreen.page.scss'],
  providers: [
    DatePipe,Idle]
    // selector: 'app-exceptionreport',
    // templateUrl: './exceptionreport.page.html',
    // styleUrls: ['./exceptionreport.page.scss'],
})
export class EntryscreenPage implements OnInit {

  EntryscreenForm: FormGroup;
  areaUnit:string = "T";
  checked: boolean = true;
  checkedNew: boolean = false;
  showCustomerID: boolean = true;
  entry = {};
  CallOutcomeItems: any = [];
  entrypurpose: any = [];
  businessunit: any = [];
  showFollowupDateTime: boolean = false;
  showJointVisitLocation: boolean = false;
  jointvisitChecked: boolean = false;
  showEmployeeDetails: boolean = false;
  showBusinessUnit: boolean = false;
  captionAmount: boolean = false;
  showDepositCasaAdvance: boolean = false;
  nextcalldate1: any;
  followuptime: any;
  date: any;
  lat1: any;
  lng1: any;
  addbaselocno: any;
  showInsuranceSellproductSourceLead: boolean = false;
  insuranceType: any;
  sourceOfLead: any;
  relationofLead: any;
  showRelationofLead: boolean = false;
  accuracy: any;
  time: any;
  jointvisit1: any;
  //Geocoder configuration
geoencoderOptions: NativeGeocoderOptions = {
  useLocale: true,
  maxResults: 5
};
address: any;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  idleState: string;
  constructor(private Apiservice: ApiServiceService,
    private alertService: AlertServiceService,
    private datepipe: DatePipe,
    public modalController: ModalController,
    private formBuilder: FormBuilder,
    private router: Router,
    private geolocation: Geolocation,
    private nativeGeocoder: NativeGeocoder,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); 
    
    
    }

  ngOnInit() {
    debugger
    // let myCompOneObj = new UserprofilePage(s,s,s,s);

    // myCompOneObj.myFunctionOne();
    this.EntryscreenForm = this.formBuilder.group({
      calloutcome: [''],
      calltype: [''],
      remarks: [''],
      followuptime: [''],
      followupdate: [''],
      jointvisit: [''],
      location: [''],
      empcode: [''],
      empname: [''],
      firstname: [''],
      lastname: [''],
      email: ['',[Validators.email]],
      mobile: [''],
      customerid: [''],
      bussiness: [''],
      purpose: [''],
      sourceoflead: [''],
      crosssellproduct: [''],
      insurance: [''],
      amount: ['',Validators.pattern('^[a-zA-Z \-\']+')],
      caption: [''],
      advance: [''],
      casa: [''],
      deposits: [''],
      insuranceType: [''],
      relationofLead:['']
    });
    
    this.getcalloutcome();
    this.getpurpose();
    this.getbusinessunitExisting();
    this.getInsuranceType();
    this.getInsuranceSource();
    this.getGeolocation();
    // this.EntryscreenForm.get('firstname').setValue("Lead Generation");
    // // this.EntryscreenForm.get('location').setValue(null);
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  getInsuranceType() {
    this.Apiservice.getInsuranceType().then(response => {
      
      var result = JSON.stringify(response.data);
      this.insuranceType = JSON.parse(result);
      this.insuranceType = JSON.parse(this.insuranceType);
      this.insuranceType = JSON.parse(this.insuranceType);
      console.log(response);
    });
    // this.Apiservice.getInsuranceType = function(){
    //   callAPI.getInsuranceType()
    //     .success(function(response) {
    //       console.log(response);
    //       this.ins_type = JSON.parse(response);
    //     }).error(function(response) {
    //       this.hidespin();
    //       console.log(response);
    //     });
    // }
  }
  changeInsurance(value) {
    console.log(value);
    this.EntryscreenForm.get('insuranceType').setValue(value);

  }
 
  getInsuranceSource() {
    this.Apiservice.getInsuranceSource().then(response => {
      var result = JSON.stringify(response.data);
      this.sourceOfLead = JSON.parse(result);
      this.sourceOfLead = JSON.parse(this.sourceOfLead);
      this.sourceOfLead = JSON.parse(this.sourceOfLead);
      console.log(response);
    })
    
      // callAPI.getInsuranceSource()
      //   .success(function(response) {
      //     console.log(response);
      //     this.ins_source = JSON.parse(response);
      //   }).error(function(response) {
      //     this.hidespin();
      //     console.log(response);
      //   });
    
  }
  get f() { return this.EntryscreenForm.controls; }
  getpurpose() {
    // this.showspin();
    this.Apiservice.getentrypurpose().then(response => {

      var result = JSON.stringify(response.data);
      this.entrypurpose = JSON.parse(result);
      this.entrypurpose = JSON.parse(this.entrypurpose);
      this.entrypurpose = JSON.parse(this.entrypurpose);
      
      // var result = response.data;
      // result = JSON.parse(result);
      // result = JSON.parse(result);
      // this.entrypurpose = result;
      // this.entrypurpose = JSON.parse(this.entrypurpose);
      console.log(response);
    })
    // .success(function(response) {

    //   console.log(response);
    //   var res = JSON.parse(response);
    //   console.log(res);
    //   this.callPurpose = res;


    //   // CODE BY JOHN 
    //   $rootScope.callPurpose_existingt = this.callPurpose[0].Text;
    //   $rootScope.callPurpose_existingv =  this.callPurpose[0].Value;

    //   // OLD SOURCE DONT KNOW WHY  res[2].Text; COMMENTED BY JOHN
    //   // $rootScope.callPurpose_existingt = res[2].Text;
    //   // $rootScope.callPurpose_existingv = res[2].Value;
    //   // console.log(this.callPurpose_existingt);
    //   // console.log(this.callPurpose_existingv);



    //   //this.existing = this.callPurpose.Value;
    //   //console.log(this.existing);
    //   this.hidespin();

    // })
    // .error(function(response) {
    //   console.log(response);
    //  this.hidespin(); 
    // });
  }

  getbusinessunitExisting() {
    // this.showspin();

    this.Apiservice.getbusinessunitExisting().then(response => {
      var result = JSON.stringify(response.data);
      this.businessunit = JSON.parse(result);
      this.businessunit = JSON.parse(this.businessunit);
      this.businessunit = JSON.parse(this.businessunit);

      // var result = response.data;
      // result = JSON.parse(result);
      // result = JSON.parse(result);
      // this.businessunit = result;
      // this.businessunit = JSON.parse(this.businessunit);
    });


  }

  getbusinessunitNew() {
    // this.showspin();

    this.Apiservice.getbusinessunitNew().then(response => {

      var result = JSON.stringify(response.data);
      this.businessunit = JSON.parse(result);
      this.businessunit = JSON.parse(this.businessunit);
      this.businessunit = JSON.parse(this.businessunit);

      // var result = response.data;
      // result = JSON.parse(result);
      // result = JSON.parse(result);
      // this.businessunit = result;
      // this.businessunit = response;
      // this.businessunit = JSON.parse(this.businessunit);
      console.log(this.businessunit);
    })
  }

  onSubmitForm(EntryscreenForm) {
    this.saveCourtesyCall();
  }
  modelDissmiss() {
    this.modalController.dismiss();
  }
  changeCallOutcome(value) {
    console.log(value)
    if (value == '2') {
      this.showFollowupDateTime = true;
      this.date = '';
      this.time = '';
      this.EntryscreenForm.get('followupdate').setValue('');
      this.EntryscreenForm.get('followuptime').setValue('')
    } else {
      this.showFollowupDateTime = false;
    }
    console.log(value);

  }
  changeProductType(value) {

  }
  changeCallType(value) {
    if (value == 'P') {
      this.showJointVisitLocation = true;
    } else {
      this.showJointVisitLocation = false;
    }
    console.log(value);

  }
  changeRelation(value) {
    this.EntryscreenForm.get('relationofLead').setValue(value);
  }
  changeSource(value) {
    if(value == "3") {
      this.showRelationofLead = true;
      this.relationofLeaD();
    }else {
      this.showRelationofLead = false;
    }
    this.EntryscreenForm.get('sourceoflead').setValue(value);

    console.log( value);
  }
  relationofLeaD() {
    this.Apiservice.getinsurancedetails('Refferals').then(response=> {
      var result = JSON.stringify(response.data);
      this.relationofLead = JSON.parse(result);
      this.relationofLead = JSON.parse(this.relationofLead);
      this.relationofLead = JSON.parse(this.relationofLead);
      this.relationofLead =  this.relationofLead.Table;
      console.log(" this.relationofLead", this.relationofLead)
    })
    // callAPI.getinsurancedetails('Refferals')
    // .success(function(response) {
    //   this.hidespin();
    //   console.log(response);
    //   var itemrefarr = JSON.parse(response);
    //   this.ins_ref = itemrefarr.Table;
    // }).error(function(response) {
    //   this.hidespin();
    //   console.log(response);
    // });
  }
  changeBussiness(value) {
    debugger
    if (value == '12') {
      this.captionAmount = false;
      this.showDepositCasaAdvance = false;
      this.showInsuranceSellproductSourceLead = true;
    }
    else if (value == '13') {
      this.showDepositCasaAdvance = false;
      this.showInsuranceSellproductSourceLead = false;
      this.captionAmount = true;

    }
    else if (value == '14' || value == '11') {
      this.showDepositCasaAdvance = true;
      this.showInsuranceSellproductSourceLead = false;
      this.captionAmount = false;
    }
    else {
      this.showDepositCasaAdvance = false;
      this.showInsuranceSellproductSourceLead = false;
      this.captionAmount = false;
    }
    // else if()
this.checkdeeping(value)
    console.log(value);
  }
  changeProductGroup(value) {

  }
  changePurposeType(value) {
    if (value == '3') {
      this.showBusinessUnit = true;
    } else {
      this.showBusinessUnit = false;
    }
    console.log(value)

  }

  jointVisit(value) {
    console.log(value);
    // console.log(value,value.detail.checked);
    if (value == false) {
      debugger
      this.jointvisit1 =  true;
      this.jointvisitChecked = true;
      this.showEmployeeDetails = true;
    } else {
      debugger
      this.jointvisit1 = false;
      this.jointvisitChecked = false;
      this.showEmployeeDetails = false;
    }

  }
  CheckBoxChangeNew(value, checked) {
  
    console.log(value, checked)
    debugger
    if (value == 'New' && checked == true) {
      debugger
      this.EntryscreenForm.reset();
      this.checked = false;
      this.showCustomerID = false;
      this.EntryscreenForm.get('purpose').setValue('3');
      this.getbusinessunitNew();
      // this.EntryscreenForm.get('purpose').setValue('Lead Generation'),
      // this.EntryscreenForm.patchValue({
      //   purpose : 'Lead Generation',
      
      // });
      // this.EntryscreenForm.get('purpose').setValue('Lead Generation');
      // this.EntryscreenForm.get('purpose').disabled;
      this.showEmployeeDetails = false;
      this.showFollowupDateTime = false;
      this.showJointVisitLocation = false;
      //  this.jointvisitChecked = true;
      // this.showEmployeeDetails = false;
      this.showBusinessUnit = true;
      this.captionAmount = false;
      this.showDepositCasaAdvance = false;
      this.showInsuranceSellproductSourceLead = false;
      // this.EntryscreenForm.get('jointVisit').setValue(false);
    }
    else if (value == 'New' && checked == false) {
      debugger
      this.EntryscreenForm.reset();
      this.checked = true;
      this.showCustomerID = true;
      this.getbusinessunitExisting();
      this.EntryscreenForm.get('purpose').setValue('');
      this.EntryscreenForm.controls.followupdate.setValue('');
      // this.EntryscreenForm.get('followupdate').setValue('');
      // this.EntryscreenForm.get('followuptime').setValue('');
      this.showEmployeeDetails = false;
      this.showFollowupDateTime = false;
      this.showJointVisitLocation = false;
      //  this.jointvisitChecked = true;
      // this.showEmployeeDetails = false;
      this.showBusinessUnit = false;
      this.captionAmount = false;
      this.showDepositCasaAdvance = false;
      this.showInsuranceSellproductSourceLead = false;
    }
  }
  CheckBoxChange(value, checked) {
    console.log(value, checked)
    debugger
    if (value == 'Existing' && checked == true) {
      debugger
      this.EntryscreenForm.reset();
      this.checkedNew = false;
      this.getbusinessunitExisting();
      this.EntryscreenForm.get('purpose').setValue('');
      this.EntryscreenForm.controls.followupdate.setValue('');
      // this.EntryscreenForm.get('followupdate').setValue('');
      // this.EntryscreenForm.get('followuptime').setValue('');
      this.showEmployeeDetails = false;
      this.showFollowupDateTime = false;
      this.showJointVisitLocation = false;
      //  this.jointvisitChecked = true;
      // this.showEmployeeDetails = false;
      this.showBusinessUnit = false;
      this.captionAmount = false;
      this.showDepositCasaAdvance = false;
      this.showInsuranceSellproductSourceLead = false;
    }
    else if (value == 'Existing' && checked == false) {
      debugger
      this.EntryscreenForm.reset();
      this.checkedNew = true;
      this.getbusinessunitNew();
      this.EntryscreenForm.get('purpose').setValue('3');
      // this.EntryscreenForm.reset();
      // this.EntryscreenForm.patchValue({
      //   purpose : 'Lead Generation',
      
      // });
      // this.EntryscreenForm.get('purpose').setValue('Lead Generation'),
      // this.EntryscreenForm.get('purpose').disabled;
      this.showEmployeeDetails = false;
      this.showFollowupDateTime = false;
      this.showJointVisitLocation = false;
      //  this.jointvisitChecked = true;
      // this.showEmployeeDetails = false;
      this.showBusinessUnit = true;
      this.captionAmount = false;
      this.showDepositCasaAdvance = false;
      this.showInsuranceSellproductSourceLead = false;
      // this.EntryscreenForm.get('jointvisit').setValue(false);
    }
  }

  empCode() {
    debugger
    var empcode = this.EntryscreenForm.get('empcode').value;
    this.Apiservice.getEmployeeName(empcode,window.localStorage['branchID']).then(res=> {
      debugger
      var response = JSON.parse(res.data);
      response = JSON.parse(response);
      // response = JSON.parse(response);
      console.log(response);

      if (response == "This User Not in this Branch") {
        this.alertService.presentAlert("","Please Enter The Valid Emp Code");
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Please Enter The Valid Emp Code</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.data.jointusername = "";
        // this.data.jointusercode = "";
        return false

      }else {
        this.EntryscreenForm.get('empname').setValue(response);
        console.log(response);
      }
   
    })
  }

  getcalloutcome() {

    this.Apiservice.getcalloutcome1().then(response => {
      var result = JSON.stringify(response.data);
      this.CallOutcomeItems = JSON.parse(result);
      this.CallOutcomeItems = JSON.parse(this.CallOutcomeItems);
      this.CallOutcomeItems = JSON.parse(this.CallOutcomeItems);


      // var result = response.data;
      // result = JSON.parse(result);
      // result = JSON.parse(result);
      // this.CallOutcomeItems = result;
      // this.CallOutcomeItems = JSON.parse(this.CallOutcomeItems);
      console.log(this.CallOutcomeItems);
    })


  }

  getCustomer() {

debugger
    var customerid = this.EntryscreenForm.get('customerid').value;
    console.log(customerid);

    if (customerid == "" || customerid == undefined || customerid == null) {
      this.alertService.presentAlert("","Enter Customer Id");
      // this.Alertservice.presentAlert("","This can\'t be removed.");
      // alert('Enter Customer Id')


    } else {

// this.Apiservice.Bankfetchdata().then((res)=>{
  //yes->normal
  debugger
  this.Apiservice.getcustomerdetails(customerid).then(response => {
    debugger
    console.log(response);
    var result = JSON.stringify(response.data);
    console.log(result);
   result = JSON.parse(result);
   result = JSON.parse(result);
   result = JSON.parse(result);
    var value =result;
    value = JSON.parse(value);
    console.log(value);
  
    console.log(value[0]);



    debugger
if(value.length==0){
this.alertService.presentAlert("","Please Enter the Valid Customer Id")
}else{

// window.localStorage['branchID']  
    if( value[0]['NBranch'] ==  window.localStorage['branchCode'] ){


      this.EntryscreenForm.patchValue({
        firstname :value[0]['Nfirstname'],
        lastname :value[0]['Nlastname'],
        mobile :value[0]['Nmobile'],
        // resdphnno = this.value[0].Nresidencephone;
        location: value[0]['Add1'] + value[0]['Add2'] +  value[0]['Add3'] +  value[0]['Add4'],
        email :value[0]['Nemail']
      })

     
    }
    else{
       
        this.alertService.presentAlert("","CustomerId does not Belongs to this Branch")
     
    }
  }
  })

// })

    
   
    }
  }
  dateCheck() {
    this.time=''
  }
  timeCheck() {
    var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
    var date1 = this.datepipe.transform( this.date,'YYYY-MM-dd')
    if (date1 <= date) {
      this.alertService.presentAlert("","The Call Back Date should not be same and less than current date")
    //  this.date=''
    //  this.time=''

  }
}
  // changeCallOutcome


  saveCourtesyCall() {
    debugger
    this.getGeolocation();
    console.log(this.EntryscreenForm.getRawValue());
    // this.showspin($ionicLoading);
    var courtesyCustomerID = this.EntryscreenForm.get('customerid').value;
    var username = window.localStorage['userName'];
    var branchid = window.localStorage['branchID'];
    var CallerId = window.localStorage['userID'];
    var callid = null;
    var cbsid = null;
    var firstname = null;
    var customername = null;
    var lastname = null;
    var mobile = null;
    var remarks = null;
    var latvalue = null;
    var langvalue = null;
    var address = null;

    var collectionmode = null;
    var accountno = null;
    var amount = null;
    var collectiondate = null;
    var casaVal = null;
    var depositVal = null;
    var AdvanceVal = null;
    var InsuranceVal = null;
    var BusinessUnit = null;
    var nextcalldate = null;
    var jointvisit = null;
    var jointcode = null;
    var Endtime = null;
    var Totime = null;
    var mode = null;
    var depositVal = null;
    var casaVal = null;
    var AdvanceVal = null;
    var InsuranceVal = null;

    mode = "N";
    var usercode = window.localStorage['userCode'];
    if (courtesyCustomerID == "" || courtesyCustomerID == undefined || courtesyCustomerID == 'undefined') {
      cbsid = 0;
    } else {
      cbsid = courtesyCustomerID;
    }




    var customername1 = this.EntryscreenForm.get('firstname').value;
    var firstname1 = this.EntryscreenForm.get('firstname').value;
    var lastname1 = this.EntryscreenForm.get('lastname').value;
    var mobile1 = this.EntryscreenForm.get('mobile').value;
    var calltype = this.EntryscreenForm.get('calltype').value;
    var remarks1 = this.EntryscreenForm.get('remarks').value;
    var purpose = this.EntryscreenForm.get('purpose').value;
    var responseid = this.EntryscreenForm.get('calloutcome').value;
    var depositVal = this.EntryscreenForm.get('deposits').value;
    var businessunit = this.EntryscreenForm.get('bussiness').value;
    var deposits = this.EntryscreenForm.get('deposits').value;
    var casa = this.EntryscreenForm.get('casa').value;
    var advance = this.EntryscreenForm.get('advance').value;
    var insurance = this.EntryscreenForm.get('insurance').value;
    var caption = this.EntryscreenForm.get('caption').value;
    var amount = this.EntryscreenForm.get('amount').value;
    var purpose = this.EntryscreenForm.get('purpose').value;
    var callout = this.EntryscreenForm.get('calloutcome').value;
    var jointusercode = this.EntryscreenForm.get('empcode').value;
    var jointvisit = this.jointvisit1;
    var followupdate = this.EntryscreenForm.get('followupdate').value;
    var followuptime = this.EntryscreenForm.get('followuptime').value;
    //new code ramesh
    var crosssell = this.EntryscreenForm.get('insuranceType').value;
    var sourceofle=this.EntryscreenForm.get('sourceoflead').value;
    
    debugger
    var address = this.EntryscreenForm.get('location').value;
    /*if(this.data1.exist =='YES')
    {
      if(this.assigned.customerid =="" || this.assigned.customerid ==undefined )
    {
      var myPopup = $ionicPopup.show({
              template: '<center>Enter valid customerid</center>',
              title: "",
              scope: this,
              buttons: [{
                text: 'OK',
                type: 'button button-clear button-assertive'
              }]
            });
            this.hidespin($ionicLoading);

            return false;
          }
    }
    */
   if(this.checked == true) {
    if(courtesyCustomerID =="" || courtesyCustomerID ==undefined || courtesyCustomerID == null )
    {
      this.alertService.presentAlert("","Enter customerid");
      // var myPopup = $ionicPopup.show({
      //         template: '<center>Enter valid customerid</center>',
      //         title: "",
      //         scope: this,
      //         buttons: [{
      //           text: 'OK',
      //           type: 'button button-clear button-assertive'
      //         }]
      //       });
      //       this.hidespin($ionicLoading);

            return false;
          }

   }
   
    if (firstname1 == "") {
      firstname = null;
    } else {
      firstname = firstname1;
    }


    // if (purpose == 3) {
    if (businessunit == 11 || businessunit == 14) {
      if ((deposits == "" || deposits == undefined || deposits == null)  && (casa == "" || casa == undefined || casa == null) && (advance == "" || advance == undefined || advance ==null)) {
        // alert('Enter atleast one BusinessUnit')
        this.alertService.presentAlert("","Enter atleast one BusinessUnit");
        //   var myPopup = $ionicPopup.show({
        //     template: '<center>Enter atleast one BusinessUnit</center>',
        //     title: "",
        //     scope: this,
        //     buttons: [{
        //       text: 'OK',
        //       type: 'button button-clear button-assertive'
        //     }]
        //   });
        //   this.hidespin($ionicLoading);

          return false;
        // }
      }
    }

    if (businessunit == 12) {
      if (insurance == "" || insurance == undefined || insurance == null) {
        this.alertService.presentAlert("","Enter Insurance");
        // alert('Enter Insurance')
        //   var myPopup = $ionicPopup.show({
        //     template: '<center>Enter Insurance</center>',
        //     title: "",
        //     scope: this,
        //     buttons: [{
        //       text: 'OK',
        //       type: 'button button-clear button-assertive'
        //     }]
        //   });
        //   this.hidespin($ionicLoading);

          return false;
        // }
      }else if(crosssell=="" || crosssell==undefined || crosssell==null){
        this.alertService.presentAlert("","Enter Cross sell Product");
        return false
      }else if(sourceofle=="" || sourceofle==undefined || sourceofle==null){
        this.alertService.presentAlert("","Enter Source of Lead");
        return false
      }
    }
    if (businessunit == 13) {
      if (caption == "" || caption == undefined || caption == null) {
        this.alertService.presentAlert("","Enter Caption ");
        // alert('Enter Caption and Amount')
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Caption and Amount</center>',
        //   title: "",  || (amount == "" || amount == undefined || amount == null)
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);

        return false;
      }else if(amount == "" || amount == undefined || amount == null){
        this.alertService.presentAlert("","Enter Amount ");
        return false
      }
    }
    if (customername1 == "") {

      customername = null;
    } else {
      customername = customername1;
    }
    if (this.checkedNew == true) {
      if (lastname1 == "" || lastname1 == undefined || lastname1 == null) {
        this.alertService.presentAlert("","Enter Last Name");
       

        return false;
      } else if(lastname1 == '.'){
        lastname = 'test'
      }
      else{
        lastname = lastname1;
      }
    }

    if (this.checked == true) {
      if (lastname1 == "" || lastname1 == undefined || lastname1 == null) {
        lastname = null;
      } else if(lastname1 == '.'){
        lastname = 'test'
      } else {
        lastname = lastname1;
      }
    }

    if (this.checkedNew == true) {
      if (mobile1 == "" || mobile1 == undefined || mobile1 == null) {
        this.alertService.presentAlert("","Enter Mobile Number");
        // alert('Enter Mobile Number');
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Mobile Number</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;
      } else {
        mobile = mobile1;
      }
    }

    if (this.checked == true) {
      if (mobile1 == "") {
        mobile = null;
      } else {
        mobile = mobile1;
      }
    }

    if (purpose == "" || purpose == undefined || purpose == null )  {
      this.alertService.presentAlert("","Select Purpose");
      // alert('Select Purpose')
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Purpose</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;

    }

    if (responseid == "" || responseid == undefined || responseid == null) {
      this.alertService.presentAlert("","Select Call OutCome");
      // alert('Select Call OutCome')
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call OutCome</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;

    }

    if (calltype == "" || calltype == undefined ||calltype == null) {
      this.alertService.presentAlert("","Select Call Type");
      // alert('Select Call Type');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call Type</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;

    }

    if (remarks1 == "" || remarks1 == undefined || remarks1 == null) {
      this.alertService.presentAlert("","Enter Remarks");
      // alert('Enter Remarks');
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Remarks</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      return false;
    } else {
      remarks = remarks1;
    }

    // var courtesyResidentialPhone = document.getElementById('courtesyResidentialPhone').value;
    // if (purpose == "5" && this.data.current == "Y") {

    //   if ((this.data.collected_accno == null || this.data.collected_accno == undefined || this.data.collected_accno == "") || (this.data.collectamount == null || this.data.collectamount == undefined || this.data.collectamount == "") || (this.data.collected_date == null || this.data.collected_date == "" || this.data.collected_date == undefined)) {

    //     alert('Fill All Details Of Amount Collected');
    //     // var myPopup = $ionicPopup.show({
    //     //   template: '<center>Fill All Details Of Amount Collected</center>',
    //     //   title: "",
    //     //   scope: this,
    //     //   buttons: [{
    //     //     text: 'OK',
    //     //     type: 'button button-clear button-assertive'
    //     //   }]
    //     // });
    //     // this.hidespin($ionicLoading);
    //     // return false;
    //   } else {
    //      collectionmode = "Y";
    //      accountno = this.data.collected_accno;
    //      amount = this.data.collectamount;
    //     this.collectiondate1 = this.data.collected_date;
    //      collectiondate = $filter('date')(this.collectiondate1, 'yyyy-MM-dd');
    //   }
    // }





    if (purpose != "5") {

      collectionmode = null;

    }

    if (collectionmode == null) {
      accountno = null;
      amount = null;
      collectiondate = null;

    }



    // if (purpose == "5") {
    //   if (this.data.current == "" || this.data.current == undefined || this.data.current == null || this.data.current == 'N') {
    //      collectionmode = null;

    //   }
    // }

    if (purpose == "3") {
      console.log(businessunit);
      if (businessunit == null || businessunit == undefined || businessunit == "") {
        this.alertService.presentAlert("","Select Business Unit");
        // alert("Select Business Unit")
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Select Business Unit</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;

      } else {
        BusinessUnit = businessunit;
      }
    }
    if (purpose == "3" && businessunit == 14) {
      if (deposits == 0 && casa == 0 && advance == 0 && insurance == 0) {
        this.alertService.presentAlert("","Fill Details Of Expected Business");
        // alert('Fill Details Of Expected Business');
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Fill Details Of Expected Business</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;
      } else {
        casaVal = casa;
        depositVal = deposits;
        AdvanceVal = advance;
        InsuranceVal = insurance;
      }
    }

    if (deposits != 0 || casa != 0 || advance != 0 || insurance != 0) {
      casaVal = casa;
      depositVal = deposits;
      AdvanceVal = advance;
      InsuranceVal = insurance;
    }


    if (purpose != "3") {
      casaVal = 0;
      depositVal = 0;
      AdvanceVal = 0;
      InsuranceVal = 0;

    }

    if (purpose != "3") {

      BusinessUnit = 0;
    }

    if (callout == "2") {
      if ((followupdate == null || followupdate == undefined || followupdate == "") || (followuptime == null || followuptime == undefined || followuptime == "")) {
        this.alertService.presentAlert("","Provide Followup Details");
        // alert('Provide Followup Details');
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Provide Followup Details</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;


      } else {
        var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        var date1 = this.datepipe.transform( this.date,'YYYY-MM-dd')
        if (date1 <= date) {
          this.alertService.presentAlert("","The Call Back Date should not be same and less than current date")
          return false
        }else{

        this.nextcalldate1 = this.datepipe.transform(this.date, 'yyyy-MM-dd');
        // $filter('date')(followupdate, 'yyyy-MM-dd');
        var time = this.time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.time];

        if (time.length > 1) { // If time format correct
          time = time.slice (1);  // Remove full string match value
          this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
          time[0] = +time[0] % 12 || 12; 
          time[1]="."// Adjust hours
        }
        this.modifytime1= time.join ('');
        if(this.getampm=="AM"){
          this.modifytime2= this.modifytime1+' '+"AM"
        }else{
          this.modifytime2= this.modifytime1+' '+"PM"
        }
        nextcalldate = this.nextcalldate1 + ' ' + this.modifytime2;

      }
    }
    }

    if (callout != "2") {
      nextcalldate = null;

    }


debugger
    if (calltype == "P" && jointvisit == true) {

      if (jointusercode == null || jointusercode == undefined || jointusercode == "") {
        this.alertService.presentAlert("","Enter Emp Code");
        // alert('Enter Joint Usercode');
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Joint Usercode</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        return false;
      } else {
        jointvisit = "Y";
        jointcode = jointusercode;

      }


    }

    if (calltype != "P") {

      jointvisit = null;

    }

    if (calltype == "P") {
      if (jointvisit == "" || jointvisit == undefined || jointvisit == null || jointvisit == false) {

        jointvisit = null;
      }

    }

    if (jointvisit == null) {
      jointcode = null;
    }

    Endtime = null;
    Totime = null;

    if (this.checked = true) {
       mode = 'N';
    } else {
       mode = 'E';
    }





    /*if (depositVal == "") {
          debugger;
          var myPopup = $ionicPopup.show({
            template: '<center>Select Deposit</center>',
            title: "",
            scope: this,
            buttons: [{
              text: 'OK',
              type: 'button button-clear button-assertive'
            }]
          });
          this.hidespin($ionicLoading);
          return false;

        }*/
        if(businessunit == 13 && this.showDepositCasaAdvance == true) {
          if (deposits == null || deposits == undefined || deposits == "") {
            this.alertService.presentAlert("","Select Deposit");
            depositVal = null;
            /*   var myPopup = $ionicPopup.show({
                    template: '<center>Select Deposit</center>',
                    title: "",
                    scope: this,
                    buttons: [{
                      text: 'OK',
                      type: 'button button-clear button-assertive'
                    }]
                  });*/
                  return false
          } else {
      
            depositVal = depositVal;
      
          }
        }
  

    if (casa == null || casa == undefined || casa == "") {

      casaVal = null;

    } else {

      casaVal = casa;

    }

    if (businessunit == 13) {


      if (caption == null || caption == undefined || caption == "") {

        AdvanceVal = null;

      } else {

        AdvanceVal = caption;

      }
    }
    else {

      if (advance == null || advance == undefined || advance == "") {

        AdvanceVal = null;

      } else {

        AdvanceVal = advance;

      }
    }

    if (businessunit == 13) {


      if (amount == null || amount == undefined || amount == "") {

        InsuranceVal = null;

      } else {

        InsuranceVal = amount;

      }
    }
    else {

      if (insurance == null || insurance == undefined || insurance == "") {

        InsuranceVal = null;

      } else {

        InsuranceVal = insurance;

      }
    }
    if (calltype == "P") {
      debugger
      // console.log(address)
      if (address == "" || address == 'undefined' || address == undefined || address == null) {
        // console.log(address)
        
        this.alertService.presentAlert("","Enter Your Location");
        this.checkedNew = this.checkedNew;
        if(this.checkedNew == true) {
          this.checked  =false; 
        }else {
          this.checked = true;
        }
        this.checked = this.checked;
        // alert('Enter Your Location');
        return false;
      } else {
        //alert(latvalue);
        latvalue = this.lat1;
        //console.log(latvalue)
        langvalue = this.lng1;
        //console.log(latvalue)
        address = address;
      }
debugger

    } else {
      debugger
      latvalue = null;
      langvalue = null;
      address = null;
    }

    if(depositVal == '' || depositVal == undefined ) {
      depositVal = null;
    }
debugger
if( window.localStorage['userType']=='17'){

  //ManagerEntry Screen
  if (calltype == "P") {
    console.log("calltype is  p");
    // this.showspin();
    //       // cbsid = 0;
    console.log(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, mode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal+"_0_0_0")
    this.Apiservice.managerEntryScreen(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, mode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal+"_0_0_0").then(response => {
     
     debugger
      var result = response.data;
      result = JSON.parse(result);
      result = JSON.parse(result);
      // result = JSON.parse(response); 
      var success;
      debugger
      success = result;
      debugger
      if (success == 4) {
        this.alertService.presentAlert('Warning',"This Customer Is Not Mapped With You");
        // alert('This Customer Is Not Mapped With You');

      }

      else if
        (success == 2) {
          this.alertService.presentAlert('Warning',"This Customer Is Not Mapped With You");
        // alert('This Customer Is Not Mapped With You');

      }

      else if
        (success == 3) {
          this.alertService.presentAlert('Warning',"This Customer Already Mapped To You. No Need To Convert");
        // alert('This Customer Already Mapped To You. No Need To Convert')


      }
      else if (success[0].response == 1) {
        this.alertService.presentAlert('Warning',"Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status" + success[0].Column1);
        // alert('Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status' + success[0].Column1)

      }
      else  {
        console.log(success);
        console.log(latvalue);
        console.log(langvalue)
        console.log(address);
        console.log(purpose);
        console.log(cbsid)
        // this.showspin();

        var addressnew = address.replace("/", "-");
        this.Apiservice.saveaddress(success, latvalue, langvalue, addressnew, purpose, cbsid).then(response => {
         debugger
          if (response.data == '"Yes"') {

            // $("#mapshowimage").css("display", "none");
            // console.log("$(#mapshowimage).css(display, none)")
            this.alertService.presentAlert('Success',"Saved Successfully");
            this.EntryscreenForm.reset();
            // alert('Saved Successfully')

          }
          else {

            this.alertService.presentAlert('Success',"Saved Successfully");
            // alert('Error While Saving');
            this.EntryscreenForm.reset();
          }
        })
      }
    })

  }
  else {
    debugger
    console.log("calltype is not p");
    //  this.showspin();
    this.Apiservice.managerEntryScreen(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, mode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal+"_0_0_0").then(response => {
      var result = response.data;
      result = JSON.parse(result);
      result = JSON.parse(result);
      // result = JSON.parse(response); 
      var success;
      success = result;

      console.log("entryScreenSaveResponse", success)

      if (success == 4) {
        this.alertService.presentAlert('Warning',"This Customer Is Not Mapped With You");
        // alert('This Customer Is Not Mapped With You');
      }
      else if (success == 2) {
        this.alertService.presentAlert('Warning',"This Customer Is Not Mapped With You");
        // alert('This Customer Is Not Mapped With You');

      }
      else if (success == 3) {
        this.alertService.presentAlert('Warning',"This Customer Already Mapped To You. No Need To Convert");
        // alert('This Customer Already Mapped To You. No Need To Convert');


      }
      else if (success[0].response == 1) {
        this.alertService.presentAlert('Warning',"Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status"+ success[0].Column1);
        // alert('Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status' + success[0].Column1)

      }
      else {
        this.alertService.presentAlert('Success',"Saved Successfully");
        this.EntryscreenForm.reset();
        // alert('Saved Successfully');
      }
    })

  }

}else{

    if (calltype == "P") {
      console.log("calltype is  p");

     
      // this.showspin();
      //       // cbsid = 0;
      console.log(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, mode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal+"_0_0_0")
      this.Apiservice.EntryScreen(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, 
        mode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal+'_0'+'_0'+'_0'+'_0'+'_0'+'_0'+'_0').then(response => {
       
       debugger
        var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
        // result = JSON.parse(response); 
        var success;
        debugger
        success = result;
        debugger
        if (success == 4) {
          this.alertService.presentAlert("","This Customer Is Not Mapped With You");
          // alert('This Customer Is Not Mapped With You');

        }

        else if
          (success == 2) {
            this.alertService.presentAlert("","This Customer Is Not Mapped With You");
          // alert('This Customer Is Not Mapped With You');

        }

        else if
          (success == 3) {
            this.alertService.presentAlert("","This Customer Already Mapped To You. No Need To Convert");
          // alert('This Customer Already Mapped To You. No Need To Convert')


        }
        else if (success[0].response == 1) {
          this.alertService.presentAlert("","Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status" + success[0].Column1);
          // alert('Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status' + success[0].Column1)

        }
        else  {
          console.log(success);
          console.log(latvalue);
          console.log(langvalue)
          console.log(address);
          console.log(purpose);
          console.log(cbsid)
          // this.showspin();

          var addressnew = address.replace("/", "-");
          this.Apiservice.saveaddress(success, latvalue, langvalue, addressnew, purpose, cbsid).then(response => {
           debugger
            if (response.data == '"Yes"') {

              // $("#mapshowimage").css("display", "none");
              // console.log("$(#mapshowimage).css(display, none)")
              this.alertService.presentAlert('Success',"Saved Successfully");
              this.EntryscreenForm.reset();
              // alert('Saved Successfully')

            }
            else {

              this.alertService.presentAlert('Success',"Saved Successfully");
              // alert('Error While Saving');
              this.EntryscreenForm.reset();
            }
          })
        }
      })

    }
    else {
      debugger
      console.log("calltype is not p");
      //  this.showspin();
      this.Apiservice.EntryScreen(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, mode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal,InsuranceVal+'_0'+'_0'+'_0'+'_0'+'_0'+'_0'+'_0').then(response => {
        var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
        // result = JSON.parse(response); 
        var success;
        success = result;

        console.log("entryScreenSaveResponse", success)

        if (success == 4) {
          this.alertService.presentAlert("","This Customer Is Not Mapped With You");
          // alert('This Customer Is Not Mapped With You');
        }
        else if (success == 2) {
          this.alertService.presentAlert("","This Customer Is Not Mapped With You");
          // alert('This Customer Is Not Mapped With You');

        }
        else if (success == 3) {
          this.alertService.presentAlert("","This Customer Already Mapped To You. No Need To Convert");
          // alert('This Customer Already Mapped To You. No Need To Convert');


        }
        else if (success[0].response == 1) {
          this.alertService.presentAlert("","Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status"+ success[0].Column1);
          // alert('Please Visit Pending Courtesy Call Screen As It Is In FOLLOW UP Status' + success[0].Column1)

        }
        else {
          this.alertService.presentAlert('Success',"Saved Successfully");
          this.EntryscreenForm.reset();
          // alert('Saved Successfully');
        }
      })

    }
  }

  }

  checkdeeping (val) {
    debugger
    var deeping = val;
    console.log(deeping);
    var courtesyCustomerID = this.EntryscreenForm.get('customerid').value;
    var customername1 = this.EntryscreenForm.get('firstname').value;
    var firstname1 = this.EntryscreenForm.get('firstname').value;
    var lastname1 = this.EntryscreenForm.get('lastname').value;
    var mobile1 = this.EntryscreenForm.get('mobile').value;
    var calltype = this.EntryscreenForm.get('calltype').value;
    var remarks1 = this.EntryscreenForm.get('remarks').value;
    var purpose = this.EntryscreenForm.get('purpose').value;
    var responseid = this.EntryscreenForm.get('calloutcome').value;
    var depositVal = this.EntryscreenForm.get('deposits').value;
    var businessunit = this.EntryscreenForm.get('bussiness').value;
    var deposits = this.EntryscreenForm.get('deposits').value;
    var casa = this.EntryscreenForm.get('casa').value;
    var advance = this.EntryscreenForm.get('advance').value;
    var insurance = this.EntryscreenForm.get('insurance').value;
    var caption = this.EntryscreenForm.get('caption').value;
    var amount = this.EntryscreenForm.get('amount').value;
    var purpose = this.EntryscreenForm.get('purpose').value;
    var callout = this.EntryscreenForm.get('calloutcome').value;
    var jointusercode = this.EntryscreenForm.get('empcode').value;
    var jointvisit = this.jointvisit1;
    var followupdate = this.EntryscreenForm.get('followupdate').value;
    var followuptime = this.EntryscreenForm.get('followuptime').value;
    debugger
    var address = this.EntryscreenForm.get('location').value;
    //var branchid = window.localStorage['branchID'];
    var struserID = window.localStorage['userID'];
    var custype = 'E';
    if(courtesyCustomerID==""){
      courtesyCustomerID=null
    }
    // this.showspin();
    if(deeping == 14 &&  this.showCustomerID == true){
      console.log('checking');
      if(courtesyCustomerID != undefined || courtesyCustomerID != null ){
        this.Apiservice.deepingcheck(struserID,courtesyCustomerID,custype, deeping)
        .then((response:any)=> {
          // this.hidespin();
          debugger
          console.log(response);
          response = JSON.parse(response);
          if (response == "This customer is not mapped with you. Cannot select Deepening Of Customer") {

            this.alertService.presentAlert("","This customer is not mapped with you. Cannot select Deepening Of Customer")
            
            this.EntryscreenForm.reset();
            // this.assigned.customerid = "";
          //  this.EntryscreenForm.patchValue(
          //    {customerid=''}
          //    )
            this.entry = {};
    
          }
        })
       
      }else{
        this.alertService.presentAlert("","Customer ID is Required")
        return true
       
      }
    }else if(deeping == 12 ){
        this.relationofLeaD();
    }else{
      // this.hidespin();
    }

  }

  getGeolocation() {
    debugger
    this.lat1 = "13.0306479";
    this.lng1 = "80.2380532";
    debugger
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        debugger
        if (position) {
          console.log("Latitude: " + position.coords.latitude +
            "Longitude: " + position.coords.longitude);
          this.lat1 = position.coords.latitude;
          this.lng1 = position.coords.longitude;
          console.log(this.lat1);
          console.log(this.lng1);
        }
      },);
    }
    debugger
    navigator.geolocation.getCurrentPosition((position) => {
      debugger
      this.lat1 = position.coords.latitude;
      this.lng1 = position.coords.longitude;
      this.accuracy = position.coords.accuracy;
      window.localStorage['latitude'] =this.lat1;
      window.localStorage['longitude'] =this.lng1;
      window.localStorage['accuracy'] =this.accuracy;
      debugger
      this.getGeoencoder(position.coords.latitude, position.coords.longitude);
      // this.zoom = 16;
      console.log('position', position);
    });
    debugger
  // this.geolocation.getCurrentPosition().then((resp) => {
  // debugger
  //   this.lat1 = resp.coords.latitude;
  //   this.lng1 = resp.coords.longitude;
  //   this.accuracy = resp.coords.accuracy;
  
  //   window.localStorage['latitude'] =this.lat1
  //   window.localStorage['longitude'] =this.lng1
  //   window.localStorage['accuracy'] =this.accuracy
  //   debugger
  //   this.getGeoencoder(resp.coords.latitude, resp.coords.longitude);
  
  // })
  // .catch((error) => {
  //   alert('Error getting location' + JSON.stringify(error));
  // });
  }
  
  //geocoder method to fetch address from coordinates passed as arguments
  getGeoencoder(latitude, longitude) {
    debugger
  this.nativeGeocoder.reverseGeocode(latitude, longitude, this.geoencoderOptions)
    .then((result: NativeGeocoderResult[]) => {
      this.address = this.generateAddress(result[0]);
    })
    .catch((error: any) => {
      alert('Error getting location' + JSON.stringify(error));
    });
  }

  //Return Comma saperated address
generateAddress(addressObj) {
  debugger
let obj = [];
let address = "";
for (let key in addressObj) {
  obj.push(addressObj[key]);
}
obj.reverse();
for (let val in obj) {
  if (obj[val].length)
    address += obj[val] + ', ';
}
return address.slice(0, -2);
}
  
  //  setlatlong (address) {
  //     console.log(address);
  //     // $http.get('https://maps.googleapis.com/maps/api/geocode/json?address=' + address + '&key=AIzaSyBmB20neq4usVvgGguBN-zm4tubXXM3QDg').then(function(resp) {

  //       var geocoder = new google.maps.Geocoder();
  //       geocoder.geocode( { 'address': address,'region': 'IN' }, function(resp, status) {
  //       if (status == google.maps.GeocoderStatus.OK) {


  //         var geocoder = new google.maps.Geocoder();
  //     geocoder.geocode( { 'address': resp[0].formatted_address,'region': 'IN'}, function(resp, status) {
  //     if (status == google.maps.GeocoderStatus.OK) {
  //       console.log(resp);
  //       this.BranchLatLong = resp[0].geometry.location.lat() + ',' + resp[0].geometry.location.lng();
  //       //console.log(this.BranchLatLong)

  //       this.lat1 = resp[0].geometry.location.lat();
  //       console.log(this.lat1);
  //       this.lng1 = resp[0].geometry.location.lng();
  //       console.log(this.lng1);
  //       this.addbaselocno = (this.lat1) + "," + (this.lng1);
  //      this.typeshowmap1(resp[0])
  //       }

  //     })

  //   }
  // })
  //   }
    getinfoadd (data) {
      console.log(data);
      console.log(data.formatted_address);
     this.lat1 = data.geometry.location.lat();
     this.lng1 = data.geometry.location.lng();
     this.addbaselocno = (this.lat1) + "," + (this.lng1);
    //  this.typeshowmap(this.lat1, this.lng1, data);
    };
    goToMyplannerPage() {
      this.jointvisitChecked = false;
      this.EntryscreenForm.reset()

      // if( window.localStorage['userType']=='17'){
        
      //   this.router.navigateByUrl('/newsummary');
      // }else{


      // this.router.navigateByUrl('/myplanner');
      // }

      if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
        this.router.navigate(['/regionsummary']);
  }else
      if(window.localStorage['userType']=='17')
    { this.router.navigate(['/newsummary']);}else{
      this.router.navigateByUrl('/myplanner');
    }

    }

}