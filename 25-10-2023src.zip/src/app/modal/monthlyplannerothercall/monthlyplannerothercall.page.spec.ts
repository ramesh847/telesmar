import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MonthlyplannerothercallPage } from './monthlyplannerothercall.page';

describe('MonthlyplannerothercallPage', () => {
  let component: MonthlyplannerothercallPage;
  let fixture: ComponentFixture<MonthlyplannerothercallPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthlyplannerothercallPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MonthlyplannerothercallPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
