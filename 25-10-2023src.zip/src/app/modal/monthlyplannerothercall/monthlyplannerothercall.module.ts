import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MonthlyplannerothercallPageRoutingModule } from './monthlyplannerothercall-routing.module';

import { MonthlyplannerothercallPage } from './monthlyplannerothercall.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MonthlyplannerothercallPageRoutingModule
  ],
  declarations: [MonthlyplannerothercallPage]
})
export class MonthlyplannerothercallPageModule {}
