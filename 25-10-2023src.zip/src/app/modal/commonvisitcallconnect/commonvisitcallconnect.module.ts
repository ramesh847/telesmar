import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CommonvisitcallconnectPageRoutingModule } from './commonvisitcallconnect-routing.module';

import { CommonvisitcallconnectPage } from './commonvisitcallconnect.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CommonvisitcallconnectPageRoutingModule
  ],
  declarations: [CommonvisitcallconnectPage]
})
export class CommonvisitcallconnectPageModule {}
