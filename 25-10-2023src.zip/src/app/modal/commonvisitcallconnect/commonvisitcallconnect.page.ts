import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController } from '@ionic/angular';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-commonvisitcallconnect',
  templateUrl: './commonvisitcallconnect.page.html',
  styleUrls: ['./commonvisitcallconnect.page.scss'],
  providers:[DatePipe]
})
export class CommonvisitcallconnectPage implements OnInit {
  Cusdata: any;
  enable:boolean=false
  customerName: any;
  customerMobile: any;
  customerId: any;
  purpose: any;
 // callerName: string;
  result: any;
  resout: any;
  clickcallID: any;
  obj:any={};
  endDate: any;
  currDate: any;
  clickcall:any= {};
  callerName:any;
callerMobile:any;
 
  statusResp: any;
  repStatus: any;
  EndCallobj:any={};
  interval: any;
  followupvisits:any = {};
  lat1: any;
  lng1: any;
  myvalue:boolean=false
  hidecalloutcome: boolean;
  DisLat: any;
  DisLong: any;
  CUSTOMER_ID;
RO_CODE;
START_TIME;
  voicerecording: string;
  firstname1: any;
  addbaselocno: string;
  dateToday1: string;
  purposeid: any;
  purposename: any;
  purposetype: any;
  cust_id: any;
  custDetails: any;
  followupvisitscustomerdata: any;
  firstWords: any[];
  businessunit: any;
  location: string;
  provider: string;
  status: string;
  status2: string;

  commonvisitcallconnect:boolean
commonvisitgrid:boolean
commonvisitupdate:boolean
  callPurpose: any;
  CBSCustomerID:any;
  mobileNumber:any;
  Purpose:any;
  search:any={}
  assignedvisit:any={}
  commonvisitdataonload: any;
  // firstWords: any[];
  datalength: any;
  callOutCome: any;
  fullname: any;
  save_custname: any;
  savemon: any;
  savefn: any;
  saveln: any;
  assignedvisitscustomerdata: any;
  branchid: any;
  usertype: any;
  userid: any;
  CallerId: any;
  username: any;
  usercode: any;
  cbsid: any;
  customername1: any;
  mobile1: any;
  calltype: any;
  callid: any;
  remarks1: any;
  saveIn: any;
  lastname1: any;
  responseid: any;
  BusinessUnit: number;
  customername: any;
  mobile: any;
firstname: any;
lastname: any;
remarks: any;

accountno: any;
amount: any;
Endtime: any;
Totime: any;
date: string;
jointcode: any;
latvalue: any;
langvalue: any;
address: any;



Collectiondate1: any;
collectionmode: any;
collectiondate: any;
nextcalldate1: any;
followuptime: any;
nextcalldate: any;
jointvisit: any;

getfollowdates: string;
getampm: string;
modifytime1: any;
modifytime2: string;

assignedvisitdata: any;

firstnamemodel: any;

getusername: any;
  rowid: any;
  clickid: any;
  getcaller:any;
  getcustomer:any;
  constructor(private Apiservice: ApiServiceService,
    private modalController: ModalController,public router:Router,private loader:ToastServiceService,
    private datepipe:DatePipe,
    private AlertService:AlertServiceService,private alert:AlertController) { }

  ngOnInit() {
let xyz=this.Apiservice.commonvisitcallconnectarray[0]
this.callNumber1(xyz)
  }
  clicknumberstar(num:any,status)
  {
    debugger
    if(status == 'ca'){
      this.getcaller= this.Apiservice.firstfivexxxx(num)
    }else
    {
      this.getcustomer= this.Apiservice.firstfivexxxx(num)
  
  }
}
  callNumber1(item){
 


    this.Cusdata = item
    console.log(this.Cusdata);


this.clickcall.callerName= window.localStorage['userName']
this.clickcall.callermobile=  window.localStorage['mobile']
this.clickcall.customerName=this.Cusdata.CustomerName;
this.clickcall.customerMobile= this.Cusdata.Mobile
// this.Cusdata.Mobile
this.clickcall.customerId=this.Cusdata.CBSCustomerID;
this.clickcall.purpose=this.Cusdata.Purpose;
this.obj.callerName=window.localStorage['userName']
// window.localStorage['mobile']
this.obj.callermobile=  window.localStorage['mobile']

    this.obj.customerName=this.Cusdata.CustomerName     
    
   this.obj.customerMobile=this.Cusdata.Mobile
  //  this.Cusdata.CONTACT_NO
  this.obj.customerId=this.Cusdata.CBSCustomerID;
    this.obj.purpose=this.Cusdata.Purpose;
    var currentDate=new Date();
    this.obj.currDate=currentDate
   // this.callermobile=localStorage.getItem('mobile');
    //this.usertype=localStorage.getItem('userType')

    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    if(this.obj.callermobile =='' || this.obj.callermobile ==undefined || this.obj.callermobile ==null ){
      this.AlertService.presentAlert("","CallerNumber Not Available")
    }else if(this.obj.customerMobile =='' || this.obj.customerMobile ==undefined || this.obj.customerMobile ==null ){
     this.AlertService.presentAlert("","CustomerNumber Not Available") 
   }else{
    this.Apiservice.endcallnrewfunction(branchid,userid,this.obj.callermobile,this.obj.customerMobile).then((res:any)=>{
      this.rowid=JSON.parse(JSON.parse(res.data))
         this.Apiservice.clickToCallFollowUP(this.obj.callermobile,this.obj.customerMobile,this.rowid).then((response:any)=> {
           debugger
           console.log(response.data)
           // this.hidespin($ionicLoading);
           this.result = JSON.parse(response.data);
           this.resout = JSON.parse( JSON.parse(this.result));
           if(this.resout.status == '200'){
             this.clickcallID = this.resout.data;
             this.Apiservice. autoclicktocallupdate(  this.clickcall.customerId,  this.clickcall.customerName,  this.clickcallID.id,  this.rowid,  "CommonVisit").then((res:any)=>{
              debugger
                           })
             this.callinterval();
             // this.CallConnectModal.show();
           }else{
             this.AlertService.presentAlert("",this.resout.message)
          
           }
       
       
         })
       })
   }


  }

  callinterval(){
    debugger
    this.interval = setInterval(() => {
      this.callResp();
          // clearInterval(this.interval)
        }, 10000);
  
   
  
    
  }
  stopCall(){
    debugger
    clearInterval(this.interval)
  }
  callResp(){
  debugger
  console.log(this.clickcallID.id);
  var id = this.clickcallID.id;
  this.Apiservice.callStatusFollowUp(id)
  .then((response:any)=> {
    debugger
  //  console.log(response)
    this.statusResp= JSON.parse(JSON.parse(JSON.parse(response.data)))
    this.repStatus = this.statusResp;
    //this.hidespin($ionicLoading);
    // console.log(JSON.parse( JSON.parse(response.data)).length);
    if(this.repStatus.data.length == 1){
  
  if((this.repStatus.data[0].status=="NOANSWER" || this.repStatus.data[0].status=="FAILED" || this.repStatus.data[0].status=="CONGESTION") && this.repStatus.data[0].status2==null) {
    this.stopCall();
  this.callResppopup(this.repStatus.data[0].status,id,"1")
  
  }else{
  
      console.log(this.repStatus.data[0].status2);
    if(this.repStatus.data[0].status2 != null){
      console.log(this.repStatus.data[0]);
      if(this.repStatus.data[0].status2 == 'ANSWER'){
        this.stopCall();
       // this.CallConnectModal.hide();
        console.log(this.currDate);
        this.EndCallobj.callerName=window.localStorage['userName'];
        this.EndCallobj.callerMobile=window.localStorage['mobile'];
        this.EndCallobj.customerName=this.Cusdata.CUSTOMER_NAME;
        this.EndCallobj.customerMobile=this.Cusdata.CONTACT_NO
        this.EndCallobj.customerId=this.Cusdata.CUSTOMER_ID;
        //this.EndCallobj.purpose=this.item.purpose_id;
        this.EndCallobj.purposeText= this.Cusdata.PURPOSE.split('/').join('-');
        this.EndCallobj.endStatus= 'A';
        //var currentDate= new Date();
        this.EndCallobj.currDate = this.repStatus.data[0].start_time;
        this.EndCallobj.endDate = this.repStatus.data[0].end_time;
        this.Endcall(this.EndCallobj);
        // this.End(this.Cusdata);
      }else{
       
  this.stopCall()
        this.callResppopup(this.repStatus.data[0].status2,id,"2")
  
  
      }
      
    }
  }
  }
  })
  
  
  }

  callResppopup(ans,id,leg2){
    debugger
this.stopCall()
                             // <<<---using ()=> syntax
      this.Apiservice.callStatusLead(id).then((res:any)=>{
  
        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
  
       if(res !='' && res.data == '"\\"\\""'){
    this.Apiservice.callStatusLead(id).then((res:any)=>{
  
      debugger
     res= JSON.stringify(res)
     res=JSON.parse(res)




    
      var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
      if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
        this.voicerecording='No Record'
      }else{
      this.voicerecording=xyz[0].recording.slice(28)
      }
      if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
      this.location="no record"
      }else{
        this.location=xyz[0].location
      }
      if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
        this.provider="no provider"
      }else{
        this.provider=xyz[0].provider
      }
      if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
        this.status="no status"
      }else{
       this.status=xyz[0].status
      }
      if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
        this.status2="no status"
      }else{
       this.status2=xyz[0].status2
      }
      
   debugger
   var branchid = window.localStorage['branchID'];
   var usertype = window.localStorage['userType'];
   var userid = window.localStorage['userID'];
   var purpose = 'Common Visit';
var objendcall={
  CustId :this.clickcall.customerId,
            CustName :this.clickcall.customerName,
            CustNumber :this.clickcall.customerMobile,
            strUserId :userid,
            strBranch :branchid,
            UserNumber :this.clickcall.callermobile,
            StartTime :xyz[0].start_time,
            Endtime :xyz[0].end_time,
            Purpose :purpose,
            duration :xyz[0].duration,
            bill :xyz[0].billsec,
            credit :xyz[0].credits,
            status :this.status,
            status1 :this.status2,
            rec :this.voicerecording,
            location :this.location,
            provider :this.provider,
            callid :id,
            rowid :this.rowid
}


      this.Apiservice.endcallconnectnewmethod(objendcall)
        .then((response:any)=> {
                debugger
            this.callresppopoutput(ans,leg2)
            
              },err=>{
                 if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
              })
              
            
            
              }
            )
  }else{
  
  
      
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        
     debugger
     var branchid = window.localStorage['branchID'];
     var usertype = window.localStorage['userType'];
     var userid = window.localStorage['userID'];
     var purpose = 'Common Visit';
  var objendcall={
    CustId :this.clickcall.customerId,
              CustName :this.clickcall.customerName,
              CustNumber :this.clickcall.customerMobile,
              strUserId :userid,
              strBranch :branchid,
              UserNumber :this.clickcall.callermobile,
              StartTime :xyz[0].start_time,
              Endtime :xyz[0].end_time,
              Purpose :purpose,
              duration :xyz[0].duration,
              bill :xyz[0].billsec,
              credit :xyz[0].credits,
              status :this.status,
              status1 :this.status2,
              rec :this.voicerecording,
              location :this.location,
              provider :this.provider,
              callid :id,
              rowid :this.rowid
  }
  
  
        this.Apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              this.callresppopoutput(ans,leg2)
              
                },err=>{
                   if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
              
              
                }
              }
              )
  



  
  }



  async callresppopoutput(ans,leg2){
  debugger

  if(ans == "FAILED" && leg2 == "2"){
    const alert = await this.alert.create({
      header: "Successfully Saved",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: '',
      buttons: [{ text     : 'Ok',
     
      
      handler:() => {
        this.clickcall={};
       
        this.stopCall();
      this. commonvisitclose()
      }
    }
    ]
    });
    
    await alert.present()
    return false
  }else{
  const alert = await this.alert.create({
    header: ans+' Would you like to update?',
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: '',
    buttons: [{ text     : 'Yes',
   
    
    handler:() => {
      this.clickcall={};
        //this.CallConnectModal.hide();
        // this.modelDissmiss()
        this.stopCall();
        console.log(this.Cusdata);
        this.EndCallobj.callerName=window.localStorage['userName'];
        this.EndCallobj.callerMobile=window.localStorage['mobile'];
        this.EndCallobj.customerName=this.Cusdata.CUSTOMER_NAME;
        this.EndCallobj.customerMobile=this.Cusdata.CONTACT_NO
        this.EndCallobj.customerId=this.Cusdata.CUSTOMER_ID;
        //this.EndCallobj.purpose=this.item.purpose_id;
        this.EndCallobj.purposeText= this.Cusdata.PURPOSE;
        this.EndCallobj.endStatus= 'I';
        //var currentDate= new Date();
        this.EndCallobj.currDate = this.repStatus.data[0].start_time;
        this.EndCallobj.endDate = this.repStatus.data[0].end_time;
        // this.Endcall(this.EndCallobj);
        // this.End(this.Cusdata);
   
  
          this.commonvisitshow(this.Cusdata)
    }
  },
  {
    text     : 'No',
   
    
    handler:() => {
      this.clickcall={};
     
        this.stopCall();
      this. commonvisitclose()
      
    }
  }
  ]
  });
  
  await alert.present()
  return false
}
  }
  Endcall1(obj){
    this.commonvisitshow(this.Cusdata)
  }
  Endcall(obj){
    debugger
    this.stopCall()
    if(this.resout=='' || this.repStatus.data.length==0){
      this.commonvisitshow(this.Cusdata)
    }else{
  if(this.repStatus.data[0].status2=='ANSWER'){
  
  
    this. clickid=this.clickcallID.id
    console.log(obj);
    if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
      var enDate= new Date();
      this.endDate =this.datepipe.transform(enDate,'yyyy-MM-dd hh-mm-ss')
      // this.endDate = $filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
      // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
      console.log(this.endDate);
      }else{
        var enDate= new Date(obj.endDate);
        this.endDate =this.datepipe.transform(enDate, 'yyyy-MM-dd hh-mm-ss');
        console.log(this.endDate);
      }
      var curDate= new Date(obj.currDate);
      this.currDate = this.datepipe.transform(curDate, 'yyyy-MM-dd hh-mm-ss');
      console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = 'Common Visit';
  
                            // <<<---using ()=> syntax
      this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{
  
        debugger
       res= JSON.stringify(res)
       res=JSON.parse(res)
    
       if(res !='' && res.data == '"\\"\\""'){
        this.Apiservice.callStatusLead(this.clickid).then((res:any)=>{
  
          debugger
         res= JSON.stringify(res)
         res=JSON.parse(res)
      
        
      
      
         if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
           
            this.stopCall();
            // console.log($scope.item);
            this.commonvisitshow(this.Cusdata)
          }else{
          
          if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
            // $scope.clickTocallConnect.hide();
            this.stopCall();
            // console.log($scope.item);
            this.commonvisitshow(this.Cusdata)
          }else{
          
          var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
          
          if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
            this.voicerecording='No Record'
          }else{
          this.voicerecording=xyz[0].recording.slice(28)
          }
          if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
          this.location="no record"
          }else{
            this.location=xyz[0].location
          }
          if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
            this.provider="no provider"
          }else{
            this.provider=xyz[0].provider
          }
          if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
            this.status="no status"
          }else{
           this.status=xyz[0].status
          }
          if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
            this.status2="no status"
          }else{
           this.status2=xyz[0].status2
          }
          var objendcall={
            CustId :obj.customerId,
                      CustName :obj.customerName,
                      CustNumber :obj.customerMobile,
                      strUserId :userid,
                      strBranch :branchid,
                      UserNumber :obj.callerMobile,
                      StartTime :xyz[0].start_time,
                      Endtime :xyz[0].end_time,
                      Purpose :purpose,
                      duration :xyz[0].duration,
                      bill :xyz[0].billsec,
                      credit :xyz[0].credits,
                      status :this.status,
                      status1 :this.status2,
                      rec :this.voicerecording,
                      location :this.location,
                      provider :this.provider,
                      callid :this.clickid,
                      rowid :this.rowid
          }
          
          this.Apiservice.endcallconnectnewmethod(objendcall)
            .then((response:any)=> {
                    debugger
                
                    // obj.endStatus == 'I'
                    if(obj.endStatus == '0'){
                 
                   
        
                    this.endcallpopup()
        
                  }else{
                    debugger
                   this.clickcall={};
                         
                        this.stopCall();
                          // console.log($scope.item);
                          this.commonvisitshow(this.Cusdata)
                  }
                  },err=>{
                     if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                  })
                  
                
                }
                  }
                })
       }
    
    else{
       if(res=='' || JSON.parse(JSON.parse(JSON.parse(res.data)))==''){
         
          this.stopCall();
          // console.log($scope.item);
          this.commonvisitshow(this.Cusdata)
        }else{
        
        if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
          // $scope.clickTocallConnect.hide();
          this.stopCall();
          // console.log($scope.item);
          this.commonvisitshow(this.Cusdata)
        }else{
        
        var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
        if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
          this.voicerecording='No Record'
        }else{
        this.voicerecording=xyz[0].recording.slice(28)
        }
        if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
        this.location="no record"
        }else{
          this.location=xyz[0].location
        }
        if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
          this.provider="no provider"
        }else{
          this.provider=xyz[0].provider
        }
        if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
          this.status="no status"
        }else{
         this.status=xyz[0].status
        }
        if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
          this.status2="no status"
        }else{
         this.status2=xyz[0].status2
        }
        var objendcall={
          CustId :obj.customerId,
                    CustName :obj.customerName,
                    CustNumber :obj.customerMobile,
                    strUserId :userid,
                    strBranch :branchid,
                    UserNumber :obj.callerMobile,
                    StartTime :xyz[0].start_time,
                    Endtime :xyz[0].end_time,
                    Purpose :purpose,
                    duration :xyz[0].duration,
                    bill :xyz[0].billsec,
                    credit :xyz[0].credits,
                    status :this.status,
                    status1 :this.status2,
                    rec :this.voicerecording,
                    location :this.location,
                    provider :this.provider,
                    callid :this.clickid,
                    rowid :this.rowid
        }
        
        this.Apiservice.endcallconnectnewmethod(objendcall)
          .then((response:any)=> {
                  debugger
              
                  // obj.endStatus == 'I'
                  if(obj.endStatus == '0'){
               
                 
      
                  this.endcallpopup()
      
                }else{
                  debugger
                 this.clickcall={};
                       
                      this.stopCall();
                        // console.log($scope.item);
                        this.commonvisitshow(this.Cusdata)
                }
                },err=>{
                   if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
                })
                
              
              }
                } }
              })
  
    
   
   
  }else{
    this.commonvisitshow(this.Cusdata)
  }
}
  }
  
  async endcallpopup(){
  debugger
  const alert = await this.alert.create({
    header: 'You have ended the call explicitly. would you like to update?',
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: '',
    buttons: [{ text     : 'Yes',
   
    
    handler:() => {
      this.clickcall={};
      // this.CallConnectModal.hide();
      // this.alert.dismiss()
       this.stopCall();
       console.log();
       this.End(this.Cusdata);
      //  this.commonvisitshow(this.Cusdata)
    }
  },
  {
    text     : 'No',
   
    
    handler:() => {
      this.clickcall={};
      //this.CallConnectModal.hide();
      this.stopCall();
      // this.alert.dismiss()
       console.log(this.Cusdata);
      //  this.route.navigate(['myfollowupvisitendmodel'])
      // this.commonvisitshow(this.Cusdata)
       //this.followupcallsUpdmodal(this.item);
    }
  }
  ]
  });
  await alert.present()
  }
  
  
  
  End(obj) {
  
      this.commonvisitshow(obj)
    // } catch (err) {
    //   console.log(err);
    // }
  
  }
  commonvisitshow(items){
    this.Apiservice.commonvisitupdatearray=[]
    this.Apiservice.commonvisitupdatearray.push(items)
    this.router.navigateByUrl('/commonvisit-update-modal')
  }
  commonvisitclose(){
    this.router.navigateByUrl('/commonvisit')
  }
}
