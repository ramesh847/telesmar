import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CommonvisitcallconnectPage } from './commonvisitcallconnect.page';

const routes: Routes = [
  {
    path: '',
    component: CommonvisitcallconnectPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommonvisitcallconnectPageRoutingModule {}
