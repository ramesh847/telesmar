import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { BranchreportbrangePage } from '../branchreportbrange/branchreportbrange.page';

@Component({
  selector: 'app-branchreportsummary',
  templateUrl: './branchreportsummary.page.html',
  styleUrls: ['./branchreportsummary.page.scss'],
  providers:[Idle]
})
export class BranchreportsummaryPage implements OnInit {
  Cusdata: any;
  viewUserid: any;
  viewbranchid: any;
  viewuserType: any;
  data: any={};
  custID: number;
  datarespview: any;
  datarespviewlength: any;
  idleState: string;

  constructor(private apiService:ApiServiceService,
    private navParams: NavParams,
    private alertService: AlertServiceService,
    public modalController: ModalController,private loader:ToastServiceService,public router:Router,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          // (this.idleState = countdown.toString() )
          {
            let idleState = countdown
            let minutes = Math.floor((idleState)/ 60);
            let extraSeconds = (idleState) % 60;
           let minutes1 = minutes < 10 ? "0" + minutes : minutes;
           let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
           this.idleState=minutes1 +':'+ extraSeconds1
           console.log(this.idleState)
          }
      ); }

  ngOnInit() {
    this.Cusdata = this.navParams.get('Data');
    this.reportCust(this.Cusdata)
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  reportCust (item){
    debugger
     //  console.log(item);
       // this.showspin();
       this.viewUserid = item.CallerId;
       this.viewbranchid = item.BranchId;
       this.viewuserType = item.UserType;
       if(this.data.customerid == undefined){
       this. custID = 0 ;
       }else{
       this. custID = this.data.customerid ;
       }
       this.loader.presentLoading('')
       this.apiService.getviewreportGrid(this.viewUserid, this.viewbranchid, this.viewuserType, this.custID)
       .then((response:any) =>{
         debugger
         this.loader.dismissLoading()
         //  console.log(response);
           // this.hidespin();
           response = JSON.parse(JSON.parse(response.data));
           this.datarespview = response.Table;
           this.datarespviewlength=this.datarespview.length
         //  console.log(this.datarespview)
           // this.viewReportaction.show();
       },err=>{
         this.loader.dismissLoading()
         this.alertService.presentAlert("Error",err.status)
       })
      
        
   }
  getViewReport() {
  debugger
     var userid = this.viewUserid;
     var branchid = this.viewbranchid;
     var userType =  this.viewuserType;
     if(this.data.customerid == undefined){
     this. custID = 0 ;
     }else{
     this. custID = this.data.customerid ;
     }
     this.apiService.getviewreportGrid(userid, branchid, userType, this.custID)
     .then((response:any)=> {
       //  console.log(response);
       debugger
         // this.hidespin();
         response =JSON.parse(JSON.parse(response.data));
         this.datarespview = response.Table;
         this.datarespviewlength=response.Table.length
       //  console.log(this.datarespview)
     },err=>{
       this.alertService.presentAlert("Error",err.status)
     })
    
 }
 goToMyplannerPage(){
   this.modalController.dismiss()
 }
 async branchreportCustSummary1(item){
   debugger
  //  this.apiService.branchreportsummary=[]
  // this.apiService.branchreportsummary.push(item)
  // this.router.navigateByUrl('/branchreportbrange')  

  const modal = await this.modalController.create({
    component: BranchreportbrangePage,
    componentProps: { Data: item }
  });
  return await modal.present();
 }
}
