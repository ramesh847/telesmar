import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssignedcommonupdatePageRoutingModule } from './assignedcommonupdate-routing.module';

import { AssignedcommonupdatePage } from './assignedcommonupdate.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssignedcommonupdatePageRoutingModule
  ],
  declarations: [AssignedcommonupdatePage]
})
export class AssignedcommonupdatePageModule {}
