import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-assignedcommonupdate',
  templateUrl: './assignedcommonupdate.page.html',
  styleUrls: ['./assignedcommonupdate.page.scss'],
  providers:[DatePipe,Idle]
})
export class AssignedcommonupdatePage implements OnInit {
  savebool:boolean
  assigned:any={};
  Cusdata1: any;
  Purpose: any;
  purpose: string;
  hidecalloutcome:boolean;
  customerid: any;
  purposeid: any;
  enable:boolean;
  assignedcallscustomerdata: any;
  firstWords: any[];
  firstname1: any;
  myvalue:boolean;
  getusername: any;
  Collectiondate1: any;
  cbsid: any;
  mobile1: any;
  calltype: any;
  remarks1: any;
  lastname1: any;
  customername1: any;
  responseid: any;
  callid: any;
  BusinessUnit: number;
  mobile: any;
  customername: any;
  firstname: any;
  lastname: any;
  remarks: any;
  collectionmode: string;
  collectiondate: string;
  accountno: any;
  amount: any;
  nextcalldate1: any;
  followuptime: any;
  getfollowdates: string;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  nextcalldate: string;
  jointvisit: string;
  jointcode: any;
  lat1: any;
  lng1: any;
  latvalue: any;
  langvalue: any;
  address: any;
  branchid: any;
  usertype: any;
  userid: any;
  CallerId: any;
  username: any;
  usercode: any;
  depositVal: any;
  casaVal: any;
  AdvanceVal: any;
  InsuranceVal: any;
  success: any[];
  commoncallsdataonload: any[];
  commoncallsdata: any[];
  loaddata: boolean;
  custid: string;
  date: any;
  date_a: string;
  datatofilter: any[];
  callout: any;
  jointvisitChecked: boolean = false;
  idleState: string;
  constructor(private loader:ToastServiceService,public modalController: ModalController,
    private datepipe:DatePipe,private Apiservice:ApiServiceService,
    // private navParams:NavParams,
    private AlertService:AlertServiceService,public route:Router,private alert:AlertController,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.route.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>{
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      ); }

  ngOnInit() {
    debugger
   this. assigned.JointVisit=true
    this. branchid = window.localStorage['branchID'];
    this. usertype = window.localStorage['userType'];
    // this. userid = window.localStorage['userID'];
    this. usercode = window.localStorage['userCode'];
    this. CallerId = window.localStorage['userID'];
    this. username = window.localStorage['userName'];
    this.Cusdata1 =this.Apiservice.assignedcommoncallarray
    let Cusdata=this.Cusdata1[0]
    this.getcalloutcome()
    this.commoncallsUpdmodal(Cusdata)
// this.reset()
  }
reset(){
  this.idle.watch()
}
  verifytime() {
    debugger
    var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
    this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
    if (this.getfollowdates <= date) {
      this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
    //  this.followupvisits.followdate=''
    //  this.followupvisits.followtime=''
    }
    
  }
  commoncallsUpdmodal(obj) {
    debugger
    console.log(obj)
    this.assigned.custname = obj.firstname;
    this.assigned.fullname = obj.CustomerName;
    this.Purpose = obj.Purpose;
    console.log(this.Purpose)

//Condition to hide call closed option for NPA followup and VVIP Visits purposes
if(this.Purpose != "NPA followup" && this.Purpose != "VVIP Visits"){
  this.hidecalloutcome = false;
}else{
  this.hidecalloutcome = true;
}



    //address
    this.assigned.addressname ="";
        //  $("#showdivscalls").css("display", "none");

    this.assigned.current = "";
    this.assigned.collected_date = "";
    this.assigned.collected_accno = "";
    this.assigned.collectamount = "";
    this.assigned.calloutcome = "";
    this.assigned.followdate = "";
    this.assigned.followtime = "";
    this.assigned.calltype = 'T';
    this.assigned.JointVisit = "";
    this.assigned.jointusername = "";
    this.assigned.jointcode = "";
    this.assigned.remarks = "";
    var customerid = obj.CBSCustomerID;
    this.customerid = obj.CBSCustomerID;
    window.localStorage['Customerid'] = obj.CBSCustomerID;
    window.localStorage['Callid'] = obj.CallID;

    window.localStorage['PurposeId'] = obj.PurposeId;
    this.purposeid = obj.PurposeId;



    // this.UpdateModal.show();
    if (customerid == null) {

      this.enable = false;

    }
    if (customerid != null) {
      this.enable = true;
      this.Apiservice.getcustomerdetails(customerid)
        .then((response:any)=> {
          debugger
          response = JSON.parse(JSON.parse(response.data));
          // response = JSON.parse(response);
          this.assignedcallscustomerdata = JSON.parse(response);
          if(this.assignedcallscustomerdata != "" && this.assignedcallscustomerdata != undefined)
          {
          this.assigned.customerid = customerid;
          this.assigned.firstname = this.assignedcallscustomerdata[0].Nfirstname;
          this.assigned.lastname = this.assignedcallscustomerdata[0].Nlastname;
          this.assigned.mobile = this.assignedcallscustomerdata[0].Nmobile;
          this.assigned.resphnno = this.assignedcallscustomerdata[0].Nresidencephone;
          this.assigned.email = this.assignedcallscustomerdata[0].Nemail;
          this.assigned.Purpose = this.assignedcallscustomerdata[0].Purpose;
console.log(this.assigned);

          this.firstWords = [];

          var firstname = [];

          for (let i = 0; i < this.assignedcallscustomerdata.length; i++) {

            firstname = this.assignedcallscustomerdata[i].Nfirstname;

            this.firstWords.push(firstname[0]);
            this.assignedcallscustomerdata[i].firstname = this.firstWords[i];
            this.firstname1 = this.assignedcallscustomerdata[i].firstname;

          }
debugger
          console.log(this.assignedcallscustomerdata[0].Add1);
          if(this.assignedcallscustomerdata[0].Add1 != undefined || this.assignedcallscustomerdata[0].Add2 != undefined || this.assignedcallscustomerdata[0].Add3 != undefined || this.assignedcallscustomerdata[0].Add4 != undefined || this.assignedcallscustomerdata[0].PIN != undefined){
            var respAdd1= this.assignedcallscustomerdata[0].Add1;
            var add1 = respAdd1.replace("/", "-");
            console.log(add1);
            var respAdd2= this.assignedcallscustomerdata[0].Add2;
            var add2 = respAdd2.replace("/", "-");
            console.log(add1);
            
          this.assigned.addressname = add1.replaceAll(' ','')+' '+add2.replaceAll(' ','')+' '+this.assignedcallscustomerdata[0].Add3+' '+this.assignedcallscustomerdata[0].Add4+' '+this.assignedcallscustomerdata[0].PIN;
          console.log(this.assigned.addressname);
          }
          if(this.assigned.addressname != "" && this.assigned.addressname != undefined)
          { 
            console.log(this.assigned.addressname);
           this.myvalue = true;
           //this.data.selectele='P';
          //  this.setlatlong(this.assigned.addressname);
          }

        }

        },err=>{
          if(err.status == '-4'){
            this.AlertService.presentAlert("Error", "Request Time Out")
          }else if(err.status == '-3'){
            this.AlertService.presentAlert("Error","Host could not be resolved")
          }else
          {
          
          this.AlertService.presentAlert("Error", err.status)
          }
        })
       
    }
           // console.log(obj);
          //  console.log(this.assigned.addressname);
          //  if(this.assigned.addressname != '' &&this.assigned.addressname != 'undefined' &&this.assigned.addressname != undefined){
          //    this.typeshowmap(this.lat1, this.lng1,this.assigned.addressname)
          //  }
  };



  checkboxClick(Event){
    debugger
    console.log(Event);
    
    if(Event == true){
      this.assigned.JointVisit = 'N';
    }else{
      this.assigned.JointVisit = "Y";
    }
    // console.log(this.followupvisits.JointVisit)
  }
  checkusercode(val) {
    var usercode = val;
    var branchid = window.localStorage['branchID'];
  
    // this.showspin();
    this.Apiservice.getusername(usercode, branchid)
      .then( (response:any)=> {
        // this.hidespin();
        debugger
        console.log(response);
        response = JSON.parse(JSON.parse(response.data));
        if (response == "This User Not in this Branch") {
  
          this.AlertService.presentAlert("","Please Enter The Valid Emp Code")
          return false;
          this.assigned.jointusername = "";
         this.assigned.jointcode = "";
  
        } else {
          this.getusername = response;
         this.assigned.jointusername = this.getusername;
          console.log(this.getusername)
        }
  
      })
      
  }
  getcalloutcome() {
    // this.showspin();
    this.Apiservice.getcalloutcome1()
      .then((response:any) =>{
        console.log(response);
        this.purposeid = response.PurposeId;
        response = JSON.parse(JSON.parse(response.data));
        this.callout = response;
        // this.hidespin()


      })
      // .error(function(response) {
      //   console.log(response);
      //    count++; 
      //     if(count<=2){
      //       this.getcalloutcome();
      //      }else{
      //       this.hidespin();
      //       this.showToast('Server Error, Call Outcome is not loaded.' )
      //    }
        
      // });
  }
  savecommoncalls(obj) {
    debugger
    var usercode = window.localStorage['userCode'];
    var username = window.localStorage['userName'];
    var branchid = window.localStorage['branchID'];
    var CallerId = window.localStorage['userID'];
    var cbsid = window.localStorage['Customerid'];
    console.log(cbsid)

    var mobile1 = this.assigned.mobile;
    var calltype = this.assigned.calltype;
    var remarks1 = this.assigned.remarks;
    var firstname1 = this.assigned.firstname;
    var lastname1 = this.assigned.lastname;
    var purpose = window.localStorage['PurposeId'];
    var customername1 = this.assigned.firstname;
    var responseid = this.assigned.calloutcome;
    var callid = window.localStorage['Callid'];
    var BusinessUnit = 0;
    console.log(responseid)


    if (mobile1 == "") {

      var mobile = null;
    } else {
      var mobile = mobile1;
    }

    if (customername1 == "") {

      var customername = null;
    } else {
      var customername = customername1;
    }


    if (firstname1 == "") {

      var firstname = null;
    } else {
      var firstname = firstname1;
    }

    if (lastname1 == "") {

      var lastname = null;
    } else {
      var lastname = lastname1;
    }

    if (remarks1 == "") {

      var remarks = null;
    } else {
      var remarks = remarks1;
    }

    if (purpose == "5" && this.assigned.current == "Y") {
      if ((this.assigned.collected_date == null || this.assigned.collected_date == undefined || this.assigned.collected_date == "") || (this.assigned.collected_accno == "" || this.assigned.collected_accno == undefined || this.assigned.collected_accno == null) || (this.assigned.collectamount == undefined || this.assigned.collectamount == "" || this.assigned.collectamount == null)) {
this.AlertService.presentAlert("","Fill All Details Of Amount Collected")
return false
       

      } else {
        var collectionmode = "Y";
        this.Collectiondate1 = this.assigned.collected_date;
        var collectiondate = this.datepipe.transform(this.Collectiondate1, 'yyyy-MM-dd');
        var accountno = this.assigned.collected_accno;
        var amount = this.assigned.collectamount;
      }

    }
    console.log(this.assigned.current)
    console.log(this.assigned.JointVisit)

    if (purpose != "5") {
       collectionmode = null;

    }

    if (purpose == "5") {
      if (this.assigned.current == "" || this.assigned.current == undefined || this.assigned.current == null || this.assigned.current == "N") {
        collectionmode = null;

      }
    }

    if (collectionmode == null) {
      var accountno = null;
      var amount = null;
      collectiondate = null;
    }


    if (this.assigned.calloutcome == "" || this.assigned.calloutcome == undefined || this.assigned.calloutcome == null) {
this.AlertService.presentAlert("","Select Call OutCome")

     
      return false;
    }



    if (responseid == "2") {
      if ((this.assigned.followdate == null || this.assigned.followdate == "" || this.assigned.followdate == undefined) || (this.assigned.followtime == null || this.assigned.followtime == undefined || this.assigned.followtime == "")) {
        this.AlertService.presentAlert("","Provide Followup Details")
      
        return false;


      }  else {
        var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        this.getfollowdates = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
        if (this.getfollowdates <= date) {
        
          this.AlertService.presentAlert("","The Call Back Date should not be same and less than current date")
        return false
        }else{
  
  
  
        this.nextcalldate1 = this.datepipe.transform( this.assigned.followdate,'YYYY-MM-dd')
      //  $filter('date')(this.followupvisits.followdate, 'yyyy-MM-dd');
  
      var time = this.assigned.followtime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.assigned.followtime];
  
      if (time.length > 1) { // If time format correct
        time = time.slice (1);  // Remove full string match value
        this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
        time[0] = +time[0] % 12 || 12; 
        time[1]="."// Adjust hours
      }
      this.modifytime1= time.join ('');
      if(this.getampm=="AM"){
        this.modifytime2= this.modifytime1+' '+"AM"
      }else{
        this.modifytime2= this.modifytime1+' '+"PM"
      }
    
          var nextcalldate = this.nextcalldate1 + ' ' +  this.modifytime2;
          
     
     
  
       
      }
    }

    }

    if (responseid != "2") {
      nextcalldate = " ";
      //          var Endtime = null;
      // var Totime = null;

    }

    if (this.assigned.calltype == "" || this.assigned.calltype == undefined || this.assigned.calltype == null) {
this.AlertService.presentAlert("","Select Call Type")

     
      return false;

    }

    if (this.assigned.calltype == "P" && this.assigned.JointVisit == "Y") {
      if (this.assigned.jointcode == null || this.assigned.jointcode == "" || this.assigned.jointcode == undefined) {
        this.AlertService.presentAlert("","Enter Joint Usercode")
      
        return false;
      } else {
        var jointvisit = "Y";
        var jointcode = this.assigned.jointcode;

      }

    }

    if (this.assigned.calltype == "P") {
      if (this.assigned.JointVisit == "" || this.assigned.JointVisit == null || this.assigned.JointVisit == undefined || this.assigned.JointVisit == "N") {

        jointvisit = null;
      }
    }

    if (this.assigned.calltype != "P") {

      jointvisit = null;

    }

    if (jointvisit == null) {
      var jointcode = null;
    }

    console.log(this.Purpose)
    if (this.Purpose == 'Lead Generation') {

      if ((this.assigned.casa != "" && this.assigned.casa != undefined) || (this.assigned.deposits != "" && this.assigned.deposits != undefined) || (this.assigned.advance != "" && this.assigned.advance != undefined) || (this.assigned.insurance != "" && this.assigned.insurance != undefined)) {
        console.log(this.assigned.casa);
        var casaVal = this.assigned.casa;
        console.log(casaVal)
        var depositVal = this.assigned.deposits;
        console.log(depositVal)
        var AdvanceVal = this.assigned.advance;
        console.log(AdvanceVal)
        var InsuranceVal = this.assigned.insurance;
        console.log(InsuranceVal)

      } else {
        this.AlertService.presentAlert("","Fill Details Of Expected Business")
       
        return false;
      }

      if (this.assigned.casa == undefined || this.assigned.casa == "") {

        casaVal = 0;
      } else {
        casaVal = this.assigned.casa;
      }
      if (this.assigned.deposits == undefined || this.assigned.deposits == "") {
        depositVal = 0;
      } else {
        depositVal = this.assigned.deposits;
      }

      if (this.assigned.advance == undefined || this.assigned.advance == "") {
        AdvanceVal = 0;
      } else {
        AdvanceVal = this.assigned.advance;
      }

      if (this.assigned.insurance == undefined || this.assigned.insurance == "") {
        InsuranceVal = 0;
      } else {
        InsuranceVal = this.assigned.insurance;
      }

    } else {
      casaVal = 0;
       depositVal = 0;
       AdvanceVal = 0;
       InsuranceVal = 0;
    }

    var Endtime = null;
    var Totime = null;
    console.log(this.assigned.followdate)
    console.log(this.assigned.followtime)
    console.log(this.assigned.JointVisit)

    if (this.assigned.calltype == "P") {

      if ((this.assigned.addressname == "") || ((this.assigned.addressname == 'undefined') || (this.assigned.addressname == undefined))) {
        console.log(this.assigned.addressname)
        this.AlertService.presentAlert("","Enter Your Location")
        
        return false;

      } else {
        //alert(latvalue);
        var latvalue = this.lat1;
        //console.log(latvalue)
        var langvalue = this.lng1;
        //console.log(latvalue)
        var address = this.assigned.addressname;
      }


    } else {
      var latvalue = null;
      var langvalue = null;
      var address = null;
    }
    console.log(purpose);
    if(lastname == '.') lastname = null;
    console.log(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
if (this.assigned.calltype == "P") {

  console.log("call type is pv");
   this.savebool=true
  this.Apiservice.updatecommoncalls(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
  .then((response:any)=> {
    debugger
    // this.hidespin($ionicLoading);
    console.log(response);
    response =JSON.parse( JSON.parse(response.data));
    var success:any = [];
    success = response;

     if(success!="")
    {

      if (success[0].response == 1) {

        this.statusmethod(success[0].Column1)
        
        
            } 
            else {
              // this.savemethod()
              console.log(success, latvalue, langvalue, address,purpose, cbsid)
              this.Apiservice.saveaddress(success, latvalue, langvalue, address,purpose,cbsid)
      .then((response:any)=> {
        debugger
        console.log(response)
         if(JSON.parse(response.data) == '"Yes"')
              {
                this.savemethod()
             
    
              }
    
              else{
    
                this.AlertService.presentAlert("","Error While Saving")
          
    
       
              }
    
      })
           
            }


      
//debugger;
 



    }
    
    
  })

    
    // this.UpdateModal.hide();
}
else
{
  debugger
  console.log("call type is not pv");
  
  
  this.Apiservice.updatecommoncalls(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit, depositVal, casaVal, AdvanceVal, InsuranceVal)
  .then((response:any)=> {
    debugger
    // this.hidespin($ionicLoading);
    // console.log(response);
    response = JSON.parse(JSON.parse(response.data));
    var success = [];
    success = response;


    if (success[0].response == 1) {

this.statusmethod(success[0].Column1)
    
   

    } 
    else {
      this.savemethod()
    
   
    }

    // this.getCommoncallsonload();
    
  }) 
}

  }

async statusmethod(msg){
  const alert = await this.alert.create({
    // header: 'You have ended the call explicitly. would you like to update?',
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status '+msg,
    buttons: [{ text     : 'Ok',
   
    
    handler:() => {
      debugger
      if(this.Cusdata1[1].close=="endassigncommoncallconnect" ||this.Cusdata1[1].close=="endassigncommoncallconnectpage"){
        this.route.navigateByUrl('/commoncall')
      }

    }
  },

]
  });
  await alert.present()
}
   async savemethod(){
    const alert = await this.alert.create({
      // header: 'You have ended the call explicitly. would you like to update?',
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: 'Saved Successfully',
      buttons: [{ text     : 'Ok',
     
      
      handler:() => {
        debugger
        if(this.Cusdata1[1].close=="endassigncommoncallconnect" ||this.Cusdata1[1].close=="endassigncommoncallconnectpage"){
          this.route.navigateByUrl('/commoncall')
        }

      }
    },
  
  ]
    });
    await alert.present()
    }
  searchCommonCalls(purposeid,custid){
    debugger
    localStorage.setItem('CCpurposeselected',purposeid);
    this.commoncallsdataonload = [];
  
    this.commoncallsdata = [];
    this.loaddata = true;
    if(this.purposeid == ""){
     this. purposeid = 0;
    }
    if(custid == ''|| custid == 'undefined'){
      custid=" ";
    }

    this.Apiservice.getcomcalls(this.purposeid, this.branchid, this.calltype, custid)
      .then((response:any) =>{
        debugger
        // $ionicLoading.hide();
        console.log(response);
        if(response != ""){
          response = JSON.parse(JSON.parse(response.data));
        }
        
        this.commoncallsdataonload = response;
        //console.log(this.commoncallsdataonload)
        var firstname = [];
        this.firstWords = [];
  
        for (let i = 0; i < this.commoncallsdataonload.length; i++) {
          firstname = this.commoncallsdataonload[i].CustomerName.split(" ");
          this.firstWords.push(firstname[0]);
          this.commoncallsdataonload[i].firstname = this.firstWords[i];
         this. date = this.commoncallsdataonload[i].ToCallDate.split('/');
         this. date_a = this.date[1]+'/'+this.date[0]+'/'+this.date[2];
          this.commoncallsdataonload[i].tofiltercalldate = this.date_a;
        }
        this.datatofilter = this.commoncallsdataonload;
     
        console.log(this.commoncallsdataonload)
        // $ionicLoading.hide();
      })
   
  
  
  }
  modelDissmiss(){
    debugger
    if(this.Cusdata1[1].close=="endassigncommoncallconnect" ||this.Cusdata1[1].close=="endassigncommoncallconnectpage"){
      this.route.navigateByUrl('/commoncall')
    }

   
  }
}


