import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ManagerheatmapdetailPageRoutingModule } from './managerheatmapdetail-routing.module';

import { ManagerheatmapdetailPage } from './managerheatmapdetail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ManagerheatmapdetailPageRoutingModule
  ],
  declarations: [ManagerheatmapdetailPage]
})
export class ManagerheatmapdetailPageModule {}
