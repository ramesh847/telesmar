import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManagerheatmapdetailPage } from './managerheatmapdetail.page';

const routes: Routes = [
  {
    path: '',
    component: ManagerheatmapdetailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagerheatmapdetailPageRoutingModule {}
