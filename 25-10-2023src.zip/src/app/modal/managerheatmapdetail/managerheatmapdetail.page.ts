import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-managerheatmapdetail',
  templateUrl: './managerheatmapdetail.page.html',
  styleUrls: ['./managerheatmapdetail.page.scss'],
  providers:[Idle]
})
export class ManagerheatmapdetailPage implements OnInit {
  username: any;
  code: any;
  branchid: any;
  staffmapdata: any;
  userid: any;
  UserType: any;
  showitemcard: boolean = false
  showitemlist: boolean = true
  assignstartdate: any;
  assignstartend: any;
  staffmapdatalength: any;
  idleState: string;
  constructor(private loader:ToastServiceService,
    private Alertservice:AlertServiceService,
    private Apiservice:ApiServiceService,public route:Router,
    private navParams: NavParams,
    public modalController: ModalController,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.route.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          (this.idleState = countdown.toString() )
      );}

  ngOnInit() {
    debugger
    this.userid = window.localStorage['userID']
    this.branchid = window.localStorage['branchID']
    this.UserType = window.localStorage['userType']
    let data = this.navParams.get('Data');
    this.username=data.UserName;
    this.code=data.UserCode;

    this.getstaffheatmapdata(data)
// this.reset()
  }
reset(){
  this.idle.watch()
}

      getstaffheatmapdata(obj){
  
  this.loader.presentLoading('')
        this.Apiservice.getstaffheatmap(obj.USERID, this.branchid)
            .then((response:any)=> {
              
              this.loader.dismissLoading()
              // this.username=obj.UserName;
              // this.code=obj.UserCode;
                response = JSON.parse(JSON.parse(response.data))
                console.log(response)
                this.staffmapdata = response;
this.staffmapdatalength=response.length
            },err=>{
              this.Alertservice.presentAlert("Error",err.status)
            })
           
            this.Apiservice.AssigneDdate()
            .then((response:any) =>{
              debugger
                response = JSON.parse(JSON.parse(response.data));
                console.log(response);
               this.assignstartdate =response[0].EndDate;
               this.assignstartend=response[0].StartDate;
            })
        // $('.userDetails' + index_val).toggle();
    }
    modeldissmiss() {
      this.modalController.dismiss()
    }
    cardshowbranch() {
      this.showitemcard = true
      this.showitemlist = false
    }
    tableshowbranch() {
      this.showitemcard = false
      this.showitemlist = true
    }

}
