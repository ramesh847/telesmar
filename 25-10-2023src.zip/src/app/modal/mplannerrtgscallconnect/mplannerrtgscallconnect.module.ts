import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MplannerrtgscallconnectPageRoutingModule } from './mplannerrtgscallconnect-routing.module';

import { MplannerrtgscallconnectPage } from './mplannerrtgscallconnect.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MplannerrtgscallconnectPageRoutingModule
  ],
  declarations: [MplannerrtgscallconnectPage]
})
export class MplannerrtgscallconnectPageModule {}
