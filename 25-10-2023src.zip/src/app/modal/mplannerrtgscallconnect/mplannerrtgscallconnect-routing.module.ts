import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MplannerrtgscallconnectPage } from './mplannerrtgscallconnect.page';

const routes: Routes = [
  {
    path: '',
    component: MplannerrtgscallconnectPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MplannerrtgscallconnectPageRoutingModule {}
