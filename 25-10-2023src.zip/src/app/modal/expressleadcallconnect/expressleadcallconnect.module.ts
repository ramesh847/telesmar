import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ExpressleadcallconnectPageRoutingModule } from './expressleadcallconnect-routing.module';

import { ExpressleadcallconnectPage } from './expressleadcallconnect.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ExpressleadcallconnectPageRoutingModule
  ],
  declarations: [ExpressleadcallconnectPage]
})
export class ExpressleadcallconnectPageModule {}
