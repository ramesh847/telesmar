import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CommoncallconnectPage } from './commoncallconnect.page';

const routes: Routes = [
  {
    path: '',
    component: CommoncallconnectPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommoncallconnectPageRoutingModule {}
