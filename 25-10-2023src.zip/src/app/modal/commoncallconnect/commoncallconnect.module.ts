import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CommoncallconnectPageRoutingModule } from './commoncallconnect-routing.module';

import { CommoncallconnectPage } from './commoncallconnect.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CommoncallconnectPageRoutingModule
  ],
  declarations: [CommoncallconnectPage]
})
export class CommoncallconnectPageModule {}
