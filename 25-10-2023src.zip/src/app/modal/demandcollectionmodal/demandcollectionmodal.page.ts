import { Component, OnInit } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { NavParams } from '@ionic/angular';
import * as moment from "moment"; 
import { Pipe, PipeTransform } from "@angular/core";
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-demandcollectionmodal',
  templateUrl: './demandcollectionmodal.page.html',
  styleUrls: ['./demandcollectionmodal.page.scss'],
  providers:[DatePipe,Idle]
})
export class DemandcollectionmodalPage implements OnInit {
  savebool:boolean
  isHidden: boolean = true;
data:any = {}
  callOutCome: any;
  getusername: any;
  businessunit: any;
  customeractiondata: any;
  enable: boolean;
  Npacustomerdata: any;
  firstWords: any[];
  firstname1: any;
  myvalue: boolean;
  purposeID: any;
  purpose: any;
  Collectiondate1: any;
  nextcalldate1: string;
  followuptime: string;
  getfollowdates: string;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  Cusdata1: any;
  idleState: string;
  constructor(private Alertservice:AlertServiceService,
   
    private Apiservice:ApiServiceService,private modalController:ModalController,
    private loader:ToastServiceService,private datepipe:DatePipe,public route:Router,
    private alert1:AlertController,private idle:Idle) {
     // sets an idle timeout of 5 seconds, for testing purposes.
     this.idle.setIdle(5);
     // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
     this.idle.setTimeout(15*60);
     // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
     this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
 
     this.idle.onIdleEnd.subscribe(() => (this.idleState = "No longer idle."));
     this.idle.onTimeout.subscribe(() => {
       // this.idleState = "Timed out!";
       // this.timedOut = true;
       this.route.navigate(['sessionout'])
     });
     this.idle.onIdleStart.subscribe(
       () => (this.idleState = "")
     );
     this.idle.onTimeoutWarning.subscribe(
       countdown =>
         (this.idleState = countdown.toString() )
     );
   }

  ngOnInit() {
     this.Cusdata1=this.Apiservice.demandcollectionarray
    //let Cusdata = this.navParams.get('Data');
     let Cusdata = this.Cusdata1[0]
    this.data.customerid = Cusdata.CBSCustomerID
    this.getcalloutcome();
    this.demandAccountactionModal(Cusdata);
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  modelDissmiss(){
    debugger
    this.savebool=false
    if(this.Cusdata1[1].close=="demand" || this.Cusdata1[1].close=="endcalldemand"){
      this.route.navigateByUrl('/demandcollection')
    }
   }
  getcalloutcome(){
    this.Apiservice.getcalloutcome1().then((res:any)=>{
  // console.log(JSON.parse(res));
  var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
  this.callOutCome = response;
  
    }) 
  }
  verifytime() {
    debugger
    var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
    this.getfollowdates = this.datepipe.transform( this.data.followupdate,'YYYY-MM-dd')
    if (this.getfollowdates <= date) {
      this.Alertservice.presentAlert("","The Call Back Date should not be same and less than current date")
   return false
    }
   
  }

  checkbox(Event){
    console.log(Event);
    
    if(Event){
      this.data.jointvisit = 'YES';
    }else{
      this.data.jointvisit = "NO"
    }
    console.log(this.data.jointvisit)
  }

  checkusercode(val) {
    debugger
    var usercode = val;
    var branchid = window.localStorage['branchID'];

    // this.showspin();
    this.Apiservice.getusername(usercode, branchid)
      .then((res:any)=> {
        debugger
        // this.hidespin();
      //  var response = JSON.parse(res);
  var response = JSON.parse(JSON.parse(res.data))
        if (response == "This User Not in this Branch") {

          // var myPopup = $ionicPopup.show({
          //   template: '<center>This User Is Not Under This Branch</center>',
          //   title: "",
          //   scope: this,
          //   buttons: [{
          //     text: 'OK',
          //     type: 'button button-clear button-assertive'
          //   }]
          // });
          this.Alertservice.presentAlert('',"This User Is Not Under This Branch");
          this.data.jointusername = "";

        }

        else {
          this.getusername = response;
          // this.data.jointusername = this.getusername;
          this.data.jointusername = this.getusername;
          console.log(this.getusername)
        }

      })
      // .error(function (response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }
  getbusinessunit(){
    //  this.showspin();
      this.Apiservice.getbusinessunit()
        .then( (res:any)=> {
          var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
         this.businessunit = response;
  
        //  this.hidespin();
        })
        // .error(function (response) {
        //  this.hidespin();
        //   console.log(response);
  
  
        // });
  
  
    }

    demandAccountactionModal(items){

      this.data={};
      console.log(items);

      this.data.addressname = "";
      this.data.callout = "";
      this.data.selectele = "";       
      this.data.followupdate = "";
      this.data.followuptime = "";
      this.data.jointvisit = "";
      this.data.jointusercode = "";
      this.data.jointusername = "";
      this.customeractiondata = items;
      window.localStorage['customerID'] = this.customeractiondata.CBSCustomerID;
      window.localStorage['callID'] = this.customeractiondata.ROWID;
      this.data.customerid=this.customeractiondata.CBSCustomerID;
      var customerid = items.CBSCustomerID;
      this.data.collected_accno = this.customeractiondata.AccountNumber;

      // this.smaAccountaction.show();

      if (customerid == null) {
  
          this.enable = false;
    
        }
        if (customerid != null) {
          this.enable = true;
          // this.showspin();

          this.Apiservice.getcustomerdetails(customerid)
            .then((res:any)=> {
              // this.hidespin();
              var response = res.data;
              response = JSON.parse(response);
              response = JSON.parse(response);
              this.Npacustomerdata = JSON.parse(response);
              console.log(this.Npacustomerdata)
              if(this.Npacustomerdata != "" && this.Npacustomerdata != undefined)
              {
              this.data.customerid = customerid;
              this.data.customername = this.Npacustomerdata[0].Nfirstname + ' ' + this.Npacustomerdata[0].Nlastname;
              window.localStorage['customerName'] = this.data.customername;
              this.data.firstname = this.Npacustomerdata[0].Nfirstname;
              this.data.lastname = this.Npacustomerdata[0].Nlastname;
              this.data.mobile = this.Npacustomerdata[0].Nmobile;
              this.data.resphnno = this.Npacustomerdata[0].Nresidencephone;
              this.data.email = this.Npacustomerdata[0].Nemail;
    
              this.firstWords = [];
    
              var firstname = [];
    
              if (this.Npacustomerdata.length > 0) {
                // this.showspin();
              }
              for (let i = 0; i < this.Npacustomerdata.length; i++) {
    
                firstname = this.Npacustomerdata[i].Nfirstname.split(" ");
    
                this.firstWords.push(firstname[0]);
                this.Npacustomerdata[i].firstname = this.firstWords[i];
                this.firstname1 = this.Npacustomerdata[i].firstname;
                if (i == this.Npacustomerdata.length - 1) {
                  // this.hidespin();
                }
              }
    
              console.log(this.Npacustomerdata[0].Add1);
              if(this.Npacustomerdata[0].Add1 != undefined || this.Npacustomerdata[0].Add2 != undefined || this.Npacustomerdata[0].Add3 != undefined || this.Npacustomerdata[0].Add4 != undefined || this.Npacustomerdata[0].PIN != undefined){

                var respAdd1= this.Npacustomerdata[0].Add1;
                var add1 = respAdd1.replace("/", "-");
                console.log(add1);
                var respAdd2= this.Npacustomerdata[0].Add2;
                var add2 = respAdd2.replace("/", "-");
                console.log(add2);
              this.data.addressname = add1+' '+add2+' '+this.Npacustomerdata[0].Add3+' '+this.Npacustomerdata[0].Add4+' '+this.Npacustomerdata[0].PIN;
              console.log(this.data.addressname);
              }
              if(this.data.addressname != "" && this.data.addressname != undefined)
              { 
                console.log(this.data.addressname);
               this.myvalue = true;
               //this.data.selectele='P';
              //  this.setlatlong(this.data.addressname); cmd by sijin
              }
             
             }
            })
            // .error(function (response) {
            //   console.log(response);
            //   this.hidespin();
            // });
        }

      this.purposeID= items.PURPOSEID;
      this.purpose = items.PURPOSE;
      this.data.courtesypurp = this.purposeID; 
  }

  

 saveDemandCustomer(){
debugger
    var usercode = window.localStorage['userCode'];
  var username = window.localStorage['userName'];
  var branchid = window.localStorage['branchID'];
  var CallerId = window.localStorage['userID'];
  var callid = null;
    // this.showspin();
    var mobile1 = this.data.mobile;
    var calltype = this.data.selectele;
    var remarks1 = this.data.Remarks;
    var firstname = this.data.firstname;
    var lastname1 = this.data.lastname;
    var purpose = this.data.courtesypurp;
    var customername = this.data.firstname;
    var responseid = this.data.callout;
    var cbsid = window.localStorage['customerID'];

    console.log(responseid)
    console.log(remarks1)
    if (lastname1 == "" || lastname1 == null || lastname1 == undefined) {

      var lastname = null;
    } else {
      var lastname = lastname1;
    } 
    if (remarks1 == "" || remarks1 == null || remarks1 == undefined) {

      var remarks = null;
    } else {
      var remarks = remarks1;
    }
    if (mobile1 == "" || mobile1 == null || mobile1 == undefined) {

      var mobile = null;
    } else {
      var mobile = mobile1;
    }
    console.log(this.data.courtesypurp)

    if (purpose == undefined || purpose == null || purpose == "") {
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Purpose</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert("","Select Purpose");
      return false;

    }

    if (purpose == "5" && this.data.current == "Y") {
      if ((this.data.collected_date == null || this.data.collected_date == undefined || this.data.collected_date == "") || (this.data.collected_accno == null || this.data.collected_accno == undefined || this.data.collected_accno == "") || (this.data.collectamount == null || this.data.collectamount == "" || this.data.collectamount == undefined)) {

        // var myPopup = $ionicPopup.show({
        //   template: '<center>Fill All Details Of Amount Collected</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Fill All Details Of Amount Collected");
        return false;

      } else {
        var collectionmode = "Y";
        // this.Collectiondate1 = this.data.collected_date;
        // var collectiondate = $filter('date')(this.Collectiondate1, 'yyyy-MM-dd');
        this.Collectiondate1 = this.data.collected_date;
      var collectiondate = moment(this.Collectiondate1).format('YYYY-MM-DD');
        var accountno = this.data.collected_accno;
        var amount = this.data.collectamount;
      }

    }


    if (purpose != "5") {
      var collectionmode:string = null;

    }

    if (collectionmode == null) {
      var accountno = null;
      var amount = null;
      var collectiondate:string = null;

    }

    if (purpose == 5) {
      if (this.data.current == "" || this.data.current == undefined || this.data.current == null || this.data.current == "N") {

        var collectionmode:string = null;

      }

    }


    console.log(this.data.current)

    if (this.data.callout == "" || this.data.callout == undefined || this.data.callout == null) {

      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call OutCome</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert("","Select Call OutCome");
      return false;
    }



    if (responseid == "2") {
      if ((this.data.followupdate == null || this.data.followupdate == undefined || this.data.followupdate == "") || (this.data.followuptime == undefined || this.data.followuptime == "" || this.data.followuptime == null)) {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Provide Followup Details</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Provide Followup Details");
        return false;


      } 
      else {
        var date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        this.getfollowdates = this.datepipe.transform( this.data.followupdate,'YYYY-MM-dd')
        if (this.getfollowdates <= date) {
          // this.followupvisits.followdate=''
          // this.followupvisits.followtime=''
          this.Alertservice.presentAlert("","The Call Back Date should not be same and less than current date")
        return false
        }else{
        // this.nextcalldate1 = $filter('date')(this.data.followupdate, 'yyyy-MM-dd');
        // this.followuptime = $filter('date')(this.data.followuptime, 'h.mm a');
        // var nextcalldate = this.nextcalldate1 + ' ' + this.followuptime;
        this.nextcalldate1 = moment(this.data.followupdate).format('YYYY-MM-DD');

         var time = this.data.followuptime.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [this.data.followuptime];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      this.getampm = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; 
      time[1]="."// Adjust hours
    }
    this.modifytime1= time.join ('');
    if(this.getampm=="AM"){
      this.modifytime2= this.modifytime1+' '+"AM"
    }else{
      this.modifytime2= this.modifytime1+' '+"PM"
    }
  
       //  this.followuptime = $filter('date')(this.data.followuptime, 'h.mm a');
         var nextcalldate = this.nextcalldate1 + ' ' +this.modifytime2;
      }
    }

    }

    if (responseid != "2") {
      var nextcalldate = " ";
      //          var Endtime = null;
      // var Totime = null;

    }

    if (this.data.selectele == "" || this.data.selectele == undefined || this.data.selectele == null) {
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select Call Type</center>',
      //   title: "",
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert("","Select Call Type");
      return false;

    }

    if (this.data.selectele == "P" && this.data.JointVisit == "YES") {
      if (this.data.jointusercode == null || this.data.jointusercode == "" || this.data.jointusercode == undefined) {
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter Joint Usercode</center>',
        //   title: "",
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // this.hidespin($ionicLoading);
        this.Alertservice.presentAlert("","Enter Joint Usercode");
        return false;
      }

      else {
        var jointvisit = "Y";
        var jointcode = this.data.jointusercode;

      }


    }

    if (this.data.selectele == "P") {
      if (this.data.JointVisit == "" || this.data.JointVisit == undefined || this.data.JointVisit == null || this.data.JointVisit == "N") {

        var jointvisit:string = null;
      }

    }

    if (this.data.selectele != "P") {

      var jointvisit:string = null;

    }

    if (jointvisit == null) {
      var jointcode = null;
    }
    var BusinessUnit = 0;
    var Endtime = null;
    var Totime = null;
    console.log(this.data.followupdate)
    console.log(this.data.followuptime)
    console.log(this.data.JointVisit)
    if(lastname == '.') lastname = null;
console.log(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit)
var specialChars = "<>@!#$%^&*()_+[]{}?:;|'\"\\,./~`-=";
var checkForSpecialChar = function(string){
for(let i = 0; i < specialChars.length;i++){
 if(string.indexOf(specialChars[i]) > -1){
     return true
  }
}
return false;
}   
if(checkForSpecialChar(customername)){
// alert("First Name should not contain special character");
// var alertPopup = $ionicPopup.alert({
//   title: "",
//   template: 'First Name should not contain special character '
// });
this.Alertservice.presentAlert("","First Name should not contain special character");
} else {
  
// this.showspin();
this.loader.presentLoading('')
this.savebool=true
   this.Apiservice.DemandEntry(branchid, cbsid, customername, mobile, CallerId, username, calltype, remarks, purpose, responseid, nextcalldate, firstname, lastname, usercode, callid, accountno, amount, collectiondate, collectionmode, jointvisit, jointcode, Endtime, Totime, BusinessUnit)
      .then((res:any)=> {
        debugger
        this.loader.dismissLoading();
        var response = res.data;
  response = JSON.parse(response);
  response = JSON.parse(response);
        // this.hidespin();JSON.parse(JSON.parse(res.data))
        // response = JSON.parse(response);
        var success = [];
        success = response;
        window.localStorage['date'] = "";

        if (success[0].response == 1) {

          // var alertPopup = $ionicPopup.alert({
          //   title: "",
          //   template: 'Please Visit Follow Up Screen As It Is In FOLLOW UP Status ' + success[0].Column1
          // });
          // this.Alertservice.presentAlert("","Please Visit Follow Up Screen As It Is In FOLLOW UP Status " + success[0].Column1);
         this. destatusmethod(success[0].Column1)
          // alertPopup.then(function (res) {
          //   this.UpdateModal.hide();
          //   // Custom functionality....
          // });

        }
        else {

          // this.Alertservice.presentAlert('Success',"Saved Successfully");
          // return false
          this.data = {};
          this.desavemethod()
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Success',
          //   template: 'Saved Successfully'
          // });

          // alertPopup.then(function (res) {
          //   this.smaAccountaction.hide();
          //   this.getdemandcollectionCustomers(); cmd by sijin
          //   // Custom functionality....
          // });
          // this.modelDissmiss()
          
          
        
        }
        
        // this.getsmaAmount();

      })
      // .error(function (response) {
      //   this.hidespin();
      //   console.log(response);
      // });

    }

      // this.data={};

  }
  async destatusmethod(msg){
    const alert:any = await this.alert1.create({
      header: "",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: "Please Visit Follow Up Screen As It Is In FOLLOW UP Status"+msg,
      buttons: [{ text     : 'Ok',
     
      
      handler: () => {
     this.modelDissmiss()
      }
    },
   ]
    });
    await alert.present()
   }

   async desavemethod(){
    const alert:any = await this.alert1.create({
      header: "",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: "Saved Successfully",
      buttons: [{ text     : 'Ok',
     
      
      handler: () => {
        this.modelDissmiss()
      }
    },
   ]
    });
    await alert.present()
   }
  customerActionModal(item){
    this.data.addressname = "";
    this.data.callout = "";
    this.data.selectele = "";       
    this.data.followupdate = "";
    this.data.followuptime = "";
    this.data.jointvisit = "";
    this.data.jointusercode = "";
    this.data.jointusername = "";
  }

}
