import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DairyuserdetailscheckPageRoutingModule } from './dairyuserdetailscheck-routing.module';

import { DairyuserdetailscheckPage } from './dairyuserdetailscheck.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DairyuserdetailscheckPageRoutingModule
  ],
  declarations: [DairyuserdetailscheckPage]
})
export class DairyuserdetailscheckPageModule {}
