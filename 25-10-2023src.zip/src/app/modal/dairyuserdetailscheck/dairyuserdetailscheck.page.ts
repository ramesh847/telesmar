import { Component, OnInit } from '@angular/core';
import { NavParams } from 'node_modules/@ionic/angular';

@Component({
  selector: 'app-dairyuserdetailscheck',
  templateUrl: './dairyuserdetailscheck.page.html',
  styleUrls: ['./dairyuserdetailscheck.page.scss'],
})
export class DairyuserdetailscheckPage implements OnInit {
  cusdata: any;

  constructor(private navparam:NavParams) { }

  ngOnInit() {
    debugger
    this.cusdata=this.navparam.get('Data')
  }

}
