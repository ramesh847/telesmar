import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DairyuserdetailscheckPage } from './dairyuserdetailscheck.page';

const routes: Routes = [
  {
    path: '',
    component: DairyuserdetailscheckPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DairyuserdetailscheckPageRoutingModule {}
