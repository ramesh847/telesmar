import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';

@Component({
  selector: 'app-monthlyuserdetails',
  templateUrl: './monthlyuserdetails.page.html',
  styleUrls: ['./monthlyuserdetails.page.scss'],
  providers:[DatePipe]
})
export class MonthlyuserdetailsPage implements OnInit {
  data: any;
  monthyear: any;
  usercode: any;
  getmanagerdetails: any;
  getmanagerdetailslength: any;

  constructor(private loader:ToastServiceService,private datepipe:DatePipe,
    private modalController:ModalController,private Apiservice:ApiServiceService,
    public navparam:NavParams,
    private router:Router,public alertservice:AlertServiceService) { }

  ngOnInit() {
    debugger
    this.usercode=this.navparam.get('Data')
   
    this.monthyear=this.navparam.get('monthyear')
    this.getmonthuserdetails(this.usercode,this.monthyear.month,this.monthyear.year)
  }
  getmonthuserdetails (usercode,month,year) {
  debugger
    // console.log(val)
    var usercode = usercode;
    var branchid = window.localStorage['branchID'];
    // var month = this.diary.month;
    // var year = this.diary.year;

    // this.showspin();
    this.loader.presentLoading('')
    this.Apiservice.getusermonthstaffdiarydetails(usercode, branchid, month, year)
        .then( (response:any)=> {
          debugger
          this.loader.dismissLoading()
            // this.hidespin();
            response =JSON.parse(JSON.parse(response.data));
            // console.log(response)
            this.getmanagerdetails = response;
            this.getmanagerdetailslength=response.length


        },err=>{
          this.alertservice.presentAlert("Error",err.status)
        })
       

}
  modeldissmiss(){
    this.modalController.dismiss()
  }
}
