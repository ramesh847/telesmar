import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MonthlyuserdetailsPage } from './monthlyuserdetails.page';

const routes: Routes = [
  {
    path: '',
    component: MonthlyuserdetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MonthlyuserdetailsPageRoutingModule {}
