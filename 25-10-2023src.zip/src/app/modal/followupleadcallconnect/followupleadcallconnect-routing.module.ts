import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FollowupleadcallconnectPage } from './followupleadcallconnect.page';

const routes: Routes = [
  {
    path: '',
    component: FollowupleadcallconnectPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FollowupleadcallconnectPageRoutingModule {}
