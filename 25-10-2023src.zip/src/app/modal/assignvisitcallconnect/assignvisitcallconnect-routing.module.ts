import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssignvisitcallconnectPage } from './assignvisitcallconnect.page';

const routes: Routes = [
  {
    path: '',
    component: AssignvisitcallconnectPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssignvisitcallconnectPageRoutingModule {}
