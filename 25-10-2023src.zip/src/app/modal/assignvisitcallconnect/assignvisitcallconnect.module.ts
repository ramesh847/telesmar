import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssignvisitcallconnectPageRoutingModule } from './assignvisitcallconnect-routing.module';

import { AssignvisitcallconnectPage } from './assignvisitcallconnect.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssignvisitcallconnectPageRoutingModule
  ],
  declarations: [AssignvisitcallconnectPage]
})
export class AssignvisitcallconnectPageModule {}
