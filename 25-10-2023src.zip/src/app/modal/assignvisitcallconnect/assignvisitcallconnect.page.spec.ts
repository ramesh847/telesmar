import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AssignvisitcallconnectPage } from './assignvisitcallconnect.page';

describe('AssignvisitcallconnectPage', () => {
  let component: AssignvisitcallconnectPage;
  let fixture: ComponentFixture<AssignvisitcallconnectPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignvisitcallconnectPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssignvisitcallconnectPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
