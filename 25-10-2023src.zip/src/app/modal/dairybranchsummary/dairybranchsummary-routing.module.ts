import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DairybranchsummaryPage } from './dairybranchsummary.page';

const routes: Routes = [
  {
    path: '',
    component: DairybranchsummaryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DairybranchsummaryPageRoutingModule {}
