import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { ToastServiceService } from 'src/app/service/toast-service.service';
import { BranchreportsummaryPage } from '../branchreportsummary/branchreportsummary.page';
import { BranchsummarypendingPage } from '../branchsummarypending/branchsummarypending.page';
import { SummarywishlistPage } from '../summarywishlist/summarywishlist.page';
import { ViewReportPage } from '../view-report/view-report.page';

@Component({
  selector: 'app-dairybranchsummary',
  templateUrl: './dairybranchsummary.page.html',
  styleUrls: ['./dairybranchsummary.page.scss'],
  providers:[Idle]
})
export class DairybranchsummaryPage implements OnInit {
  data:any={}
  dataresp: any;
  dataresplength: any;
  idleState: string;
  constructor(private apiService:ApiServiceService,
  //  private navParams: NavParams,
    private alertService: AlertServiceService,
    public modalController: ModalController,private loader:ToastServiceService,
    public router:Router,private idle:Idle) {  // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          // (this.idleState = countdown.toString() )
          {
            let idleState = countdown
           let minutes = Math.floor((idleState)/ 60);
           let extraSeconds = (idleState) % 60;
          let minutes1 = minutes < 10 ? "0" + minutes : minutes;
          let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
          this.idleState=minutes1 +':'+ extraSeconds1
          console.log(this.idleState) 
          }
      );}

  ngOnInit() {
    this.getBranchSummarylist()
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
 getBranchSummarylist () {
    // this.showspin();
    var userid = window.localStorage['userID'];
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    if(this.data.customerid == undefined){
      var custID = 0 ;
    }else{
      custID = this.data.customerid ;
    }
    this.loader.presentLoading('')
    this.apiService.getBranchsummaryGrid(userid, branchid, userType,custID)
      .then((response:any) =>{
        this.loader.dismissLoading()
        // this.hidespin();
        console.log(response);
        response = JSON.parse(JSON.parse(response.data));
        this.dataresp = response.Table;
        this.dataresplength=this.dataresp.length
        console.log(this.dataresp)

      },err=>{
        this.alertService.presentAlert("Error",err.status)
      })
     
  }
  goToMyplannerPage(){
    this.router.navigateByUrl('/newsummary')
  }
  async branchreportCust1(item){
    const modal = await this.modalController.create({
      component:BranchreportsummaryPage,
      componentProps: { Data: item }
    });
    return await modal.present();
   
  }
  async branchpendingList1(item){
    const modal = await this.modalController.create({
      component:BranchsummarypendingPage,
      componentProps: { Data: item }
    });
    return await modal.present();
  }
  async branchwishpendingList1(item){
    const modal = await this.modalController.create({
      component:SummarywishlistPage,
      componentProps: { Data: item }
    });
    return await modal.present();
  }
}
