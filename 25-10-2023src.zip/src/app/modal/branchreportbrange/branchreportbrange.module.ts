import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BranchreportbrangePageRoutingModule } from './branchreportbrange-routing.module';

import { BranchreportbrangePage } from './branchreportbrange.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BranchreportbrangePageRoutingModule
  ],
  declarations: [BranchreportbrangePage]
})
export class BranchreportbrangePageModule {}
