import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BranchreportbrangePage } from './branchreportbrange.page';

const routes: Routes = [
  {
    path: '',
    component: BranchreportbrangePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BranchreportbrangePageRoutingModule {}
