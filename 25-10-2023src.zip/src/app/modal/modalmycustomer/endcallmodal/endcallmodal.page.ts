import { Component, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';
import { ApiServiceService } from 'src/app/service/api-service.service';
import { AlertController } from '@ionic/angular';
import * as moment from "moment"; 
import { ModalController } from '@ionic/angular';
import { ModalmycustomerPage } from '../modalmycustomer.page';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-endcallmodal',
  templateUrl: './endcallmodal.page.html',
  styleUrls: ['./endcallmodal.page.scss'],
})
export class EndcallmodalPage implements OnInit {
  entry:any={};
  data:any={};
  interval: any;
  res: any;
  resout: any;
  clickcallID: any;
  availableinfo: any[];
  productListresp: any;
  recommended: any;
  availedproductdetails: any;
  // availableinfo = [];
  availed = [];
  unavailed = [];
  successcount = 0;
  accessResp: any;
  ClickAccess: boolean;
  statusResp: any;
  repStatus: any;
  endDate: string;
  currDate: string;

  clickcall:any={};
  item:any = '';
  cusdetail_data: any;
  customeractiondata: any;
  cusType: any;
  businessunit: any;
  customerData1: any;
  existingcustomeradd: any;
  myvalue: boolean;
  provider: any;
  location: any;
  voicerecording: any;
  status: string;
  status2: string;
  constructor(private AlertService:AlertServiceService,
    private alert:AlertController,private modalController:ModalController,
    private apiservice:ApiServiceService,private navParams:NavParams,public route:Router) { }

  ngOnInit() {
    this.cusdetail_data = this.navParams.get('Data');
    console.log( this.cusdetail_data);
    this.callNumber( this.cusdetail_data);
    this.clickCallAccess();
  }


  clickCallAccess(){
    var userid = window.localStorage['userID'];
    this.apiservice.AccesstoClick(userid)
    .then((res:any)=> {
      console.log(res)
    var  response = JSON.parse(res.data)
      this.accessResp= JSON.parse(response)
      // this.hidespin($ionicLoading);
      if(this.accessResp == 'A'){
        console.log(this.accessResp);
        this.ClickAccess =true;
      }else{
        this.ClickAccess =false;
      }
     
    })
    
    .catch((response)=> {
      console.log(response);
      // this.hidespin($ionicLoading);
    });
  }

 
  callNumber(item){
    console.log(item);
    this.item = item;
    debugger
    this.clickcall.callerName=window.localStorage['userName'];
    this.clickcall.callerMobile=window.localStorage['mobile'];
    this.clickcall.customerName= item.CustomerName;
    console.log(this.clickcall.customerName)
    this.clickcall.customerMobile=item.Mobile;
    this.clickcall.customerId=item.CBSCustomerId;
    this.clickcall.cust=item.custCat;
    this.clickcall.endDate='';
    var purpose = 'Mystarcustomer';
    var currentDate= new Date();
    // this.clickcall.currDate = $filter('date')(currentDate, 'yyyy-MM-dd hh-mm-ss');
    // console.log(this.currDate);
    this.clickcall.currDate = moment(currentDate).format('YYYY-MM-DD h.mm a');
    this.getproductlistdetails(this.clickcall.customerId);
    // this.followuptime = moment(this.data.followuptime).format('h.mm a');
    this.apiservice.clickToCallCustomer(this.clickcall.callerMobile,this.clickcall.customerMobile,purpose)
    .then((response)=> {
      debugger
      console.log(response)
      // this.hidespin($ionicLoading);
      // debugger
      this.res = JSON.parse(response.data);
      this.resout = JSON.parse(this.res);
      this.resout = JSON.parse(this.resout);
      // console.log(resout)
      // debugger
      if(this.resout.status == "200"){
        // debugger
        this.clickcallID = this.resout.data;
        this.callinterval();

        

        // this.CallConnectModal.show();
      }else{
      // var alertPopup = $ionicPopup.alert({
      //   title: 'Alert',
      //   template: response.data
      // });
      this.AlertService.presentAlert("Alert",this.resout.message)
      // alertPopup.then(function(res) {
      // });
      // by sijin
      }


    },(err)=>{
      console.log(err);
      
      this.AlertService.presentAlert('Error', err.status);
    })
    
    // .error(function(response) {
    //   console.log(response);
    //   this.hidespin($ionicLoading);
    // });

  }

  callinterval(){
    // alert()
  this.interval = setInterval(() => {
this.callResp();
    // clearInterval(this.interval)
  }, 10000);
  }
  stopCall(){
    clearInterval(this.interval)
  }
////////////////////////////////////////

  EndCallobj:any={};
  callResp(){
    // console.log(this.clickcallID.id);
    var id = this.clickcallID.id;
    this.apiservice.callStatusCustomer(id)
    .then((res:any)=> {
     console.log(res)
    debugger
     var response = JSON.parse(res.data)
     var response = JSON.parse(response)
     var response = JSON.parse(response)
      this.statusResp= response.data
      this.repStatus = response;
      // this.hidespin($ionicLoading);
      console.log(this.repStatus.data.length);
      if(this.repStatus.data.length == 1){
        // console.log(this.repStatus.data[0].status2);
      if(this.repStatus.data[0].status2 != null){
        // console.log(this.repStatus.data[0]);
        if(this.repStatus.data[0].status2 == 'ANSWER'){
          this.stopCall();
          // this.CallConnectModal.hide();
          this.EndCallobj.callerName=window.localStorage['userName'];
          this.EndCallobj.callerMobile=window.localStorage['mobile'];
          this.EndCallobj.customerName=this.item.CustomerName;
          this.EndCallobj.customerMobile=this.item.Mobile;
          this.EndCallobj.customerId=this.item.CBSCustomerId;
          this.EndCallobj.cust=this.item.custCat;
          this.EndCallobj.endStatus= 'A';
          this.EndCallobj.currDate = this.repStatus.data[0].start_time;
          this.EndCallobj.endDate = this.repStatus.data[0].end_time;
          this.Endcall(this.EndCallobj);
          //  this.customerpopup(this.item); 
        }else{


         this.callresppopup(this.repStatus.data[0].status2)
       
        }
        
      }
    }
    },(err)=>{
      console.log(err);
      
      this.AlertService.presentAlert('Error', err.status);
    })
    
   
  }
async callresppopup(ans){
  debugger
  const alert:any = await this.alert.create({
    header: "Alert",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message:ans+ ' would you like to update?',
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
      this.clickcall={};
      // this.CallConnectModal.hide();
      // this.modelDissmiss();
      this.stopCall();
      console.log(this.item);
      this.EndCallobj.callerName=window.localStorage['userName'];
      this.EndCallobj.callerMobile=window.localStorage['mobile'];
      this.EndCallobj.customerName=this.item.CustomerName;
      this.EndCallobj.customerMobile=this.item.Mobile;
      this.EndCallobj.customerId=this.item.CBSCustomerId;
      this.EndCallobj.cust=this.item.custCat;
      this.EndCallobj.endStatus= 'I';
      this.EndCallobj.currDate = this.repStatus.data[0].start_time;
      this.EndCallobj.endDate = this.repStatus.data[0].end_time;
      // this.Endcall(this.EndCallobj);
    this.customerpopup(this.item);
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.CallConnectModal.hide(); cmd by sijin
    this.stopCall();
  }
},]
  });
await alert.precent();
}

  Endcall(obj){
    debugger
    console.log(obj);
    var clickid=this.clickcallID.id
      if(obj.endDate == undefined || obj.endDate == 'undefined' || obj.endDate == null || obj.endDate == ''){
        var enDate = new Date();
        //  this.endDate = $filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
         this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
        // this.endDate = $filter('date')(enDate, 'hh-mm-ss');
        console.log(this.endDate);
        }else{
          var enDate= new Date(obj.endDate);
          this.endDate = moment(enDate).format('YYYY-MM-DD h.mm a')
          // this.endDate =$filter('date')(enDate, 'yyyy-MM-dd hh-mm-ss');
          console.log(this.endDate);
        }
        var curDate= new Date(obj.currDate);
        this.currDate = moment(curDate).format('YYYY-MM-DD h.mm a')
        // this.currDate = $filter('date')(curDate, 'yyyy-MM-dd hh-mm-ss');
        console.log(this.currDate);
    var branchid = window.localStorage['branchID'];
    var usertype = window.localStorage['userType'];
    var userid = window.localStorage['userID'];
    var purpose = 'Mystarcustomer';
   


    // this.apiservice.callStatusLead(clickid).then((res:any)=>{
    //   debugger
    //   if(res !='' ){
    //     var dce=JSON.parse(JSON.parse(res.data))
    //     if(dce==''){
    //       this.customerpopup(this.item)
    //     }else{
    //     if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length !='0'){
    //       var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
        
    //       console.log(xyz)
        
    //       if(xyz[0].recording==''){
    //         this.voicerecording='No Record'
    //       }else{
    //       this.voicerecording=xyz[0].recording.slice(28)
    //       }
    //       if(xyz[0].location==''){
    //         this.location="no record"
    //       }else{
    //         this.location=xyz[0].location
    //       }
    //       if(xyz[0].provider==''){
    //         this.provider="no provider"
    //       }else{
    //         this.provider=xyz[0].location
    //       }
  
    //     this.apiservice.EndCAllClick2(obj.customerId,obj.customerName,obj.customerMobile,userid,branchid,obj.callerMobile,xyz[0].start_time,xyz[0].end_time,purpose,xyz[0].duration, xyz[0].billsec,xyz[0].credits,xyz[0].status,xyz[0].status2,this.voicerecording,this.location,this.provider)
    //     .then((response:any)=> {
    //       debugger
    //       // console.log(response)
    //       // this.hidespin($ionicLoading);
    //       if(obj.endStatus == 'I'){
         
    //         this.endcalpopup()
    //     }else{
    //       this.clickcall={};
    //             // this.CallConnectModal.hide();
    //             this.stopCall();
    //             // console.log(this.Cusdata);
    //             this.customerpopup(this.item)
    //     }
    //     } ,(err)=>{
    //       debugger
    //       console.log(err);
    //       // this.hidespin();
    //       // var myPopup = $ionicPopup.show({
    //       //   template: err,
    //       //   title: 'Error',
    //       //   scope: this,
    //       //   buttons: [{
    //       //     text: 'OK',
    //       //     type: 'button button-clear button-assertive'
    //       //   }]
    //       // });
    //       this.AlertService.presentAlert('Error', err.status);
    //     }     )
        
    //     // .catch((error)=>{
    //     //   this.AlertService.presentAlert('failed',console.error(error));
          
    //     // });
    //   }else{
    //     this.customerpopup(this.item)
    //     }
    //     }}else{
    //       this.customerpopup(this.item)
    //     }
    // },(err)=>{
    //   console.log(err);
      
    //   this.AlertService.presentAlert('Error', err.status);
    // })


    this.apiservice.callStatusLead(clickid).then((res:any)=>{

      debugger
     res= JSON.stringify(res)
     res=JSON.parse(res)
  
  
  
  
      if(res=='' ){
       
        this.stopCall();
        // console.log($scope.item);
        this.customerpopup(this.item)
      }else{
      
      if(JSON.parse(JSON.parse(JSON.parse(res.data))).data.length==0){
        // $scope.clickTocallConnect.hide();
        this.stopCall();
        // console.log($scope.item);
        this.customerpopup(this.item)
      }else{
      
      var xyz=JSON.parse(JSON.parse(JSON.parse(res.data))).data
      
      if(xyz[0].recording=='' || xyz[0].recording==null || xyz[0].recording==undefined){
        this.voicerecording='No Record'
      }else{
      this.voicerecording=xyz[0].recording.slice(28)
      }
      if(xyz[0].location=='' || xyz[0].location==null || xyz[0].location==undefined){
      this.location="no record"
      }else{
        this.location=xyz[0].location
      }
      if(xyz[0].provider=='' || xyz[0].provider==null || xyz[0].provider==undefined){
        this.provider="no provider"
      }else{
        this.provider=xyz[0].provider
      }
      if(xyz[0].status=='' || xyz[0].status==null || xyz[0].status==undefined){
        this.status="no status"
      }else{
       this.status=xyz[0].status
      }
      if(xyz[0].status2=='' || xyz[0].status2==null || xyz[0].status2==undefined ){
        this.status2="no status"
      }else{
       this.status2=xyz[0].status2
      }
      
      this.apiservice.EndCAllClick2(obj.customerId,obj.customerName,obj.customerMobile,userid,branchid,obj.callerMobile,xyz[0].start_time,xyz[0].end_time,purpose,xyz[0].duration, xyz[0].billsec,xyz[0].credits,this.status,this.status2,this.voicerecording,this.location,this.provider)
        .then((response:any)=> {
                debugger
            
                // obj.endStatus == 'I'
                if(obj.endStatus == '0'){
             
               
    
                  this.endcalpopup()
    
              }else{
                debugger
               this.clickcall={};
                     
                    this.stopCall();
                      // console.log($scope.item);
                      this.customerpopup(this.item)
              }
              },err=>{
                this.AlertService.presentAlert("Error",err.status)
              })
              
            
            }
              }
            })



    
  this.availableinfo = [];
  this.availed = [];
  this.unavailed = [];
  }

async endcalpopup(){
  debugger
  const alert:any = await this.alert.create({
    header: "Alert",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "You have ended the call explicitly. would you like to update?",
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
      this.clickcall={};
            // this.modelDissmiss();
            this.stopCall();
            console.log(this.item);
            this.customerpopup(this.item);
    }
  },
  { text     : 'No',
   
    
  handler: () => {
    this.clickcall={};
    // this.modelDissmiss(); // cmd by sijin
    this.stopCall();
  }
},]
  });
  await alert.precent();
}


getbusinessunitNew() {
  // this.showspin();
debugger
this.apiservice.getbusinessunitNew()
  .then((response:any)=> {
    debugger
    console.log(response);
    response = JSON.parse(response);
    this.businessunit = response;

    // this.hidespin();
  })
  


}
getbusinessunitExisting() {
  debugger

this.apiservice.getbusinessunitExisting()
  .then((response:any) =>{
    debugger
    console.log(response);
    response = JSON.parse(response.data);
    this.businessunit = JSON.parse(response);
    //this.getloction(response);
    // this.hidespin();
  })
 

}
getexistingCustomer(item) {
  // this.showspin();
  debugger
console.log(item)
//this.custID=item;
this.apiservice.getexistingcustomerdetails(item)
  .then((response:any) =>{
    debugger
    // this.hidespin();
    console.log(response.data);
    this.customerData1 = JSON.parse(response.data);
    console.log(this.customerData1);
    this.existingcustomeradd= JSON.parse(this.customerData1);

    this.existingcustomeradd[0].Add1 = this.existingcustomeradd[0].Add1
    this.existingcustomeradd[0].Add2 = this.existingcustomeradd[0].Add2
    this.existingcustomeradd[0].Add3 = this.existingcustomeradd[0].Add3
    this.existingcustomeradd[0].Add4 = this.existingcustomeradd[0].Add4

    if(this.existingcustomeradd != "" && this.existingcustomeradd != undefined)
    {
    console.log(this.existingcustomeradd[0].Add1);
    if(this.existingcustomeradd[0].Add1 != undefined || this.existingcustomeradd[0].Add2 != undefined || this.existingcustomeradd[0].Add3 != undefined || this.existingcustomeradd[0].Add4 != undefined || this.existingcustomeradd[0].PIN != undefined){
      var respAdd1= this.existingcustomeradd[0].Add1;
      var add1 = respAdd1;
      console.log(add1);
      var respAdd2= this.existingcustomeradd[0].Add2;
      var add2 = respAdd2;
      console.log(add2);
    this.data.addressname = add1+' '+add2+' '+this.existingcustomeradd[0].Add3+' '+this.existingcustomeradd[0].Add4+' '+this.existingcustomeradd[0].PIN;
    console.log(this.data.addressname);
    }
    if(this.data.addressname != "" && this.data.addressname != undefined)
    { 
      console.log(this.data.addressname);
     this.myvalue = true;
     //this.data.selectele='P';
    //  this.setlatlong(this.data.addressname);
    }
   
   }

    
  })


}
async customerpopup(item){
  debugger
  // this.apiservice.mystararray=[]
  // this.apiservice.mystararray.push(item,{close:"endcallmystar"})
  // this.route.navigateByUrl('/modalmycustomer')
  const modal = await this.modalController.create({
    component: ModalmycustomerPage,
    componentProps: { Data: item }
    });
    return await modal.present();
}
   
getproductlistdetails(custid){
    // $ionicLoading.show({
    //   template: '<ion-spinner icon="lines" class="spinner-cub"></ion-spinner>'
    // })
    console.log();
    this.availableinfo = [];
    this.apiservice.getProductListDetails(custid)
        .then((res:any)=> {
          console.log(res);
          debugger
          // $ionicLoading.hide();
         var response = JSON.parse(res.data)
          this.productListresp = JSON.parse(response);
          this.recommended = this.productListresp.Table;
          this.availedproductdetails = this.productListresp.Table1[0];
          for (const valuename in this.availedproductdetails) {
            if(valuename != 'Mobile'&&valuename != 'Email'&&valuename != 'Aadhar'&&valuename != 'PAN'){
              if(`${this.availedproductdetails[valuename]}` == "Y"){
                this.availed.push(`${valuename}`);
              }
              if(`${this.availedproductdetails[valuename]}` == "N"){
                this.unavailed.push(`${valuename}`); 
              }
            }else{
              if(`${valuename}` == 'Mobile' ){
                if(`${this.availedproductdetails[valuename]}` != null && `${this.availedproductdetails[valuename]}` != undefined &&`${this.availedproductdetails[valuename]}` != 'N'&&`${this.availedproductdetails[valuename]}` != ''){
                  this.availableinfo.push({status:'y',name:'Mobile',value:`${this.availedproductdetails[valuename]}`})
                }else{
                  this.availableinfo.push({status:'n',name:'Mobile',value:"Not Available"})
                }
              }else if(`${valuename}` == 'Email' ){
                if(`${this.availedproductdetails[valuename]}` != null && `${this.availedproductdetails[valuename]}` != undefined &&`${this.availedproductdetails[valuename]}` != 'N' &&`${this.availedproductdetails[valuename]}` != ''){
                  this.availableinfo.push({status:'y',name:'Email',value:`${this.availedproductdetails[valuename]}`})
                }else{
                  this.availableinfo.push({status:'n',name:'Email',value:"Not Available"})
                }
              }else if(`${valuename}` == 'Aadhar' ){
                if(`${this.availedproductdetails[valuename]}` != null && `${this.availedproductdetails[valuename]}` != undefined &&`${this.availedproductdetails[valuename]}` != 'N' &&`${this.availedproductdetails[valuename]}` != ''){
                  this.availableinfo.push({status:'y',name:'Aadhar',value:`${this.availedproductdetails[valuename]}`})
                }else{
                  this.availableinfo.push({status:'n',name:'Aadhar',value:"Not Available"})
                }
              }else if(`${valuename}` == 'PAN' ){
                if(`${this.availedproductdetails[valuename]}` != null && `${this.availedproductdetails[valuename]}` != undefined &&`${this.availedproductdetails[valuename]}` != 'N' &&`${this.availedproductdetails[valuename]}` != ''){
                  this.availableinfo.push({status:'y',name:'PAN',value:`${this.availedproductdetails[valuename]}`})
                }else{
                  this.availableinfo.push({status:'n',name:'PAN',value:"Not Available"})
                }
              }
            }
          }
          console.log(this.availed);
          console.log(this.unavailed);
          console.log(this.availableinfo);

        }).catch((error)=>{
            console.log(error);
            // $ionicLoading.hide();
        })
  }

  modelDissmiss(){
    this.modalController.dismiss();
   }
}
