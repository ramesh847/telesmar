import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EmpnamewisedetailsPageRoutingModule } from './empnamewisedetails-routing.module';

import { EmpnamewisedetailsPage } from './empnamewisedetails.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EmpnamewisedetailsPageRoutingModule
  ],
  declarations: [EmpnamewisedetailsPage]
})
export class EmpnamewisedetailsPageModule {}
