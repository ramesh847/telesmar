import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssigncallconnectPageRoutingModule } from './assigncallconnect-routing.module';

import { AssigncallconnectPage } from './assigncallconnect.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssigncallconnectPageRoutingModule
  ],
  declarations: [AssigncallconnectPage]
})
export class AssigncallconnectPageModule {}
