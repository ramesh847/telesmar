import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BranchempdetailPageRoutingModule } from './branchempdetail-routing.module';

import { BranchempdetailPage } from './branchempdetail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BranchempdetailPageRoutingModule
  ],
  declarations: [BranchempdetailPage]
})
export class BranchempdetailPageModule {}
