import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BranchwisedetailsPage } from './branchwisedetails.page';

const routes: Routes = [
  {
    path: '',
    component: BranchwisedetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BranchwisedetailsPageRoutingModule {}
