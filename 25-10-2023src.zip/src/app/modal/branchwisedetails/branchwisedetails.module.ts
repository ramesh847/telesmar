import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BranchwisedetailsPageRoutingModule } from './branchwisedetails-routing.module';

import { BranchwisedetailsPage } from './branchwisedetails.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BranchwisedetailsPageRoutingModule
  ],
  declarations: [BranchwisedetailsPage]
})
export class BranchwisedetailsPageModule {}
