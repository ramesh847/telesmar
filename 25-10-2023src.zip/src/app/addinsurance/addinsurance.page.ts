import { Component, OnInit } from '@angular/core';
import { Pipe, PipeTransform } from "@angular/core";
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';
import * as moment from "moment"; 
import {Router }  from '@angular/router';
import { Idle, DEFAULT_INTERRUPTSOURCES } from "@ng-idle/core";
@Pipe({
  name: 'actStatusPipe'
})
@Component({
  selector: 'app-addinsurance',
  templateUrl: './addinsurance.page.html',
  styleUrls: ['./addinsurance.page.scss'],
  providers:[Idle]
})
export class AddinsurancePage implements OnInit {
  savebool:boolean
  minDate: any = new Date().toISOString();
  maxData : any = (new Date()).getFullYear() + 3;
  entryMonth:any;
data1:any={};
assigned:any={}
new:boolean=false;
exist: boolean=true;
  types: any;
  companies: any;
  products: any;
  plans: any;
  customerId: any;
  term: any;
  exhide:boolean=false
  idleState: string;
  termvalue: any;
  constructor(private Alertservice:AlertServiceService,
    private router: Router,
    private toast:ToastServiceService,private Apiservice:ApiServiceService,public idle: Idle) { 
      
 // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
       {
          // const xyz=Math.floor(time / 60);
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
       }
    );
    }

  ngOnInit() {
    debugger
    
    this.data1.exist = 'YES';

if(this.data1.exist == 'YES'){
  this.exhide=true
}else{
  this.exhide=false
}


    this.getType();
    // this.reset()
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    // this.timedOut = false;
  }
  getToday(): string {
    return new Date().toISOString().split('T')[0]
 }

getType(){
  debugger
    // this.showspin()
    var strParam = 'Insurance';
    var strCompany = 'test';
    var strProducts = 'test';
    console.log("strCompany", strCompany)
    this.Apiservice.getInsurance(strParam,strCompany,strProducts).then((response:any)=>{
      debugger
      // this.hidespin();
      var result = response.data;
      result = JSON.parse(result);
      result = JSON.parse(result);
      this.types = result;
      console.log("Types",this.types)
    })
  }

  onTypeSelected(){
    debugger
    // console.log("selected",this.type.TEXT)
    var strParamType = this.assigned.selectedType;
    console.log(strParamType)
    if(strParamType == '' || strParamType==undefined){
      strParamType='test'
    }
    var strCompany = 'test';
    var strProducts = 'test';
    console.log("selected",strParamType)
    this.Apiservice.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
      debugger
      console.log("comapniesType",response);
      var result = response.data;
      if(result == '"No record"'){
       this.companies=[]
this.plans=[]
this.term=[]
this.assigned.selectedCompany=""
this.assigned.selectedPlan=""
// this.assigned.selectedProduct=""
this.assigned.selectedterm=""
this.assigned.selectedProduct=''
      }else{
        result = JSON.parse(result);
        result = JSON.parse(result);
      // response = JSON.parse(response);
      this.companies = result;

      this.assigned.selectedCompany=""
      this.assigned.selectedPlan=""
      this.assigned.selectedProduct=""
      this.assigned.selectedterm=""
      console.log("comapnies",this.companies);
      }
       
    })
  }

  onCompanySelected(){
    debugger
    var strParamType = this.assigned.selectedType;
    var strCompany = this.assigned.selectedCompany;
    var strProducts = 'test';
    if(strParamType == '' || strParamType == undefined){
      strParamType ='test'
    }
    if(strCompany == '' || strCompany == undefined){
      strCompany='test'
    }
    console.log("selected",strParamType,strCompany);
    this.Apiservice.getInsurancecompany(strCompany,strParamType).then((response:any)=>{
      debugger
      var result = response.data;
      if(result == '"No record"'){
       
       
        // this.companies=[]
        this.plans=[]
        this.term=[]
        this.assigned.selectedProduct=''
        // this.assigned.selectedCompany=""
        this.assigned.selectedPlan=""
        // this.assigned.selectedProduct=""
        this.assigned.selectedterm=""
      }
        else{
          result = JSON.parse(result);
          result = JSON.parse(result);
        // this.products = result;
        console.log(result)
        this.plans = result;
        this.assigned.selectedProduct=""
        this.assigned.selectedterm=""
        // this.assigned.selectedCompany=""
        this.assigned.selectedPlan=""
        // this.assigned.selectedProduct=""
        // this.assigned.selectedterm=""
        console.log("products",this.products);
        }
       
    })
  }
  onCompanyplanSelected(){
    debugger
    var strParamType = this.assigned.selectedType;
    var strCompany = this.assigned.selectedCompany;
    var strPlan = this.assigned.selectedPlan;
    if(strParamType == '' || strParamType == undefined){
      strParamType ='test'
    }
    if(strCompany == '' || strCompany == undefined){
      strCompany='test'
    }
    if(strPlan == '' || strPlan == undefined){
      strPlan='test'
    }
    console.log("selected",strParamType,strCompany,strPlan);
    this.Apiservice.getInsuranceplans(strParamType,strCompany,strPlan).then((response:any)=>{
      debugger
      console.log("products",response);
      var result = response.data;
      if(result == '"No record"'){
       
        
        this.products=[]
        this.term=[]
        this.assigned.selectedProduct=''

        // this.assigned.selectedCompany=""
        // this.assigned.selectedPlan=""
        // this.assigned.selectedProduct=""
        this.assigned.selectedterm=""
      }else{
        result = JSON.parse(result);
        result = JSON.parse(result);
      // response = JSON.parse(response);
      this.term = result;
      this.assigned.selectedProduct=""
      
      this.assigned.selectedterm=""
      console.log("plans",this.plans);
      }
       
    })
  }
  oncompanytermsselected(){
    debugger
    var strParamType = this.assigned.selectedType;
    var strCompany = this.assigned.selectedCompany;
    var strPlan = this.assigned.selectedPlan;
    var strterm = this.assigned.selectedterm;

    if(strParamType == '' || strParamType == undefined){
      strParamType ='test'
    }
    if(strCompany == '' || strCompany == undefined){
      strCompany='test'
    }
    if(strPlan == '' || strPlan == undefined){
      strPlan='test'
    }
    if(strterm == '' || strterm == undefined){
      strterm='test'
    }


    console.log("selected",strParamType,strCompany,strPlan,strterm);

    this.Apiservice.getInsuranceterm(strParamType,strCompany,strPlan,strterm).then((response:any)=>{
      debugger
      console.log("products",response);
      var result = response.data;
      if(result == '"No record"' || result == "No record"){
       
        
       
        this.assigned.selectedProduct=''
      }else{
        result = JSON.parse(result);
        // result = JSON.parse(result);
      // response = JSON.parse(response);
      this.assigned.selectedProduct = result[0].text;
      // this.assigned.selectedPlan=""
      this.term. forEach((value)=>{
        if(value.text == strterm){
this.termvalue=value.VAL
        }
       }) 
      console.log("plans",this.plans);
      }
    })

  }
  onProductSelected(){
    var strParamType = this.assigned.selectedType;
    var strCompany = this.assigned.selectedCompany;
    var strProducts = this.assigned.selectedProduct;
    console.log("selected",strParamType,strCompany,strProducts);
    this.Apiservice.getInsurance(strParamType,strCompany,strProducts).then((response:any)=>{
      console.log("products",response);
      var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
      // response = JSON.parse(response);
      this.plans = result;
      this.assigned.selectedPlan=""
      console.log("plans",this.plans);
    })
  }

  
  InsuranceInsertDatas(){
    debugger
    if(this.data1.exist == 'YES'){
      this. customerId =this.assigned.customerid;
      var SNewCustmer = "Y";
    }
    if(this.data1.new == 'YES'){
      this. customerId = 'test';
      var SNewCustmer = "N";
    }
    console.log(this.customerId)
    var UserId = window.localStorage['userID'];
    var BranchId = window.localStorage['branchID'];
    // var SNewCustmer = "Y";
    var CustName = this.assigned.CustName;
    var Contact_Number = this.assigned.Contact_Number;
    // var Customer_DOB = this.assigned.Customer_DOB;
    var Customer_DOB = moment(this.entryMonth).format('YYYY-MM-DD');
    
    var Gender = this.assigned.Gender;

    var InsuranceType = this.assigned.selectedType;
    var Insurance_Provider = this.assigned.selectedCompany;
    var Insurance_Available_Products = this.assigned.selectedPlan; 
    var Insurance_Available_Term = this.assigned.selectedterm; 
    var Insurance_Products = this.assigned.selectedProduct;
    
    // console.log("finalInsertData",UserId,BranchId,CustName,Contact_Number,Customer_DOB,Gender,InsuranceType,Insurance_Provider,Insurance_Products,Insurance_Available_Products,this.customerId)
    if(this.data1.exist == 'YES'){
    if(this.assigned.customerid == '' ||this.assigned.customerid == undefined ||this.assigned.customerid == null){
      
      this. customerId = 'test';
    }
  }
    if(this.assigned.CustName == '' || this.assigned.CustName == undefined || this.assigned.CustName == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Customer Name.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Enter Customer Name.");
      return false;
    };
    if(this.assigned.Customer_DOB == '' || this.assigned.Customer_DOB == undefined || this.assigned.Customer_DOB == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter DOB.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Enter DOB.");
      return false;
    };

    if(this.assigned.Contact_Number == '' || this.assigned.Contact_Number ==undefined || this.assigned.Contact_Number == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Mobile Number.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Enter Mobile Number.");
      return false;
    };
    if(this.assigned.Gender == '' || this.assigned.Gender == undefined || this.assigned.Gender == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter Gender.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Enter Gender.");
      return false;
    }

    if(this.assigned.selectedType == '' || this.assigned.selectedType == undefined || this.assigned.selectedType == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select insurance type.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Select insurance type.");
      return false;
    }

    if(this.assigned.selectedCompany == '' || this.assigned.selectedCompany == undefined || this.assigned.selectedCompany == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select company type.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Select company type.");
      return false;
    }
    
    if(this.assigned.selectedPlan == '' || this.assigned.selectedPlan == undefined || this.assigned.selectedPlan == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select company type.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Select Plan.");
      return false;
    }
    if(this.assigned.selectedterm == '' || this.assigned.selectedterm == undefined || this.assigned.selectedterm == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select company type.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Select Term.");
      return false;
    }

    if(this.assigned.selectedProduct == '' || this.assigned.selectedProduct == undefined || this.assigned.selectedProduct == null){
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Select product type.</center>',
      //   title: 'Warning',
      //   scope: this,
      //   buttons:[{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // })
      // this.hidespin($ionicLoading);
      this.Alertservice.presentAlert('Warning',"Select product Category.");
      return false;
    };
   
    debugger

    if(SNewCustmer== undefined){
      SNewCustmer=''
    }else{
      SNewCustmer=SNewCustmer
    }
    if(CustName==undefined){
      CustName=''
    }else{
      CustName=CustName
    }
if(Contact_Number==undefined){
  Contact_Number=''
}else{
  Contact_Number=Contact_Number
}
  if(Customer_DOB==undefined){
    Customer_DOB=''
  }else{
    Customer_DOB=Customer_DOB
  }
   
   if(Gender==undefined){
    Gender=''
   }else{
    Gender=Gender
   }
   
   if(InsuranceType==undefined){
    InsuranceType=''
   }else{
    InsuranceType=InsuranceType
   }
    
   if(Insurance_Provider==undefined){
    Insurance_Provider=''
   }else{
    Insurance_Provider=Insurance_Provider
   }
   if(Insurance_Products==undefined){
    Insurance_Products=''
   }else{
    Insurance_Products=Insurance_Products
   }
   if(Insurance_Available_Term==undefined){
    Insurance_Available_Term=''
   }else{
    // Insurance_Available_Term=Insurance_Available_Term
    Insurance_Available_Term= this.termvalue
   }
   

   if(Insurance_Available_Products==undefined){
    Insurance_Available_Products=''
   }else{
    Insurance_Available_Products=Insurance_Available_Products
   }
   if(this.customerId==undefined){
    this.customerId=''

   } else{
    this.customerId=this.customerId
   }
   



  
    console.log("finalInsertData",UserId,BranchId,CustName,Contact_Number,Customer_DOB,Gender,InsuranceType,Insurance_Provider,Insurance_Products,Insurance_Available_Products,this.customerId)
    this.toast.presentLoading('')
    this.savebool=true                                                                                            //  string InsuranceType, string Insurance_Provider, string Insurance_Products, string Insurance_Available_Products, string customer_id,string terms)
    this.Apiservice.InsuranceInsertData(UserId,BranchId,SNewCustmer,CustName,Contact_Number,Customer_DOB,Gender,InsuranceType,Insurance_Provider,Insurance_Products,Insurance_Available_Products,this.customerId,Insurance_Available_Term).then((respose:any)=>{
      debugger
      this.savebool=false
      this.toast.dismissLoading();
      this.Alertservice.presentAlert('',JSON.parse(respose.data));
      this.resetForm();
      return false
      
      // var result = respose.data;
      //   result = JSON.parse(result);
      //   result = JSON.parse(result);
        debugger
        console.log("plans",respose);
    //   var alertPopup = $ionicPopup.alert({
    //     title: 'Submit',
    //     template: '<div align="center">Successfully Submitted.</div>'

    // }); 
    // if(result != ""){
    //   debugger
      
  
    // }
  
   
    // debugger
    },err=>{
      this.savebool=false
      this.toast.dismissLoading();
      this.Alertservice.presentAlert("","Please Try After Some Time")
    })
    
    // .error(function(error){
    //   console.log("errorsubmit",error);
    //   $ionicPopup.alert({
    //     title: 'Oops!',
    //     template: '<div align="center">Error occured.</div> '
    // });
    // })
  }
  getCustomer() {

    debugger
        var customerid = this.assigned.customerid;
        console.log(customerid);
    
        if (customerid == "" || customerid == undefined || customerid == null) {
          this.Alertservice.presentAlert("","Enter Customer Id");
          // this.Alertservice.presentAlert("","This can\'t be removed.");
          // alert('Enter Customer Id')
    
    
        } else {
          this.Apiservice.getcustomerdetails(customerid).then(response => {
            debugger
            console.log(response);
            var result = JSON.stringify(response.data);
            console.log(result);
           result = JSON.parse(result);
           result = JSON.parse(result);
           result = JSON.parse(result);
            var value =result;
            value = JSON.parse(value);
            console.log(value);
          
            console.log(value[0]);
    
    
    
            debugger
    if(value.length==0){
      this.Alertservice.presentAlert("","Please Enter the Valid Customer Id")
    }else{
    
      // window.localStorage['branchID']  
            if( value[0]['NBranch'] ==  window.localStorage['branchCode'] ){
    
    
              // this.EntryscreenForm.patchValue({
              //   firstname :value[0]['Nfirstname'],
              //   lastname :value[0]['Nlastname'],
              //   mobile :value[0]['Nmobile'],
              //   // resdphnno = this.value[0].Nresidencephone;
              //   location: value[0]['Add1'] + value[0]['Add2'] +  value[0]['Add3'] +  value[0]['Add4'],
              //   email :value[0]['Nemail']
              // })
              this.assigned.CustName=value[0]['Nfirstname']
              this.assigned.Contact_Number=value[0]['Nmobile']

    
             
            }
            else{
               
                this.Alertservice.presentAlert("","CustomerId does not Belongs to this Branch")
             
            }
          }
          })
       
        }
      }
  resetForm(){
    debugger
  
   this.assigned.customerid = '';
    this.assigned.CustName = '';
    this.assigned.Contact_Number = '';
    this.assigned.Customer_DOB = '';
    this.assigned.Gender = '';
    this.assigned.selectedType = '';
    this.assigned.selectedCompany = '';
    this.assigned.selectedProduct = '';
    this.assigned.selectedPlan = '';
    this.assigned.selectedterm=''
    
  
    
  }

  CheckBoxChange(Event,isChecked){
    console.log(isChecked);
    console.log(Event);
    // this.partB = !this.partA
    if(Event == 'exist' && isChecked == true){
    this.new = false;
    this.exist = true;
    this.data1.exist = 'YES';
    this.data1.new = 'NO';
    // this.RtgsNeftPartA();
    // this.partB = !this.partA 
if(this.data1.exist == 'YES'){
  this.exhide=true
}else if(this.data1.new == 'NO'){
  this.exhide=false
}

    this.resetForm();
    }else
    if(Event == 'new' && isChecked == true){
      this.exist = false;
      this.new = true;
      this.data1.exist = 'NO';
    this.data1.new = 'YES';
    if(this.data1.new == 'YES'){
      this.exhide=false
    }else if(this.data1.exist == 'NO'){
      this.exhide=true
    }
    // this.RtgsNeftPartB();
      // this.partB = !this.partA 
      this.resetForm();
    }
      }
      goToMyplannerPage() {
        if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
          this.router.navigate(['/regionsummary']);
    }else
        if(window.localStorage['userType']=='17')
      { this.router.navigate(['/newsummary']);}else{
        this.router.navigateByUrl('/myplanner');
      }
        // this.router.navigateByUrl('/myplanner');

      }
}
