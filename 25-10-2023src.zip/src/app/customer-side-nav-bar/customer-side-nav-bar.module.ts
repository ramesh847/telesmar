import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CustomerSideNavBarPageRoutingModule } from './customer-side-nav-bar-routing.module';
import {  HttpClientModule } from '@angular/common/http';

// import { CustomerSideNavBarPage } from './customer-side-nav-bar.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CustomerSideNavBarPageRoutingModule,
    HttpClientModule
  ],
  declarations: [],
  schemas:[CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA],
  providers:[DatePipe]
})
export class CustomerSideNavBarPageModule {}
