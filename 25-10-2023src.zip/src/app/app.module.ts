import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from  '@angular/common/http';
import { Camera, CameraOptions } from '@awesome-cordova-plugins/camera/ngx';
import { ModalmycustomerPageModule } from './modal/modalmycustomer/modalmycustomer.module';
import { MyzerocustomermodalPageModule } from './modal/myzerocustomermodal/myzerocustomermodal.module';
import { MysmacustomermodalPageModule } from './modal/mysmacustomermodal/mysmacustomermodal.module'; 
import { MyNPAcustomermodalPageModule } from './modal/my-npacustomermodal/my-npacustomermodal.module';
import { DemandcollectionPageModule } from './demandcollection/demandcollection.module';
import { OtheraccountmodalPageModule } from './modal/otheraccountmodal/otheraccountmodal.module';
import { RtgsNeftmodalPageModule } from './modal/rtgs-neftmodal/rtgs-neftmodal.module';
// import { WebView } from '@awesome-cordova-plugins/ionic-webview/ngx';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { MyfollowupvisitmodalPageModule } from './modal/myfollowupvisitmodal/myfollowupvisitmodal.module';
import { Geolocation } from '@ionic-native/geolocation/ngx';
// import { HTTP } from '@awesome-cordova-plugins/http/ngx';
import { HTTP } from '@ionic-native/http/ngx';
import { NativeGeocoder, NativeGeocoderOptions, NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
// import { HttpClientModule } from '@angular/common/http';
import { AppVersion } from '@awesome-cordova-plugins/app-version/ngx';
import { InAppBrowser } from '@awesome-cordova-plugins/in-app-browser/ngx';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
// import { TodayassignedupdatemodalPipe } from './modal/todayassignedupdatemodal.pipe';
import { TodayassignedupdatemodalPage } from './modal/todayassignedupdatemodal/todayassignedupdatemodal.page';
import { TodayassignedupdatemodalPageModule } from './modal/todayassignedupdatemodal/todayassignedupdatemodal.module';
// import { Device } from '@ionic-native/device';
// import { UniqueDeviceID } from '@ionic-native/unique-device-id';
// import { Uid } from '@ionic-native/uid/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { Device } from '@awesome-cordova-plugins/device/ngx';
import { SafePipe } from './service/safe.pipe';
import { NgxExtendedPdfViewerModule} from 'ngx-extended-pdf-viewer'
import { NgIdleModule } from '@ng-idle/core';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { BlurFirstFiveDirective } from './blur-first-five.directive';
// import { AlphapetsDirective } from './alphapets.directive'


@NgModule({
  declarations: [AppComponent, SafePipe, BlurFirstFiveDirective],
  imports: [MyfollowupvisitmodalPageModule,RtgsNeftmodalPageModule,OtheraccountmodalPageModule,DemandcollectionPageModule,
    MyNPAcustomermodalPageModule,MysmacustomermodalPageModule,MyzerocustomermodalPageModule,
    ModalmycustomerPageModule,BrowserModule, 
    IonicModule.forRoot(), AppRoutingModule,HttpClientModule,FormsModule, ReactiveFormsModule,
    FilterPipeModule,Ng2SearchPipeModule,TodayassignedupdatemodalPageModule,NgIdleModule.forRoot()],
  providers: [AndroidPermissions, { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    Camera,Geolocation,HTTP,NativeGeocoder,AppVersion,InAppBrowser,Device,NgxExtendedPdfViewerModule,  FingerprintAIO,SplashScreen
  
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
