import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { InsurancehistorypopupPage } from '../insurancehistorypopup/insurancehistorypopup.page';
import { ApiServiceService } from '../service/api-service.service';
import { AlertServiceService } from '../service/alert-service.service';
@Component({
  selector: 'app-insurancehistory',
  templateUrl: './insurancehistory.page.html',
  styleUrls: ['./insurancehistory.page.scss'],
})
export class InsurancehistoryPage implements OnInit {
cusid:any;
  userid: any;
  getinsurance:any;
  constructor(public router:Router,public modalController:ModalController,
    private ApiServiceService:ApiServiceService,public alertservice:AlertServiceService) { }

  ngOnInit() {
debugger
   this.userid= window.localStorage['userID']
   this.ApiServiceService.insurancegetdetails(this.userid).then((res:any)=>{
    debugger
  this.getinsurance= JSON.parse(JSON.parse(res.data))

   })
  }
  clicksearch(){
    debugger
    let getcusid=this.cusid

  }
  async opendetail(item){
    debugger

    if(item.track_record_id == '' || item.track_record_id == null || item.track_record_id == undefined){
this.alertservice.presentAlert("","TrackId Not Available")
return false
    }
   else{
      const modal = await this.modalController.create({
       component:InsurancehistorypopupPage,
      componentProps: { Data: item.track_record_id},
      cssClass: "insurancehistory-popup-modal-css"
     });
     return await modal.present();
    }    
    
     

  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
  }else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
    // this.router.navigateByUrl('/myplanner');
  }
}
