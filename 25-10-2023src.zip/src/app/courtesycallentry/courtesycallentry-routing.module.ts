import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CourtesycallentryPage } from './courtesycallentry.page';

const routes: Routes = [
  {
    path: '',
    component: CourtesycallentryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CourtesycallentryPageRoutingModule {}
