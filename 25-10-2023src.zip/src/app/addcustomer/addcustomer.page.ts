import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, ModalController, NavParams } from '@ionic/angular';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';

import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.page.html',
  styleUrls: ['./addcustomer.page.scss'],
  providers:[DatePipe,Idle]
})




export class AddcustomerPage implements OnInit {

  EntryscreenForm: FormGroup;
  areaUnit:string = "T";
 
  entry = {};
  CallOutcomeItems: any = [];
  entrypurpose: any = [];
  businessunit: any = [];
  showFollowupDateTime: boolean = false;
  showJointVisitLocation: boolean = false;
  jointvisitChecked: boolean = false;
  showEmployeeDetails: boolean = false;
  showBusinessUnit: boolean = true;
  captionAmount: boolean = false;
  showDepositCasaAdvance: boolean = false;
  nextcalldate1: any;
  followuptime: any;
  date: any;
  lat1: any;
  lng1: any;
  addbaselocno: any;
  showInsuranceSellproductSourceLead: boolean = false;
  insuranceType: any;
  sourceOfLead: any;
  relationofLead: any;
  showRelationofLead: boolean = false;
  accuracy: any;
  time: any;
  jointvisit1: any;
  //Geocoder configuration

address: any;
  getampm: string;
  modifytime1: any;
  modifytime2: string;
  showstarcustomer:boolean = true;
  showwishlist: boolean=false
  checked: boolean = false;
  checkedNew: boolean = true;
  showCustomerID: boolean = true;
  allsegments: any;
  wish:any={}
  wishvalue: any;
  wishchecked: any;
  starvalue: any;
  starchecked: any;
  rdm:any={}
  userid: any;
  branchid: any;
  usertype: any;
  usercode: any;
  rdmbranchrole: any;
  geetbranch:any[]=[];
  getregion:any[]=[]
  rolstaff:any[]=[]
  isrdmbool:boolean=false
  isrdmboolstar:boolean=false
  idleState: string;
  getmanager: any;
  getfc: any;
  getrmmanager: any;
  constructor(private Apiservice: ApiServiceService,
    private alertService: AlertServiceService,
    private datepipe: DatePipe,
  
    private formBuilder: FormBuilder,
    private router: Router,
  
    private modalController:ModalController,
    private loader:ToastServiceService,private navParams:NavParams,  private alert1:AlertController,public idle: Idle
   ) {  // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
       {
          // const xyz=Math.floor(time / 60);
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
       }
    );}

  ngOnInit() {
    debugger
    // this.showwishlist=true
    // let myCompOneObj = new UserprofilePage(s,s,s,s);

    // myCompOneObj.myFunctionOne();
   
   this .getSegment()
    this.checkrdmandfc()
  //  this.reset()
    // this.getGeolocation();
   
  }

  checkbox1(Event){
    debugger
    console.log(Event);
    
    if(Event.detail.checked==true){
      this.wish.JointVisitmanager = 'YES';
     
  
      // this.apiservice.rdmvisitentryrm(this.branchid).then((res:any)=>{
      //   debugger
      //   this.getmanager=JSON.parse(JSON.parse(res.data))
      // })
      this.Apiservice.rdmvisitentryagmRDM(this.branchid,this.userid).then((res:any)=>{
        debugger
        this.getmanager=JSON.parse(JSON.parse(res.data))
      })
      // rdmvisitentryagmRDM(string branchid, string userid)
    }
    else{
      this.wish.JointVisitmanager = "NO"
      this.getmanager=[]
      this.wish.joinprimarymanager=''
  
    }
    console.log(this.wish.JointVisitmanager)
  }
  checkboxagmprimary(Event){
    debugger
    if(Event){
      this.wish.jointvisitagmprimary = 'YES';
      //joint visit rm
      this.Apiservice.rdmvisitentryagmfc(this.branchid,this.userid).then((res:any)=>{
        debugger
        this.getfc=JSON.parse(JSON.parse(res.data))
      })
    }else{
      this.wish.jointvisitagmprimary = "NO"
      this.wish.textareaagmprimary=''
      this.getfc=[]
    }
  }
  selectmanager(id:any){
    debugger
    // if(id[0] == ''){
    //   this.alertservice.presentAlert("","Please select without select option")
    // }else{
    //   var tyt=id
  
    //   console.log(tyt)
    // }

   
      this.wish.primaryxyz=id
        

  }
  checkboxrmmanager(Event){
    debugger
    if(Event.detail.checked==true){
      this.wish.JointVisitrmanager = 'YES';
      this.Apiservice.rdmvisitentrymanager(this.branchid).then((res:any)=>{
        debugger
        this.getrmmanager=JSON.parse(JSON.parse(res.data))
      })
    }else{
      this.wish.JointVisitrmanager="NO"
      this.wish.joinprimaryrmmanager=''
      this.getrmmanager=[]
    }
  }
  selectmanagerrm(id){
    debugger
  
this.wish.textprimary=id
  
    

  }
  selectmanageragm(id){
    debugger
  
            this.wish.textareaagmprimary=id
       

  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    // this.timedOut = false;
  }
  checkrdmandfc(){
debugger
this.userid=window.localStorage['userID']
this.branchid=window.localStorage['branchID']
this.usertype=window.localStorage['userType']
this.usercode=window.localStorage['userCode']
this.Apiservice.getrdmrole(this.userid).then((res:any)=>{
  debugger
  this.rdmbranchrole=JSON.parse(JSON.parse(res.data))[0].role
  if(JSON.parse(JSON.parse(res.data))[0].role == 'RDM'){
    this.isrdmbool=false
    this.isrdmboolstar=false
   
    this.Apiservice.getrdmrolebybranch(JSON.parse(JSON.parse(res.data))[0].role ,this.userid).then((res)=>{
      debugger
      this.geetbranch= JSON.parse(JSON.parse(res.data))

    })
  
  }else{
    this.isrdmbool=true
    this.isrdmboolstar=true
    this.Apiservice.getrdmrolebyregion(JSON.parse(JSON.parse(res.data))[0].role ,this.userid).then((res)=>{
      debugger
     this.getregion= JSON.parse(JSON.parse(res.data))

    })
  }
})
  }
  goToMyplannerPage(){
    debugger
    this.modalController.dismiss()
  }





  // changeCallOutcome



  

  
  //geocoder method to fetch address from coordinates passed as arguments
 

  //Return Comma saperated address

   

    //wishlist functionality
    getSegment(){
      debugger
      // this.showspin();
      // debugger
      // (<HTMLInputElement>document.getElementById('selectedSegment')).value ='';
      // (<HTMLInputElement>document.getElementById('selectedProduct')).value = '';
      this.Apiservice.GetSegmentList().then((response:any)=>{
        // this.hidespin();
  // debugger
        var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
        // console.log("SegmentOptions",response);
        // response = JSON.parse(response);
        debugger
        this.allsegments = result;
        console.log("allSegments",this.allsegments)
      })
    }
  
  
    submitWishList(){
      // console.log("submit")
      debugger
     
      // this.showspin();
      var username = window.localStorage['userName'];
      var BranchId = window.localStorage['branchID'];
      var UserId = window.localStorage['userID'];
      var Branchcode = window.localStorage['branchCode'];
      // var usercode = window.localStorage['usercode'];
      
      
      var CustName = this.wish.customerName
      var MobileNo = this.wish.mobileNumber
      var EmailId = this.wish.emailID
      var Amount = this.wish.expectedAmount
      var CreditFaciities = this.wish.creditFacilities
      var Segment = this.wish.selectedSegment
      var Product = this.wish.selectedProduct
  
      if(this.wish.customerName == "" || this.wish.customerName == null || this.wish.customerName == undefined){
     
      this.alertService.presentAlert("","Please enter customer name.");
           return false;
      }else{
        var CustName = this.wish.customerName;
      };
  
      if(this.wish.mobileNumber == '' || this.wish.mobileNumber == null || this.wish.mobileNumber == undefined){
    
      this.alertService.presentAlert("","Please enter mobile number.");
           return false;
      }else{
        var MobileNo = this.wish.mobileNumber;
      };
  
      if(this.wish.selectedSegment == '' || this.wish.selectedSegment == null || this.wish.selectedSegment == undefined){
     
      this.alertService.presentAlert("","Please select activity.");
           return false;
      }else{
        var Segment = this.wish.selectedSegment;
      };
  
      if(this.wish.selectedProduct == '' || this.wish.selectedProduct == null || this.wish.selectedProduct == undefined){
     
      this.alertService.presentAlert("","Please select product.");
           return false;
      }else{
        var Product = this.wish.selectedProduct;
      };
  
     
// region branch staff

if(this.isrdmbool == true){
  if(this.wish.region == '' || this.wish.region == null || this.wish.region == undefined){
    this.alertService.presentAlert("","Please select Region")
    return false
  }else {
    var region=this.wish.region
  }

  if(this.wish.branch == '' || this.wish.branch == null || this.wish.branch == undefined){
    this.alertService.presentAlert("","Please select Branch")
    return false
  } else{
    var  branch=this.wish.branch
  }

  if(this.wish.staff == '' || this.wish.staff == null || this.wish.staff == undefined){
    this.alertService.presentAlert("","Please select Staff")
    return false
  } else{
    var  staff=this.wish.staff
  }

}else{
  if(this.wish.branch == '' || this.wish.branch == null || this.wish.branch == undefined){
    this.alertService.presentAlert("","Please select Branch")
    return false
  } else{
    var  branch=this.wish.branch
  }

  if(this.wish.staff == '' || this.wish.staff == null || this.wish.staff == undefined){
    this.alertService.presentAlert("","Please select Staff")
    return false
  } else{
    var  staff=this.wish.staff
  }
}



  
      if(this.wish.expectedAmount == '' || this.wish.expectedAmount == null || this.wish.expectedAmount == undefined){
     
      this.alertService.presentAlert("","Please Enter Expected Amount.");
           return false;
      }else{
        var Amount = this.wish.expectedAmount;
      };
  
      if(this.wish.creditFacilities == '' || this.wish.creditFacilities == null || this.wish.creditFacilities == undefined){
     
      this.alertService.presentAlert("","Please Enter Credit Facilities.");
           return false;
      }else{
        var CreditFaciities = this.wish.creditFacilities;
      };


      if(this.isrdmbool == true){
        var region=region
      }else{
        region =null
      }

     
      console.log(UserId,BranchId,Branchcode,CustName,MobileNo,EmailId,Segment,Amount,CreditFaciities,Product,region,branch,staff)
      if(!EmailId){
        // console.log("fake")
        var EmailId = null
      }
      this.loader.presentLoading('')
      this.Apiservice.RMMyWishlistCustomerInsertData(UserId,branch,Branchcode,CustName,MobileNo,EmailId,Segment,Amount,CreditFaciities,Product,region,staff,this.rdmbranchrole)
      .then((response)=>{
        debugger
        this.loader.dismissLoading()
       if(JSON.parse(response.data) == 'This entry is already exist.') {
       
        this.savepopupexist(JSON.parse(response.data))
       }else{
        this.savepopup()
       }
      // if(  JSON.parse(response.data) == 'My Wishlist Customer successfully submitted'){
      //   // this.alertService.presentAlert('',"Saved Successfully");


      //   // this.resetForm()
      // }else{
      //   this.loader.dismissLoading()
      // }
    
    
     
      })
  
      .catch((error)=> {
        debugger
        this.loader.dismissLoading()
        console.log("errorsubmit",error)
        this.alertService.presentAlert('',error.status);
       
    });
    }
   async savepopupexist(data){
    const alert:any = await this.alert1.create({
      header: "",
      cssClass:'alertHeader',
      // subHeader: 'Subtitle',
      message: data,
      buttons: [{ text     : 'Ok',
     
      
      handler: () => {
       //  this.savebool=false
       this.wish={}
       this.wish.customerName = "";
       this.wish.mobileNumber = "";
       this.wish.emailID= "";
       this.wish.expectedAmount = "";
       this.wish.creditFacilities = "";
       this.wish.selectedSegment ="";
       this.wish.selectedProduct = "";
      }
    },
   ]
    });
    return await alert.present()
   }
    async savepopup(){
      const alert:any = await this.alert1.create({
        header: "",
        cssClass:'alertHeader',
        // subHeader: 'Subtitle',
        message: "Saved Successfully",
        buttons: [{ text     : 'Ok',
       
        
        handler: () => {
         //  this.savebool=false
         this.resetForm()
        }
      },
     ]
      });
      return await alert.present()
     }

    resetForm(){
      debugger
      this.wish={}
      this.wish.customerName = "";
      this.wish.mobileNumber = "";
      this.wish.emailID= "";
      this.wish.expectedAmount = "";
      this.wish.creditFacilities = "";
      this.wish.selectedSegment ="";
      this.wish.selectedProduct = "";
      this.goToMyplannerPage()
    //  this. CheckBoxChange(this.wishvalue, this.wishchecked)
    }
    resetpage(){
      this.wish={}
      this.wish.customerName = "";
      this.wish.mobileNumber = "";
      this.wish.emailID= "";
      this.wish.expectedAmount = "";
      this.wish.creditFacilities = "";
      this.wish.selectedSegment ="";
      this.wish.selectedProduct = "";
    }
    selectregion(rdmname:any){
      debugger
      this.rdm={}
    this.geetbranch=[]
    this.rdm.staff=''
    this.rolstaff=[]
    this.rdm.type=''
   
    this.rdm.customername=''
    this.rdm.CBSCustomerID=''
    this.rdm.starcustomertype=''
    if(rdmname !=""){
    this.Apiservice.getrdmrolebybranchFC(this.rdmbranchrole,this.userid,rdmname).then((res:any)=>{
      debugger
      this.geetbranch= JSON.parse(JSON.parse(res.data))
    })
    }
    }

    selectbtranchstar(id){
      debugger
   var xyx=   this.EntryscreenForm.get('rdmstarbranch').value
   this.rdm.wishtype=''
   this.rdm.staff=''
   this.rolstaff=[]
   this.rdm.type=''
   // this.isstar=false
   // this.iswish=false
   // this.getbranchid=id
   this.rdm.customername=''
   this.rdm.CBSCustomerID=''
   this.rdm.starcustomertype=''
   this.Apiservice.rdmvisitentryrm(xyx).then((res:any)=>{
    debugger
    this.rolstaff=JSON.parse(JSON.parse(res.data))
  })
  

    }

    selectbtranch(id:any){
      debugger
    
    
    
    
    
    // this.isprimarygrid=false
    // this.primaryCustomers=[]
    this.rdm.wishtype=''
      this.rdm.staff=''
      this.rolstaff=[]
      this.rdm.type=''
      // this.isstar=false
      // this.iswish=false
      // this.getbranchid=id
      this.rdm.customername=''
      this.rdm.CBSCustomerID=''
      this.rdm.starcustomertype=''
    
    
    // this.hidetype=true
    
    
    // if(id !="" ){
    //   this.Apiservice.getrdmrolebyuser(id).then((res:any)=>{
    //     debugger
    //     this.rolstaff=JSON.parse(JSON.parse(res.data))
    //   })
    // }
    this.Apiservice.rdmvisitentryrm(id).then((res:any)=>{
      debugger
      this.rolstaff=JSON.parse(JSON.parse(res.data))
    })
    
    
    }

}
