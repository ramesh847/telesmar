import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManagergoalsheetPage } from './managergoalsheet.page';

const routes: Routes = [
  {
    path: '',
    component: ManagergoalsheetPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagergoalsheetPageRoutingModule {}
