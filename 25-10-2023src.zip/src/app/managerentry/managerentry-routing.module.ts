import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManagerentryPage } from './managerentry.page';

const routes: Routes = [
  {
    path: '',
    component: ManagerentryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagerentryPageRoutingModule {}
