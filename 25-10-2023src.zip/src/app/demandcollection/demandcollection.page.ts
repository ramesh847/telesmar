import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import { DemandcollectionmodalPage } from '../modal/demandcollectionmodal/demandcollectionmodal.page';
import { ModalController } from '@ionic/angular';
import { EndcallmodalPage } from '../modal/demandcollectionmodal/endcallmodal/endcallmodal.page';
import { Router } from '@angular/router';
import { ToastServiceService } from '../service/toast-service.service';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
@Component({
  selector: 'app-demandcollection',
  templateUrl: './demandcollection.page.html',
  styleUrls: ['./demandcollection.page.scss'],
  providers:[Idle]
})
export class DemandcollectionPage implements OnInit {
 demandcollectioncustomers:any;
 tot_demandcustomers:any;
 tot_amount_tobecollected = 0;
  branchid: string;
  callerid: string;
  mode: string;
  idleState: string;
  getnummmm: any;
  constructor(private modalController:ModalController,private Apiservice:ApiServiceService,
    private router:Router,private loader:ToastServiceService,private idle:Idle) {
      // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
        // (this.idleState = countdown.toString() )
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
    );
     }

  ngOnInit() {
    debugger
    this.branchid = window.localStorage['branchID'];
    this.callerid = window.localStorage['userID'];
    this.mode = 'S';


    this.getdemandcollectionCustomers();
    // this.reset()
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
}else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
    // this.router.navigateByUrl('/myplanner');
  }
 async customerActionModal(items){
   this.Apiservice.demandcollectionarray=[]
   this.Apiservice.demandcollectionarray.push(items,{close:"demand"})
   this.router.navigateByUrl('/demandcollectionmodal')
 }
  async callconnectscreen(item) {
    this.Apiservice.demandcollectionarray=[]
    this.Apiservice.demandcollectionarray.push(item)
    this.router.navigateByUrl('/demandcallconnect')
    // const modal = await this.modalController.create({
    // component: EndcallmodalPage,
    // componentProps: { Data: item }
    // });
    // return await modal.present();
   }
getdemandcollectionCustomers(){
  debugger
this.loader.presentLoading('')
    this.Apiservice.DemandCollectionCust(this.callerid,this.branchid,this.mode).then((res:any)=> {
            debugger
            var result = res.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
        console.log(result);
            this.demandcollectioncustomers = result 
            this.tot_demandcustomers = this.demandcollectioncustomers.length;
            this.loader.dismissLoading()
            this.demandcollectioncustomers.forEach(element => {
                this.tot_amount_tobecollected += (element.ToBeCollectedAmount)
            });
            console.log(this.tot_amount_tobecollected, this.tot_demandcustomers);

        })
}
clicknumberstar(num:any){
  debugger
 this.getnummmm= this.Apiservice.firstfivexxxx(num)
}
}
