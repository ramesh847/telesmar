import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DiarycalenderdistributionPageRoutingModule } from './diarycalenderdistribution-routing.module';

import { DiarycalenderdistributionPage } from './diarycalenderdistribution.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DiarycalenderdistributionPageRoutingModule
  ],
  declarations: [DiarycalenderdistributionPage]
})
export class DiarycalenderdistributionPageModule {}
