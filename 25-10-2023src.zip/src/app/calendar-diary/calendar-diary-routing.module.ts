import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CalendarDiaryPage } from './calendar-diary.page';

const routes: Routes = [
  {
    path: '',
    component: CalendarDiaryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CalendarDiaryPageRoutingModule {}
