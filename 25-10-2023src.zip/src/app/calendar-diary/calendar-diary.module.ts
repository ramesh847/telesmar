import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CalendarDiaryPageRoutingModule } from './calendar-diary-routing.module';

import { CalendarDiaryPage } from './calendar-diary.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CalendarDiaryPageRoutingModule
  ],
  declarations: [CalendarDiaryPage]
})
export class CalendarDiaryPageModule {}
