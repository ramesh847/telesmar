import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DiarycalenderdViewReportsPage } from './diarycalenderd-view-reports.page';

describe('DiarycalenderdViewReportsPage', () => {
  let component: DiarycalenderdViewReportsPage;
  let fixture: ComponentFixture<DiarycalenderdViewReportsPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DiarycalenderdViewReportsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DiarycalenderdViewReportsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
