import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js/auto';
import { ApiServiceService } from '../service/api-service.service';



@Component({
  selector: 'app-chartnewsummary',
  templateUrl: './chartnewsummary.page.html',
  styleUrls: ['./chartnewsummary.page.scss'],
})
export class ChartnewsummaryPage implements OnInit {

  
  getarr:any[]= ['CASA','ADVANCE','DEPOSIT','TOTAL']
  getdtata:any[]=['100','50','200','4324']
  getcolor:any[]=['deeppink','darkblue','red','green']
  Chart:any;
  livebusiness: any;
  livetarget: any;
  live3103: any;
  liveyesterday: any;
  difflivebusiness: any;
  difflive3103: any;
  diiyesterday: any;
  isdownarrow:boolean=false
  isuparrow:boolean=false
  isdownarrow2:boolean=false
  isuparrow2:boolean=false
  isdownarrow3:boolean=false
  isuparrow3:boolean=false
  date: any;
  totaldifflive3103: any;
  depositason: string;
  advanceason: string;
  deposityesterday: string;
  deposit3103: string;
  advance3103: string;
  deposittarget: string;
  advancetarget: string;
  advanceyesterday: string;
  ansdeposit: string;
  ansadvance: string;
  ansyesterday: string;
  currentdate:any
  abc:any;
  updatedate: any;
  datetarget: any;
  constructor(private apiservice:ApiServiceService) { }

  ngOnInit() {

debugger

    
this.getbusinesswisesummary()
const now = new Date();
this.currentdate=now.toLocaleString()
// let timer = setInterval(()=> {
//   debugger
//   const now = new Date();
//   this.currentdate=now.toLocaleString()
//   console.log("ramesh","time interbvel")
//   this.abc.destroy();
//   this.getbusinesswisesummary()
//   //you can stop the interval if you don't need it anymore
//   // clearInterval(timer)
// },10000 ); 

// 900000
    // var options = {
		// 	title : '3d Pie Chart JavaScript with Google Charts',
		// 	is3D : true,
		// };
   

  }
  getbusinesswisesummary(){
    debugger
   var userid= window.localStorage['userID'];
   var branchid= window.localStorage['branchID'] ;
    this.apiservice.getbusinesswisesummary(userid,branchid).then((res:any)=>{
      debugger
    let arraysummary=JSON.parse(JSON.parse(res.data));
    let updatedate=arraysummary[0].LUPDATE
   this.updatedate= updatedate.replace('T',' ')


    this.depositason=parseFloat(arraysummary[0].depositason).toFixed(2)
    this.advanceason=parseFloat(arraysummary[0].advanceason).toFixed(2)
    this.livebusiness=parseFloat(arraysummary[0].livebusiness).toFixed(2)
    this.liveyesterday=parseFloat(arraysummary[0].liveyesterday).toFixed(2)
    this.deposityesterday=parseFloat(arraysummary[0].deposityesterday).toFixed(2)
    this.advanceyesterday=parseFloat(arraysummary[0].advanceyesterday).toFixed(2)
    
    this.deposit3103=parseFloat(arraysummary[0].deposit3103).toFixed(2)
    this.advance3103=parseFloat(arraysummary[0].advance3103).toFixed(2)
    this.live3103=parseFloat(arraysummary[0].live3103).toFixed(2)
    this.deposittarget=parseFloat(arraysummary[0].deposittarget).toFixed(2)
    this.advancetarget=parseFloat(arraysummary[0].advancetarget).toFixed(2)
    this.livetarget=parseFloat(arraysummary[0].livetarget).toFixed(2)
this.date=arraysummary[0].date
this.datetarget=arraysummary[0].datetarget
    this.difflivebusiness= parseFloat(this.depositason)-parseFloat(this.deposityesterday)
   this.ansdeposit= parseFloat(this.difflivebusiness).toFixed(2)
   this.difflive3103= parseFloat(this.advanceason)-parseFloat(this.advanceyesterday)
   this.ansadvance= parseFloat(this.difflive3103).toFixed(2)
  //  this.totaldifflive3103= parseFloat(this.difflive3103).toFixed(2)
    this.diiyesterday=parseFloat(this.livebusiness)-parseFloat(this.liveyesterday)
    this.ansyesterday= parseFloat(this.diiyesterday).toFixed(2)
// let asas="700"
if(parseFloat(this.deposityesterday) < parseFloat(this.depositason)){
this.isdownarrow=false
// this.isuparrow=false
}else{
  this.isdownarrow=true
// this.isuparrow=true
}

if(parseFloat(this.advanceyesterday) < parseFloat(this.advanceason)){
  this.isdownarrow2=false
  // this.isuparrow2=false
  }else{
    this.isdownarrow2=true
  // this.isuparrow2=true
  }
  
  if(parseFloat(this.liveyesterday) < parseFloat(this.livebusiness)){
    this.isdownarrow3=false
    // this.isuparrow3=false
    }else{
      this.isdownarrow3=true
    // this.isuparrow3=true
    }
    // var ctx = document.getElementById("myChart");

    var data = {
      labels: ["DEPOSIT", "ADVANCES", "BUSINESS"],
      datasets: [{
        label: "Live",
        backgroundColor: "red",
        data: [this.depositason,this.advanceason,this.livebusiness],
        // yAxisID: "y-axis-gravity"
      }, 
      // {
      //   label: "Red",
      //   backgroundColor: "red",
      //   data: [this.deposityesterday,this.advanceyesterday,this.liveyesterday]
      // },
       {
        label: this.date,
        backgroundColor: "green",
        data: [this.deposit3103,this.advance3103,this.live3103],
        // yAxisID: "y-axis-gravity"
      },
      {
        label: "Target"+this.datetarget,
        backgroundColor: "blue",
        data: [this.deposittarget,this.advancetarget,this.livetarget],
        // yAxisID: "y-axis-gravity"
      }]
    };
    
//     var myBarChart = new Chart(ctx, {
//   type: 'bar',
//   data: data,
//   options: {
//     barValueSpacing: 20,
//     scales: {
//       yAxes: [{
//         ticks: {
//           min: 0,
//         }
//       }]
//     }
//   }
// });
if(this.abc ){
  this.abc.destroy();
}
    
   this. abc= new Chart('canvas', {
      type: 'bar',
      
      // data: {
        
      //   labels: ["LIVE","YESTERDAY",this.date,"TARGET"],
        
      //   datasets: [{
          
      //     // label: 'Viewers in millions',
      //     data: [this.livebusiness,this.liveyesterday,this.live3103,this.liveyesterday,this.livetarget],
      //     backgroundColor: this.getcolor, // array should have same number of elements as number of dataset
      //     borderColor: 'rgb(38, 194, 129)',// array should have same number of elements as number of dataset
      //     borderWidth: 1
      //   }]
      // },
      data:data,
      options: {
       
        plugins: {
          legend: {
            display: false,
          },
          
        },
        scales: {
          x: {
            ticks: {
              // autoSkip:true,
              display: true,
              
            },
          },
          y: {
            ticks: {
              display: true,
            },
          },
        },
      },
    });
    // this.abc.draw(data,options)
    debugger
    
      
    })
  }
}
