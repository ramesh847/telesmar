import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChartnewsummaryPageRoutingModule } from './chartnewsummary-routing.module';

import { ChartnewsummaryPage } from './chartnewsummary.page';
// import  {CanvasJSAngularChartsModule} from '@canvasjs/angular-charts/public-api'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChartnewsummaryPageRoutingModule,
    
  ],
  declarations: [ChartnewsummaryPage],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
})
export class ChartnewsummaryPageModule {}
