import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChartnewsummaryPage } from './chartnewsummary.page';

const routes: Routes = [
  {
    path: '',
    component: ChartnewsummaryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChartnewsummaryPageRoutingModule {}
