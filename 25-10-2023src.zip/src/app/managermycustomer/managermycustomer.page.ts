import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { MycustomerlistPage } from '../mycustomerlist/mycustomerlist.page';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';

@Component({
  selector: 'app-managermycustomer',
  templateUrl: './managermycustomer.page.html',
  styleUrls: ['./managermycustomer.page.scss'],
  providers:[Idle]
})
export class ManagermycustomerPage implements OnInit {
  userid: any;
  branchid: any;
  UserType: any;
  branchcode: any;
  branchname: any;
  branch_id: any;
  managermycustomerlist: any;
  managermycustomerlistlength: any;
  assignstartdate: any;
  assignenddate: any;
  idleState: string;

  constructor(public router:Router,public apiservice:ApiServiceService,
    public alert:AlertServiceService,private modalController:ModalController,
    private loader:ToastServiceService,private navParams:NavParams,private idle:Idle) { // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          // (this.idleState = countdown.toString() )
          {
            let idleState = countdown
            let minutes = Math.floor((idleState)/ 60);
            let extraSeconds = (idleState) % 60;
           let minutes1 = minutes < 10 ? "0" + minutes : minutes;
           let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
           this.idleState=minutes1 +':'+ extraSeconds1
           console.log(this.idleState)
          }
      );}

  ngOnInit() {
debugger
    this.userid= window.localStorage['userID']
    this.branchid= window.localStorage['branchID']
   this. UserType=window.localStorage['userType']
    let data=this.navParams.get('Data');
    this.Openrdmcustomer(data)
    // this.reset()
  }
  reset(){
    this.idle.watch()
  }
  modeldismaiss(){
    this.modalController.dismiss()
  }
 Openrdmcustomer(obj)
  {
    debugger
  	console.log(obj);
    this.branchcode = obj.BranchCode
     this.branchname = obj.BranchDescription;
console.log(this.branchname);
    var branchid = obj.BranchId;
    this.branch_id = branchid;
    this.loader.presentLoading('')
    this.apiservice.mangermycustomer(branchid)
.then((response:any)=> {
  debugger
 response = JSON.parse(JSON.parse(response.data));
 console.log(response)
 this.managermycustomerlist =response;
 this.loader.dismissLoading()
 this.managermycustomerlistlength=this.managermycustomerlist .length

 //console.log( this.goalsheetrdm)
 },err=>{
   this.alert.presentAlert("Error",err.status)
 })

  	// this.UpdateModal.show();
    this.apiservice.AssigneDdate()
    .then((response:any) =>{
        response = JSON.parse(JSON.parse(response.data));
        console.log(response);
        this.assignstartdate = response[0].StartDate;
        this.assignenddate = response[0].EndDate;
      // this.mangermap =response;
    },err=>{
      this.alert.presentAlert("Error",err.status)
    })
  }
  async mycustomerlist(item){
    debugger
    const modal = await this.modalController.create({
      component: MycustomerlistPage,
      componentProps: { Data: item ,branch:this.branch_id }
    });
    return await modal.present();
  }
}
