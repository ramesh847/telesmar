import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ManagermycustomerPageRoutingModule } from './managermycustomer-routing.module';

import { ManagermycustomerPage } from './managermycustomer.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ManagermycustomerPageRoutingModule
  ],
  declarations: [ManagermycustomerPage]
})
export class ManagermycustomerPageModule {}
