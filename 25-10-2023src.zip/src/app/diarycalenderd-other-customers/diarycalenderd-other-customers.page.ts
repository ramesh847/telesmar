import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';

@Component({
  selector: 'app-diarycalenderd-other-customers',
  templateUrl: './diarycalenderd-other-customers.page.html',
  styleUrls: ['./diarycalenderd-other-customers.page.scss'],
  providers:[DatePipe,Idle]
})
export class DiarycalenderdOtherCustomersPage implements OnInit {
  datarespending:any[]=[];
  dataresp:any[] =[];
  otherBranch:boolean
  othervip:boolean
  mystylepink: any;
  mystyleblue: any;
  datafinresp:any
  startDate: string;
  endDate: string;
  FiYear: any;
  data:any={}
  data1:any={}
  custID:any
  CustomerName:any;
  mobile:any;
  profession:any;
  diaryGiven:any;
  calendarGiven:any
  Remarks:any
  CustId:any
  customerName: any;
  datarespending1: any;
  // datarespending: any=[];
  dataresTable1: any;
  custMobile: any;
  updateScreen: boolean = false;
  dataloan:any
  res: any;
  customerType: any;
  name: any;
  leadmobile: any;
  age: any;
  docAttach: string;
  staus: string;
  mode: string;
  rowid: any;
  relativeList: {};
  loanamount: number;
  dataresplength: any;
  idleState: string;
  getnummmm:any;
  constructor(private router:Router,private apiService: ApiServiceService,
    private datepipe:DatePipe,private alert:AlertController,
    private AlertService:AlertServiceService,private loader:ToastServiceService,private idle:Idle) {  // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      );}

  ngOnInit() {
debugger

    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    var userType = window.localStorage['userType'];
    this.otherBranch = true;
    this.othervip = false;
    if(this.otherBranch == true){
      this.mystylepink= 'schedulebutnpink';
    }
    if(this.othervip == false){
      this.mystyleblue= 'schedulebutnblue';
    }  
    this.getFinanciallist();
  //  this.reset()
    // this.data.customerid = undefined;
    // this.getOtherAccount();
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  clicknumberstar(num:any){
    debugger
   this.getnummmm= this.apiService.firstfivexxxx(num)
  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
}else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
    // this.router.navigateByUrl('/myplanner');
  }
  othercustomer(val, btn){
    debugger
    console.log(val);
    var property = document.getElementById(btn);
    if(val == 1){
      this.otherBranch = true;
      this.othervip = false;
      if(this.otherBranch == true){
        this.mystylepink= 'schedulebutnpink';
      }else{
        this.mystyleblue= 'schedulebutnblue';
      }    
      this.getFinanciallist();
      //property.style.backgroundColor = "#ec0576"
    }else{
      this.otherBranch = false;
      this.othervip = true;
      if(this.otherBranch == false){
        this.mystyleblue= 'schedulebutnblue';
      }else{
        this.mystylepink= 'schedulebutnpink';
      } 
     // property.style.backgroundColor = "#2e3192"
    }
    
  }
 getFinanciallist() {
    // this.showspin();
    debugger
    this.apiService.getFinancialdata()
      .then((response:any) =>{
        // this.hidespin();
        debugger
        console.log(response.data);
        response = JSON.parse(JSON.parse(response.data));
        this.datafinresp = response.Table[0];
        console.log(this.datafinresp)
        var stDate = new Date(this.datafinresp.Start_Dt);
        this.startDate = this.datepipe.transform(stDate,'MM-dd-yyyy')  
        var endDate = new Date(this.datafinresp.End_Dt);
        this.endDate =this.datepipe.transform(endDate,'MM-dd-yyyy');
        this.FiYear = this.datafinresp.FI_YEAR;
        console.log(this.startDate);
        this.getotherBranch();
      })
      
  }

 getotherBranch() {
    // this.showspin();
    debugger
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    if(this.data.customerid == undefined){
      this. custID = 0 ;
    }else{
      this. custID = this.data.customerid ;
    }
    this.apiService.getotherbranchCust(userid, branchid, userType, this.startDate, this.endDate, this.custID)
      .then((response:any)=> {
        debugger
        // console.log(response);
        // this.hidespin();
       
        this.dataresp = JSON.parse(JSON.parse(response.data)).Table
        this.dataresplength=JSON.parse(JSON.parse(response.data)).Table.length
        console.log(this.dataresp)
      })
      // .error(function(response) {
      //   console.log(response);
      // });
  }


 saveVIPCust(data) {
    // this.showspin();
    debugger
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    console.log(data);
    if(data != undefined){
    if(data.custID == undefined){
      this.CustId= 0;
    }else{
      this. CustId= data.custID;
    }
    if(data.CustomerName == undefined){
      this. customerName= null;
    }else{
      this. customerName= data.CustomerName;
    }

    if(data.mobile == undefined){
      // this.hidespin();
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Mobile Number</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // return false;
      this. mobile= 0;
    }else{
      this. mobile= data.mobile;
    }

    if(data.profession == undefined){
      this. profession= null;
    }else{
      this. profession= data.profession;
    }

    if(data.diaryGiven == undefined){
      // this.hidespin();

      // this.saveVIPCustpopup()
      this.AlertService.presentAlert("Alert","Enter No of Diary Given")
      return false;
      
    }else{
      this. diaryGiven= data.diaryGiven;
    }

    if(data.calendarGiven == undefined){
      // this.hidespin();
      // this.saveVIPCustpopup1()
      this.AlertService.presentAlert("Alert","Enter No of Calendar Given")
      return false;
     
 
    }else{
      this. calendarGiven= data.calendarGiven;
    }

    if(data.Remarks == undefined){
      // this.hidespin();
// this.saveVIPCustpopup2()
this.AlertService.presentAlert("Alert","Enter the Remarks")
      return false;
     
    //  var Remarks= null;
    }else{
      this. Remarks= data.Remarks;
    }
    this.apiService.saveVipCust(this.CustId,this. customerName,this. mobile, this.profession, this.diaryGiven, this.calendarGiven,this. Remarks,userid)
      .then((response:any)=> {
        debugger
        // console.log(response);
        // this.hidespin();
        // response = JSON.parse(response);
        // this.dataresp = response.Table;
        // console.log(this.dataresp)
        this.AlertService.presentAlert("","Saved Successfully")
      return false;
        
      })
      this.data={};
     
  }
  }

  RNPartAModel(custID) {
   
    // this.relativeList =[];
    debugger
    this.updateScreen=true
    this.othervip=false
    this.otherBranch=false
    console.log("Openmodel")
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    this.apiService.getproductAvail(userid, branchid, userType, custID).then(response => {
      // this.RNPartAaction.show();
      debugger
      var res = JSON.stringify(response.data)
      this.res = JSON.parse(JSON.parse(JSON.parse(res)));
      

    
      this.datarespending = this.res.Table;
      this.dataresTable1 = this.res.Table1[0];
      console.log(this.datarespending)
      this.custID = this.datarespending[0].CBSCustomerId;
      this.custMobile = this.datarespending[0].Mobile;
      this.customerType = this.res.Table1[0].CustomerType;
     
      // this.customerType =this.datarespending[0].Table1[0].CustomerType;
      console.log(this.custID)
    })

    this.getLoanFacility();

    this.data.mobileNo = "N";
    this.data.emailId = "N";
    this.data.panNo = "N";
    this.data.netBanking = "N";
    this.data.mobileBanking = "N";
    this.data.debit = "N";
    this.data.aadhar = "N";
    this.data.gas = "N";
    this.data.creditCard = "N";
    this.data.mutual = "N";
    this.data.insur = "N";
    this.data.health = "N";
    this.data.group = "N";
    this.data.pos = "N";
    this.data.bharat = "N";
    this.data.fastag = "N";
    this.data.gold = "N";
    this.data.demat = "N";
    this.data.asba = "N";
    this.data.fd = "N";
    this.data.locker = "N";
  }

  getLoanFacility(){
    debugger
  
    this.updateScreen=true
    this.othervip=false
    this.otherBranch=false
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    this.apiService.getloan().then(response => {
      debugger
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      this.dataloan = res;
      debugger
    })

  }

  insertRelative(){
    debugger
    // this.relativeList=[];
    // this.rel.name = this.data1.name;
    // this.rel.mobile = this.data1.leadMobile;
    // this.rel.age = this.data1.age;
  //  this.relativeList.push(this.rel);

  //  console.log(this.relativeList)
  // this.showspin();
  if(this.data1.name == undefined){
    // this.hidespin();
    this.AlertService.presentAlert('',"Enter the Name")
    return false;

    // var myPopup = $ionicPopup.show({
    //   template: '<center>Enter the Name</center>',
    //   title: 'Alert',
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // return false;
  }else{
   this. name= this.data1.name;
  }

  if(this.data1.leadMobile == undefined){
    // this.hidespin();
    this.AlertService.presentAlert("","Enter Mobile No")
    return false;
    // var myPopup = $ionicPopup.show({
    //   template: '<center>Enter the Mobile No</center>',
    //   title: 'Alert',
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // return false;
  }else{
    this.leadmobile= this.data1.leadMobile;
  }

  if(this.data1.age == undefined){
    // this.hidespin();
    this.AlertService.presentAlert("","Enter the Age")
    return false;
    // var myPopup = $ionicPopup.show({
    //   template: '<center>Enter the Age</center>',
    //   title: 'Alert',
    //   scope: this,
    //   buttons: [{
    //     text: 'OK',
    //     type: 'button button-clear button-assertive'
    //   }]
    // });
    // return false;
  }else{
    this.age= this.data1.age;
  }

  if(this.data1.docAttach == undefined){
    this. docAttach= 'N';
  }else{
    this.docAttach= this.data1.docAttach;
  }
  this. staus ='A';
  this. mode = 'Insert';
  this. rowid = null
  var userid = window.localStorage['userID'];;
  var branchid = window.localStorage['branchID'];
  var userType = window.localStorage['userType'];

  this.apiService.saveleadcust(branchid, userid, this.custID,this. name, this.leadmobile, this.age, this.docAttach, this.staus, this.mode, this.rowid)
  .then((response:any)=> {
    debugger
    console.log(response);
    response = JSON.parse(response.data);
    // this.hidespin();
    this.AlertService.presentAlert("","Saved Successfully")
   this. getRelative()

   this.data1={}
  },err=>{
    this.AlertService.presentAlert("Error",err.status)
  })
  
    
  }
 getRelative(){
   debugger
    this.relativeList={};
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
  
    this.apiService.getleadcust(this.custID, this.customerType)
    .then((response:any)=> {
      debugger
      console.log(response);
      response = JSON.parse(JSON.parse(JSON.parse(JSON.stringify(response.data))));
      this.relativeList = response.Table;
      // this.hidespin();
      //this.relativeList.push(response);
    })
    
  }
 deleteLead(item){
    // this.showspin();
  debugger
    var name= item.NAME;
    var leadmobile= item.MOBILE;
    var age= item.AGE;
    var  docAttach= item.DOC;
    var staus ='I';
    var mode = 'Delete';
    var rowid = item.Row_Id;
    var custId = item.Customer_Id;
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
  
    this.apiService.saveleadcust(branchid, userid, custId, name, leadmobile, age, docAttach, staus, mode, rowid)
    .then((response:any) =>{
      debugger
      console.log(response);
      response = JSON.parse(response);
      // this.hidespin();
      this.AlertService.presentAlert("Success","Deleted Successfully")
      // var alertPopup = $ionicPopup.alert({
      //   title: 'Success',
      //   template: 'Deleted Successfully',
      //   onTap: function(e) {
      //   }
  
  
      // });
  this.getRelative()
     
    })
  
      
    }
    calendarEntrySave(){
      // this.showspin();
      debugger
      console.log(this.custID);
      var userid = window.localStorage['userID'];;
      var branchid = window.localStorage['branchID'];
      var userType = window.localStorage['userType'];
      var CustomerID = this.custID;
      if(this.data.facility == undefined){
        var loanreq = 'N';
        var loantype = null;
      }else{
        var loanreq = 'Y';
        var loantype = this.data.facility;
      }
      if(this.data.amount == undefined){
        this. loanamount = 0;
      }else{
        this. loanamount = this.data.amount;
      }
  
      if(this.data.remarks == undefined){
        var remarks = null;
      }else{
        var remarks = this.data.remarks;
      }
  
      if(this.data.diarygiven == undefined){
        // this.hidespin();
        this.AlertService.presentAlert("Alert","Enter the No of Diary Given")
      
        return false;
      }else{
        var diarygiven = this.data.diarygiven;
      }
     
      if(this.data.calendargiven == undefined){
        // this.hidespin();
        this.AlertService.presentAlert("Alert","Enter the No of Calendar Given")
      
        return false;
       
      }else{
        var calendargiven = this.data.calendargiven;
      }
  
      if(this.data.CustFeedback == undefined){
        // this.hidespin();
        this.AlertService.presentAlert("Alert","Enter the Remarks")
      
        return false;
       
      }else{
        var CustFeedback = this.data.CustFeedback;
      }
  
      if(this.data.mangementBroch == undefined){
        // this.hidespin();
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter the No of Diary Given</center>',
        //   title: 'Alert',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // return false;
        var managementbrochure = 'N';
      }else{
        var managementbrochure = 'Y';
      }
  
      if(this.data.paymentBroch == undefined){
        // this.hidespin();
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter the No of Diary Given</center>',
        //   title: 'Alert',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        // return false;
        var paymentBrochure = 'N';
      }else{
        var paymentBrochure = 'Y';
      }
  
      var manageUser = 0;
      
      this.apiService.calendarDiaryEntry(branchid, userid, userType, CustomerID, this.data.mobileNo, this.data.emailId, this.data.panNo, this.data.netBanking, this.data.mobileBanking, this.data.debit, this.data.aadhar, this.FiYear, managementbrochure, paymentBrochure, manageUser)
      .then((response:any)=> {
        debugger
        console.log(response);
        var res = JSON.stringify(response.data);
      response = JSON.parse(res);
      //  if(response == 'S'){
        this.loader.presentLoading('')
          this.apiService.calendarDiaryEntryData(CustomerID, this.data.creditCard, this.data.mutual, this.data.insur, this.data.health, this.data.group, this.data.pos, this.data.bharat, this.data.fastag, this.data.gold, this.data.demat, this.data.asba, this.data.fd, this.data.locker,loanreq, loantype, this.loanamount, remarks, diarygiven, calendargiven, CustFeedback)
          .then((response:any) =>{
            this.loader.dismissLoading()
            debugger
            console.log(response);
            response = JSON.parse(JSON.parse(JSON.stringify(response.data)));
            // this.hidespin();
            if(response == 'S'){
              this.AlertService.presentAlert("Success","Saved Successfully")
              this.data = {};
              this.data1 = {};
              this.relativeList = {};
            this.goToMyplannerPage1()
           
             
          }
          })  
         
      //  }
      })
     
    }
    sendSms(type){
      // $scope.showspin();
      var userid = window.localStorage['userID'];;
      var branchid = window.localStorage['branchID'];
      var userType = window.localStorage['userType'];
      if(type == 1){
        var mode = 'SGB';
      }else if(type == 2){
        mode = 'Demat';
      }else{
        mode = 'VKYC';
      }
      // console.log($scope.custMobile)
    this.apiService.DCDSmsSend(userid, this.custMobile, mode)
    .then((response:any)=> {
      console.log(response);
      response = JSON.parse(JSON.stringify(response.data));
      
      // $scope.hidespin();
      if(response == 'SMS Sent'){
        this.AlertService.presentAlert("Success","Saved Successfully")
     
  
     
    }else{
      this.AlertService.presentAlert("Alert","Mobile Number Not Updated")
      return false
     
  
    
    }
    })  
  
    }
    sendSmsVkyc(type) {
      // this.showspin();
      var userid = window.localStorage['userID'];
      if (this.data1.leadMobile == undefined) {
        this.AlertService.presentAlert('Warning',"Enter the Lead Customer mobile Number");
        // var myPopup = $ionicPopup.show({
        //   template: '<center>Enter the Lead Customer mobile Number</center>',
        //   title: 'Alert',
        //   scope: this,
        //   buttons: [{
        //     text: 'OK',
        //     type: 'button button-clear button-assertive'
        //   }]
        // });
        return false;
      }
      var mode = 'VKYC';
      console.log(this.custMobile)
      this.apiService.DCDSmsSend(userid, this.data1.leadMobile, mode).then(response => {
        var res = JSON.parse(response.data);
        res = JSON.parse(res);
        if (res == 'SMS Sent') {
          this.AlertService.presentAlert('Success',"SMS Sent Successfully");
          // var alertPopup = $ionicPopup.alert({
          //   title: 'Success',
          //   template: 'SMS Sent Successfully',
          //   onTap: function (e) {
          //   }
          // });
  
          // alertPopup.then(function (res) {
          // });
        }
      })
  
    }

    goToMyplannerPage1(){
      this.updateScreen=false
      this.othervip=false
      this.otherBranch=true
      this.getFinanciallist()
    }

}
