import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DiarycalenderdOtherCustomersPage } from './diarycalenderd-other-customers.page';

const routes: Routes = [
  {
    path: '',
    component: DiarycalenderdOtherCustomersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DiarycalenderdOtherCustomersPageRoutingModule {}
