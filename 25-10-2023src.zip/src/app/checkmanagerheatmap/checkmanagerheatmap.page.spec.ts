import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CheckmanagerheatmapPage } from './checkmanagerheatmap.page';

describe('CheckmanagerheatmapPage', () => {
  let component: CheckmanagerheatmapPage;
  let fixture: ComponentFixture<CheckmanagerheatmapPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckmanagerheatmapPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CheckmanagerheatmapPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
