import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';
import { ManagerheatmapdetailPage } from '../modal/managerheatmapdetail/managerheatmapdetail.page';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import { ToastServiceService } from '../service/toast-service.service';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
@Component({
  selector: 'app-checkmanagerheatmap',
  templateUrl: './checkmanagerheatmap.page.html',
  styleUrls: ['./checkmanagerheatmap.page.scss'],
  providers:[Idle]
})
export class CheckmanagerheatmapPage implements OnInit {
  userid: any;
  branchid: any;
  UserType: any;

  showitemcard: boolean = false
  showitemlist: boolean = true
  segment: string = 'indivuduals';
  arr = new Array(25);
  BranchCode: any;
  BranchDescription: any;
  BranchID: any;
  rdmname: any;
  managerindividuals: any;
  mangerbranchs: any;
  individuals: any;
  branchlist: any;
  assignstartdate: any;
  assignstartend: any;
  index: 1;
  mangermap: any;
  individualslength: any;
  mangermaplength: any;
  idleState: string;
  constructor(public apiservice: ApiServiceService,
    public alert: AlertServiceService, private modalController: ModalController,
    public router:Router,private loader:ToastServiceService,private idle:Idle) { 
      // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
        // (this.idleState = countdown.toString() )
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)

        }
    );
    }

  ngOnInit() {
    
  this.userid = window.localStorage['userID']
    this.branchid = window.localStorage['branchID']
    this.UserType = window.localStorage['userType']
    this.heatdisplay()
    // this.reset()
   
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  segmentChanged(ev: any) {
    this.segment = ev.detail.value;
  }

  cardshowbranch() {
    this.showitemcard = true
    this.showitemlist = false
  }
  tableshowbranch() {
    this.showitemcard = false
    this.showitemlist = true
  }
  heatdisplay()
  {
    
    this.loader.presentLoading('')
      this.apiservice.getheapmapbranchname(this.userid, this.branchid)
  .then((response:any) =>{
    
    this.loader.dismissLoading()
      response = JSON.parse(JSON.parse(response.data));
      console.log(response);
     this.individuals =response;
     this.individualslength=response.length
  })
  // this.loader.presentLoading('')
  this.apiservice.getheapmap(this.userid,this. branchid)
    .then((response:any)=> {
      // this.loader.dismissLoading()
        response = JSON.parse(JSON.parse(response.data));
        console.log(response);
       this.mangermap =response;
       this.mangermaplength=response.length
    })

    this.apiservice.AssigneDdate()
    .then((response:any) =>{
      
        response = JSON.parse(JSON.parse(response.data));
        console.log(response);
       this.assignstartdate =response[0].EndDate;
       this.assignstartend=response[0].StartDate;
    })

  }

  async getindivudualsdetails(items) {
    
    const modal = await this.modalController.create({
      component: ManagerheatmapdetailPage,
      componentProps: { Data: items, }
    });
    return await modal.present();
  }
  modeldissmiss(){
    this.router.navigateByUrl('/newsummary')
  }

}
