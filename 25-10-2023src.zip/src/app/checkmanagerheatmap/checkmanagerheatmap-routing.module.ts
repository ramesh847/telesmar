import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CheckmanagerheatmapPage } from './checkmanagerheatmap.page';

const routes: Routes = [
  {
    path: '',
    component: CheckmanagerheatmapPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckmanagerheatmapPageRoutingModule {}
