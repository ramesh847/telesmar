import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';

import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';
import CryptoJS from 'crypto-js';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ToastServiceService } from '../service/toast-service.service';

@Component({
  selector: 'app-forgotpwd',
  templateUrl: './forgotpwd.page.html',
  styleUrls: ['./forgotpwd.page.scss'],
  providers:[DatePipe]
})
export class ForgotpwdPage implements OnInit {
  logindata: any={};
  dob: any;
  res: any;
  otp: any;
  invalidOTP: boolean=false;
  usercode: any;
  resver: any;
  showUpdatepwd: boolean=false;
  showVerify: boolean=true;
  pwdcheck1: boolean=false;
  pwdcheck2: boolean=false;
  resupdate: any;
  showotpdiv:boolean=false;
  user_name:any;
  userEncrypted:any;
  pwdEncrypted:any;
  usercodeencrypted:any;
  pwdEncrypteddd:any;
  dateToday:any;
  bbbvversion: any;
  // dob:any
  // showUpdatepwd:boolean=false

  constructor(private datepipe:DatePipe,private AlertService:AlertServiceService,private router: Router,
    private Apiservice:ApiServiceService, private alert:AlertController,private loader: ToastServiceService) { }

  ngOnInit() {
    debugger
    this.dateToday = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
    this.showotpdiv = false
    this.showUpdatepwd=false
    this.showVerify=true
  }
  test_str(id){ 
    debugger
    // console.log(id,document.getElementById(id).value);
    var res; 
    var str = this.logindata.pwd; 
    // console.log(str);
    
    if (str.match(/[a-z]/g) && str.match( 
            /[A-Z]/g) && str.match( 
            /[0-9]/g) && str.match( 
            /[^a-zA-Z\d]/g) && str.length >= 8){
                // $scope.pwdcheck1 = false;
            if(id == "pwd"){
               this.pwdcheck1 = false;
            }
            if(id == "cnfpwd"){
                this.pwdcheck2 = false;
            }
            }
    else {
        // res = "FALSE"; 
        // $scope.pwdcheck1 = true;
        if(id == "pwd"){
            this.pwdcheck1 = true;
        }
        if(id == "cnfpwd"){
            this.pwdcheck2 = true;
        }
    }

    if(id == 'pwd' && this.logindata.pwd == '') this.pwdcheck1 = false;
    if(id == 'cnfpwd' && this.logindata.pwd == '') this.pwdcheck2 = false;
    // document.getElementById(id).value = res; 
    

} 

  sendOtp() {
    debugger
    // this.showotpdiv = true;
    //this.showspin();
    // if(this.logindata.user_name == undefined || this.logindata.user_name == '' && this.logindata.dob == undefined || this.logindata.dob == ''){
    //     var alertPopup = $ionicPopup.alert({
    //         title: 'alert',
    //         template: 'Enter the Emp Code'
    //     });
    //     return false;
    // }
    if(this.logindata.user_name == undefined || this.logindata.user_name == null || this.logindata.user_name == ''){
       // this.hidespin($ionicLoading);
       this.AlertService.presentAlert("","Enter the Emp Code")
        // var alertPopup = $ionicPopup.alert({
        //     title: 'alert',
        //     template: 'Enter the Emp Code'
        // });
        return false;
    }

    if(this.logindata.dob == undefined || this.logindata.dob == null || this.logindata.dob == ''){
       // this.hidespin($ionicLoading);
       this.AlertService.presentAlert("","Enter the DOB")
        // var alertPopup = $ionicPopup.alert({
        //     title: 'alert',
        //     template: 'Enter the DOB'
        // });
        return false;
    }

    this.dob = this.datepipe.transform( this.logindata.dob,'dd-MM-yyyy')
    
   // $filter('date')(this.logindata.dob, 'dd-MM-yyyy');
    console.log(this.dob);
    debugger
    this.loader.presentLoadinglogin('')
    this.Apiservice.sendOTP(this.logindata.user_name,this.dob,  parseFloat(localStorage.getItem('ver')) )
        .then((response:any)=> {
          debugger
          this.loader.dismissLoading()
            console.log(response.data)
            
            this.res= JSON.parse(JSON.parse(response.data));
           // this.hidespin($ionicLoading);
            if(this.res == 'OTP Sent Successfully'){

              this.AlertService.presentAlert("",this.res)
              this.showotpdiv = true;
              this.showVerify=false
              this.showUpdatepwd=false
               
            }else if(this.res == 'Kindly Download telesmart app www.cityunionbank.com/telesmart'){
              this.godownload()
            }
            
            
            else{
                // this.hidespin($ionicLoading);

                this.AlertService.presentAlert("",this.res)
                // var alertPopup = $ionicPopup.alert({
                //     title: 'Alert',
                //     template: this.res
                // });

                // alertPopup.then(function (res) {
                //     this.logindata = {};
                // });
            }

        })

     
}

async godownload(){
  debugger
  const alert = await this.alert.create({
    header: '',
    cssClass: 'alertHeader',
    // subHeader: 'Subtitle',
    message: 'Kindly Download telesmart app www.cityunionbank.com/telesmart',
    buttons: [{
      text: 'Ok',


      handler: () => {
        window.open('https://cityunionbank.com/telesmart/', '_system');
      }
    }],
    // {
    //     text: 'No',
  
    //     handler: () => {
        
    //     }}]
  })
  await alert.present()
}
verifyfwdotp(){
  debugger
  var base64Key = CryptoJS.enc.Utf8.parse('7b3e4c8e58d5c4f22e86c92a4a3a8a25');
  console.log(base64Key)
    var iv = CryptoJS.enc.Utf8.parse('2a4fc2da7e2a9e68');
  //  this.invalidOTP = false;
  // this.showUpdatepwd = true;
  // // this.logindata = {};
  // this.showVerify= false;

this.otp = this.logindata.otp; 
console.log(this.otp);
if(this.otp == undefined){
// this.hidespin($ionicLoading);
}else{
if(this.otp.toString().length != 6){
this.invalidOTP = true;
}else{
this.invalidOTP = false;
}
}
if(this.otp != undefined || this.otp != null || this.otp != '' || this.otp != 'undefined'|| this.otp != 'null'){

//  = this.logindata.user_name;

 this.usercode = this.logindata.user_name.toString();
this.usercodeencrypted= CryptoJS.AES.encrypt(this.usercode,base64Key,{ iv: iv });
// console.log('userEncrypted = ' +  $scope.userEncrypted);
var userCode1=  this.usercodeencrypted.toString();
var otpc = this.otp.toString();
this.pwdEncrypteddd = CryptoJS.AES.encrypt(otpc,base64Key,{ iv: iv });
// console.log('pwdEncrypted = ' + $scope.pwdEncrypted);
var otpt =  this.pwdEncrypteddd.toString();

var vcredit={
  UserCode:userCode1,
  OTP:otpt
}



this.Apiservice.verifyfwdOTP(vcredit)
.then((response:any) =>{
  debugger
console.log(response)
this.resver= JSON.parse(response.data);
// this.hidespin($ionicLoading);
if(this.resver == 'Given OTP Valid'){
  // var alertPopup = $ionicPopup.alert({
  //     title: 'Success',
  //     template: this.res
  // });

  // alertPopup.then(function (res) {
  //     this.showotpdiv = true;
  // });
  this.invalidOTP = false;
  this.showUpdatepwd = true;
  this.showotpdiv=false;
  // this.logindata = {};
  this.showVerify= false;

}else{
 // this.hidespin($ionicLoading);
  this.invalidOTP = true;
  // var alertPopup = $ionicPopup.alert({
  //     title: 'Alert',
  //     template: this.res
  // });

  // alertPopup.then(function (res) {
  //     this.logindata = {};
  // });
}

})


}else{
// this.hidespin($ionicLoading); 
}
}
updatePwd(code){
  debugger
  
  var base64Key = CryptoJS.enc.Utf8.parse('7b3e4c8e58d5c4f22e86c92a4a3a8a25');
  console.log(base64Key)
    var iv = CryptoJS.enc.Utf8.parse('2a4fc2da7e2a9e68');
  //this.showspin();
  if(this.logindata.pwd == undefined || this.logindata.pwd == null || this.logindata.pwd == ''|| this.logindata.pwd == 'undefined'){
     // this.hidespin($ionicLoading);
     this.AlertService.presentAlert("","Enter the New Password")
      // var alertPopup = $ionicPopup.alert({
      //     title: 'Alert',
      //     template: 'Enter the New Password'
      // });
      return false;
  }
  if(this.logindata.cnfpwd == undefined || this.logindata.cnfpwd == null || this.logindata.cnfpwd == ''|| this.logindata.cnfpwd == 'undefined'){
      // this.hidespin($ionicLoading);
      this.AlertService.presentAlert("","Enter the Confirm Password")
      // var alertPopup = $ionicPopup.alert({
      //     title: 'Alert',
      //     template: 'Enter the Confirm Password'
      // });
      return false;
  }    
     
  if(this.logindata.pwd == this.logindata.cnfpwd && this.pwdcheck1 == false&& this.pwdcheck2 == false){  
      // console.log($rootScope.usercode,this.logindata.pwd,this.logindata,code);
      // callAPI.updatePWD($rootScope.usercode,this.logindata.pwd)
      // this.logindata.user_name=9820
      var userName = this.logindata.user_name.toString();
      this.userEncrypted = CryptoJS.AES.encrypt(userName,base64Key,{ iv: iv });
    // console.log('userEncrypted = ' +  this.userEncrypted);
   
     var userCode=  this.userEncrypted.toString();
     console.log("userCode",userCode)
     var pwd1=this.logindata.pwd.toString();
     this.pwdEncrypted = CryptoJS.AES.encrypt(pwd1,base64Key,{ iv: iv });
  // console.log('pwdEncrypted = ' + this.pwdEncrypted);
  var Pwd =  this.pwdEncrypted.toString();
  console.log("Pwd",Pwd)
  var vversion=localStorage.getItem('ver').toString()
this.bbbvversion = CryptoJS.AES.encrypt(vversion, base64Key, { iv: iv });
// console.log('pwdEncrypted = ' + $scope.pwdEncrypted);
var vrversion = this.bbbvversion.toString();



  
      var obj ={
        strUserCode:userCode,
        strPassword:Pwd,
        // Version:vrversion
      }

      this.Apiservice.updatePWD(obj)
      .then( (response:any)=> {
        debugger





          console.log(response)
          this.resupdate= JSON.parse(response.data);
          // this.hidespin($ionicLoading);
          if(this.resupdate == 'Password Updated Successfully'){
            // this.AlertService.presentAlert("Alert","Updated Succesfully")

            this.passmethod()
           

             
          }else{
             // this.invalidOTP = true;
            //  this.hidespin($ionicLoading);
            this.AlertService.presentAlert("",this.resupdate)
              // var alertPopup = $ionicPopup.alert({
              //     title: 'Alert',
              //     template: this.resupdate
              // });

              // alertPopup.then(function (res) {
              //     this.logindata = {};
              // });
          }

      })

      // .error(function (response) {
      //     console.log(response);
      //     this.hidespin($ionicLoading);
      // });
  }else{
      // this.hidespin($ionicLoading);
      this.AlertService.presentAlert("","Enter the vaild Password")
      // var alertPopup = $ionicPopup.alert({
      //     title: 'Alert',
      //     template: 'Enter the vaild Password'
      // });
      this.logindata.pwd='';
      this.logindata.cnfpwd='';
      this.pwdcheck1 = false;
      this.pwdcheck2 = false;
  } 

  
}
async passmethod(){
  const alert:any = await this.alert.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Password Updated Successfully",
    buttons: [{ text     : 'Ok',
   
    
    handler: () => {
      this.router.navigate(['/login'])
    }
  }]
  });
  await alert.present()
}
}
