import { Component } from '@angular/core';
import * as moment from "moment"; 
import { Router } from '@angular/router';
import { ApiServiceService } from './service/api-service.service';
// import { AppVersion } from '@awesome-cordova-plugins/app-version/ngx';
import { AlertController, IonRouterOutlet, ModalController } from '@ionic/angular';
import { MenuController } from '@ionic/angular';
import { AlertServiceService } from './service/alert-service.service';
// import { UniqueDeviceID } from '@ionic-native/unique-device-id';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { Device } from '@awesome-cordova-plugins/device/ngx';
import { Platform } from '@ionic/angular';
// import { AppVersion} from '@ionic-native/app-version/ngx'
import { AppVersion } from '@ionic-native/app-version/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx'
import {NotificationpopupPage} from '../app/modal/notificationpopup/notificationpopup.page'
import { Idle, DEFAULT_INTERRUPTSOURCES, IdleExpiry } from "@ng-idle/core";
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { TrialnotifyPage } from './trialnotify/trialnotify.page';
import { ToastServiceService } from './service/toast-service.service';
import { Network } from '@ionic-native/network/ngx';
import { DatePipe } from '@angular/common';
import { SplashScreen } from '@ionic-native/splash-screen/ngx'
declare var rootdetection:any;
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  providers:[IonRouterOutlet,AppVersion,Geolocation,LocationAccuracy,Idle,DatePipe,Network,AndroidPermissions,SplashScreen]
})
export class AppComponent {
 appPages:any[]=[]  
showmenu: boolean = false;
  Date: string;
  Branchcode: any;
  Username: any;
  resptest: any;
  interval: any;
sharedData: string;
  subscription: any;
  rootedid: any;
  utype: string;
  ionVersionNumber: string;
  captchares: any;
  idleState: any;
  timedOut :boolean=false
  notifycontent: any;
  mydata: any;
  logindata: {};
  footername: any;
  username: any;
  notifyjson: any;
  notifydate: string;
  latitude: any;
  longitude: any;
  accuracy: any;
  timestamp: any;
  ttogle:any;
  constructor(private platform:Platform,private device: Device,private menu: MenuController,private alert:AlertController,
    private alertService: AlertServiceService,
    private appVersion: AppVersion,private router:Router,private service:ApiServiceService,  
    private androidPermissions: AndroidPermissions,private geolocation: Geolocation, private LocationAccuracy: LocationAccuracy,
    public modalController: ModalController,public idle: Idle,private faio: FingerprintAIO,
    private authService: ApiServiceService, 
    private menuCtrl: MenuController, private loader: ToastServiceService,
   private datepipe:DatePipe,private network: Network, public _SplashScreen: SplashScreen) {
    debugger
    console.log('Device UUID is: ' + this.device.uuid);


    // this.timedOut=true
    // // sets an idle timeout of 5 seconds, for testing purposes.
    // this.idle.setIdle(5);
    // // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    // this.idle.setTimeout(20);
    // // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    // this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
   
    // this.idle.onIdleEnd.subscribe(() => 
    // (this.idleState = "No longer idle.")
    // );

    // this.idle.onTimeout.subscribe(() => {

    //   this.router.navigate(['sessionout'])
    //   // this.idleState = "Timed out!";
    // //  this.timedOut = true;
    // });
    // this.idle.onIdleStart.subscribe(
    //   () => (this.idleState = "You've gone idle!")
    // );
    // this.idle.onTimeoutWarning.subscribe( countdown =>{
    //  this.idleState = "session time out " + countdown + " seconds!"
    // }
       
    // );
    

    this._SplashScreen.hide();

    platform.ready().then((res) => {
      // SplashScreen.hide()
      // _SplashScreen.hide()
     
      setTimeout(() => {
        this._SplashScreen.hide();
      }, 3000);
        
     
      // this._SplashScreen.hide();
      console.log(this.device.uuid);
      console.log("device platform",this.device.platform)  ;
console.log("device modal",this.device.model)
      console.log("device version", this.device.version)
      window.localStorage.deviceID=this.device.uuid
      console.log("xyz",window.localStorage.deviceID)
      console.log(res)
      
    //get app version
      this.appVersion.getVersionNumber().then(res => {
        this.ionVersionNumber = res;
        localStorage.setItem('ver',this.ionVersionNumber)
        console.log("versionnumber",this.ionVersionNumber)
      })

      // find root dedection
      rootdetection.isDeviceRooted((data:any) => {
        this.rootedid=data
        if (this.rootedid && this.rootedid == 1) {
          // this.alertService.presentAlert("","This is Rooted Device")
        navigator["app"].exitApp()
         
            console.log("This is routed device");
            
      
  
  // alert("this is rooted device")
        } else {
         
        
          console.log("routed device detection failed case", this.rootedid);
            console.log("check rooted device:","This is not routed device");
        }  
    })

  
   })


   
   this.platform.backButton.subscribeWithPriority(1, () => {
     debugger
    // if (!this.routerOutlet.canGoBack()) {
      this.backmethod()
      // navigator["app"].exitApp();
    // }
  });
 
 


     this.service.sharedData$
    .subscribe((sharedData:any) =>{ 
      debugger
      // this.reset()
      // this.sessionout()
      // this.sharedData = sharedData
      if( window.localStorage['biomatric'] == 'biometric_success'){
        // this.router.navigate(['login']);
        //  this.showFingerprintAuthDlg1()
           this.ttogle='true'
        }else{
          this.ttogle='false'
            // this.router.navigate(['login']);
        }

// if(window.localStorage['branchID'] == '32'){
//   this.appPages = [
//     { title: 'Live Business Summary', url: '/livesummary', icon: 'information-circle' },]
  
// }else{

      if (sharedData == 17) {
        // $state.go('app.newsummary');
        // this.openpopup()
       
        this.appPages = [
        //  {title:'circular', url:'/pfdshow',icon:'disc' },
        // {title :'livebusiness',url: '/chartnewsummary', icon: 'newspaper'},
        {title :'Posters',url: '/poster', icon: 'newspaper'},
          { title: 'Notification', url: '/notification', icon: 'information-circle' },
          { title: 'User Profile', url: '/userprofile', icon: 'person' },
          { title: 'Manager Entry Screen', url: '/entryscreen', icon: 'call' },
          { title: 'Live Business Summary', url: '/chartnewsummary', icon: 'information-circle' },
          { title: 'My Customers',icon: 'people',
          arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
          children: [
            { title: 'My Star Customers', url: 'mystarcustomers' },
            { title: "'0' Star Customers", url: 'zerostarcustomers' },
            { title: 'My SMA Customers', url: 'mysmacustomers' },
            { title: 'My NPA Customers', url: 'mynpacustomers' },
            { title: 'Demand Collection', url: 'demandcollection' },
            { title: 'Other Accounts', url: 'otheraccounts' },
          ]},
          { title: 'My Calls', icon: 'call',
          arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
          children: [
            { title: 'My Assigned Calls', url: '/myassignedcall' },
            { title: "My FollowUp Calls", url: '/myfollowupcall' },
            { title: 'Common Calls', url: '/commoncall' },
        
          ],
          
       },
        
          
        
         
       { title: 'My Visits', icon: 'briefcase',
       arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
       children: [
         { title: 'My Assigned Visits', url: '/myassignedvisits' },
         { title: "My FollowUp Visits", url: '/myfollowupvisits' },
         { title: 'Common Visits', url: '/commonvisit' },
      
       ],
      },
      
       { title: 'My Leads', icon: 'cube',arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
          children: [
            { title: 'Followup Leads', url: 'followup-leads' },
            { title: "Express Leads", url: 'express-leads' },
            { title: 'RTGS/NEFT', url: 'rtgs-neft' },
        
          ],
          
       },
       { title: 'My Monthly Planner', icon: 'flash-off-sharp',arrow:'chevron-forward-outline',
      arrow2: 'chevron-down-outline',
         children: [
           { title: 'Monthly Telecalls', url: 'monthlytelecals' },
           { title: "Monthly Visits", url: 'monthlyvisits' },
           
       
         ],
         
      },
      { title: 'Potential Star', url: '/potentialstar', icon: 'star' },
      { title: 'Advance Commitment', url: '/advancecommitment', icon: 'build' },
       { title: 'My Diary', url: '/mydiarybranch', icon: 'book' },
       { title: 'My Planner', url: '/myplanner', icon: 'build' },
       { title: 'Branch Business Summary', url: '/newsummary', icon: 'aperture' },
       { title: 'Manager Goal Sheet', url: '/managergoalsheet', icon: 'aperture' },
      { title: 'Performance Dashboard', icon: 'clipboard', url:'/performancedashboard'},
      //  { title: 'Heat map', url: '/managerheatmap', icon: 'compass' },
       
       { title: 'Heat map', url: '/checkmanagerheatmap', icon: 'compass' },
       { title: 'Visit',icon: 'medical',arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
       children: [
         { title: 'Visit Entry',url: '/mvisitentry' },
        { title: "Visit Entry Report", url: '/mvisitreport' },
        {title:"More than 4 Wishlist Visit",url:'/mvisitnoofvisit'}
       ]},
       { title: 'Click to call Report', url: '/clicktocallcustomer', icon: 'call' },
      { title: 'Exception Report', url: '/exceptionreport', icon: 'logo-dropbox' },
       { title: 'My wish List',icon: 'apps',arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
       children: [
         { title: 'Add Customer', url: 'mywishaddcustomer' },
         { title: "Primary Customer", url: 'mywishprimarycustomer' },
         { title: 'Secondary Customer', url: 'mywishsecondarycustomer' },
         { title: 'FollowUp', url: 'mywishfollowup' },
         { title: 'Conversions', url: 'mywishconversions' },
        //  { title: 'Other Account', url: 'otheraccounts' },
       ]},
       
       { title: 'Insurance',icon: 'medical',arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
       children: [
         { title: 'Add Insurance', url: 'addinsurance' },
         { title: "Insurance Customer", url: 'insurancecustomer' }
       ]},
       { title: 'Insurance Status History', url: '/insurancehistory', icon: 'file-tray-stacked' },
       { title: 'Diary Calendar Distribution', url: '/diarycalenderdistribution', icon: 'calendar' },
       { title: 'OtherLink', url: 'mylink', icon: 'link' },
      //  { title: 'Unit NewVisit Report', url: 'uvrnewreport', icon: 'cog' },
       { title: 'Unit Visit Report', url: 'unitvisitreport', icon: 'cog' }
      //  { title: 'Logout', url: 'login', icon: 'person' },
     
         
        ];
  
      } else if (sharedData == 14 || sharedData == 26) {
        // this.openpopup();
//RDM
if(sharedData == 14)
{
        this.appPages = [
          // {title:'circular', url:'/pfdshow',icon:'disc' },
          {title :'Posters',url: '/poster', icon: 'newspaper'},
          { title: 'Notification', url: '/notification', icon: 'information-circle' },
          { title: 'User Profile', url: '/userprofile', icon: 'person' },
          { title: 'Live Business Summary', url: '/livesummary', icon: 'information-circle' },
          // { title: 'Business Summary',icon: 'paper-plane',arrow:'chevron-forward-outline',
          // arrow2: 'chevron-down-outline',
          // children: [
          //   { title: 'Region Summary', url: '/regionsummary' },
          //   { title: "Branch Summary", url: '/newsummary' }
          // ]},



          { title: 'Business Summary', url: '/regionsummary', icon: 'paper-plane' },
          { title: 'GoalSheet', url: '/regiongoalsheet', icon: 'aperture' },
          { title: 'Star Customer', url: '/regionstarcustomer', icon: 'star' },
          { title: 'Click to call Report', url: '/clicktocallcustomer', icon: 'call' },
          { title: '10-3-1 Report', url: '/regionreport', icon: 'albums' },
          { title: 'Planner', url: '/rdmplanner', icon: 'paper-plane' },
          { title: 'Lead/Telecall Summary', url: '/rdmleadlelecall', icon: 'locate' },
          { title: 'Heatmap', url: '/regionheatmap', icon: 'map' },
          { title: 'Advance Commitment', url: '/rdmadvancecommitment', icon: 'build' },
          { title: 'Visit',icon: 'medical',arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
       children: [
         { title: 'Visit Entry',url: '/visitenrty' },
        { title: "Visit Entry Report", url: '/visitreport' },
        {title:"More than 4 Wishlist Visit",url:'/visitnumberofvisit'}
       ]},
          // {title :'Visit Entry',url: '/visitenrty', icon: 'chatbox'},
          // {title :'Add Customer',url: '/addcustomer', icon: 'person-add'},
          // { title: 'checksession', url: '/pdfview', icon: 'calendar' },
       { title: 'Diary Calendar Distribution', url: '/diarycalenderdistribution', icon: 'calendar' },
       { title: 'OtherLink', url: 'mylink', icon: 'link' },
      //  { title: 'Unit NewVisit Report', url: 'uvrnewreport', icon: 'cog' },
       { title: 'Unit Visit Report', url: 'unitvisitreport', icon: 'cog' }
      //  { title: 'Logout', url: 'login', icon: 'person' },
     
        ];
      }else{
         this.appPages = [
          // {title:'circular', url:'/pfdshow',icon:'disc' },
          {title :'Posters',url: '/poster', icon: 'newspaper'},
          { title: 'Notification', url: '/notification', icon: 'information-circle' },
          { title: 'User Profile', url: '/userprofile', icon: 'person' },

          // { title: 'Business Summary',icon: 'paper-plane',arrow:'chevron-forward-outline',
          // arrow2: 'chevron-down-outline',
          // children: [
          //   { title: 'Region Summary', url: '/regionsummary' },
          //   { title: "Branch Summary", url: '/newsummary' }
          // ]},



          { title: 'Business Summary', url: '/regionsummary', icon: 'paper-plane' },
          { title: 'GoalSheet', url: '/regiongoalsheet', icon: 'aperture' },
          { title: 'Star Customer', url: '/regionstarcustomer', icon: 'star' },
          { title: 'Click to call Report', url: '/clicktocallcustomer', icon: 'call' },
          { title: '10-3-1 Report', url: '/regionreport', icon: 'albums' },
          { title: 'Planner', url: '/rdmplanner', icon: 'paper-plane' },
          { title: 'Lead/Telecall Summary', url: '/rdmleadlelecall', icon: 'locate' },
          { title: 'Heatmap', url: '/regionheatmap', icon: 'map' },
          { title: 'Advance Commitment', url: '/rdmadvancecommitment', icon: 'build' },
          { title: 'Visit',icon: 'medical',arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
       children: [
         { title: 'Visit Entry',url: '/visitenrty' },
        { title: "Visit Entry Report", url: '/visitreport' },
        {title:"More than 4 Wishlist Visit",url:'/visitnumberofvisit'}
       ]},
          // {title :'Visit Entry',url: '/visitenrty', icon: 'chatbox'},
          // {title :'Add Customer',url: '/addcustomer', icon: 'person-add'},
          // { title: 'checksession', url: '/pdfview', icon: 'calendar' },
       { title: 'Diary Calendar Distribution', url: '/diarycalenderdistribution', icon: 'calendar' },
       { title: 'OtherLink', url: 'mylink', icon: 'link' },
      //  { title: 'Unit NewVisit Report', url: 'uvrnewreport', icon: 'cog' },
       { title: 'Unit Visit Report', url: 'unitvisitreport', icon: 'cog' }
      //  { title: 'Logout', url: 'login', icon: 'person' },
     
        ];
      }
        
      } else if(sharedData== 21){
        // this.openpopup();
        this.appPages = [
          // {title:'circular', url:'/pfdshow',icon:'disc' },
          {title :'Posters',url: '/poster', icon: 'newspaper'},
          { title: 'Notification', url: '/notification', icon: 'information-circle' },
          { title: 'User Profile', url: '/userprofile', icon: 'person' },
          { title: 'Entry Screen', url: '/entryscreen', icon: 'call' },
          { title: 'My Customers',icon: 'people',
          arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
          children: [
            { title: 'My Star Customers', url: 'mystarcustomers' },
            { title: "'0' Star Customers", url: 'zerostarcustomers' },
            { title: 'My SMA Customers', url: 'mysmacustomers' },
            { title: 'My NPA Customers', url: 'mynpacustomers' },
            { title: 'Demand Collection', url: 'demandcollection' },
            { title: 'Other Accounts', url: 'otheraccounts' },
          ]},
          { title: 'My Calls', icon: 'call',
          arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
          children: [
            { title: 'My Assigned Calls', url: '/myassignedcall' },
            { title: "My FollowUp Calls", url: '/myfollowupcall' },
            { title: 'Common Calls', url: '/commoncall' },
        
          ],
          
       },
        
          
        
         
       { title: 'My Visits', icon: 'briefcase',
       arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
       children: [
         { title: 'My Assigned Visits', url: '/myassignedvisits' },
         { title: "My FollowUp Visits", url: '/myfollowupvisits' },
         { title: 'Common Visits', url: '/commonvisit' },
      
       ],
      },
      
       { title: 'My Leads', icon: 'cube',arrow:'chevron-forward-outline',
       arrow2: 'chevron-down-outline',
          children: [
            { title: 'Followup Leads', url: 'followup-leads' },
            { title: "Express Leads", url: 'express-leads' },
            { title: 'RTGS/NEFT', url: 'rtgs-neft' },
        
          ],
          
       },
       { title: 'My Diary', url: '/mydiary', icon: 'book' },
       { title: 'My Planner', url: '/myplanner', icon: 'build' },
       { title: 'Goal Sheet', url: '/goalsheet', icon: 'aperture' },
       { title: 'Performance Dashboard', icon: 'clipboard', url:'/performancedashboard'},
      
      
       { title: 'Heat map', url: '/heatmapstaff', icon: 'compass' },
       { title: 'Exception Report', url: '/exceptionreport', icon: 'logo-dropbox' },
       
       
      
       { title: 'OtherLink', url: 'mylink', icon: 'link' },
      //  { title: 'Unit NewVisit Report', url: 'uvrnewreport', icon: 'cog' },
       { title: 'Unit Visit Report', url: 'unitvisitreport', icon: 'cog' }
      //  { title: 'Logout', url: 'login', icon: 'person' },
         
        ];
      }
      
      else if(sharedData== 30){
        // this.openpopup();
        this.appPages = [
          { title: 'Advance Commitment Summary', url: '/advancecommitmentsummary', icon: 'information-circle' },]
        }
        else if(sharedData== 4 || sharedData == 11){
          this.appPages = [
            // {title:'circular', url:'/pdfview',icon:'disc' },
            // {title:'fingureprint', url:'/fingureprint',icon:'disc' },
            {title :'Posters',url: '/poster', icon: 'newspaper'},
            { title: 'Notification', url: '/notification', icon: 'information-circle' },
            { title: 'User Profile', url: '/userprofile', icon: 'person' },
            { title: 'Entry Screen', url: '/entryscreen', icon: 'call' },
            { title: 'Live Business Summary', url: '/livesummary', icon: 'information-circle' },
            { title: 'My Customers',icon: 'people',
            arrow:'chevron-forward-outline',
         arrow2: 'chevron-down-outline',
            children: [
              { title: 'My Star Customers', url: 'mystarcustomers' },
              { title: "'0' Star Customers", url: 'zerostarcustomers' },
              { title: 'My SMA Customers', url: 'mysmacustomers' },
              { title: 'My NPA Customers', url: 'mynpacustomers' },
              { title: 'Demand Collection', url: 'demandcollection' },
              { title: 'Other Accounts', url: 'otheraccounts' },
            ]},
            { title: 'My Calls', icon: 'call',
            arrow:'chevron-forward-outline',
         arrow2: 'chevron-down-outline',
            children: [
              { title: 'My Assigned Calls', url: '/myassignedcall' },
              { title: "My FollowUp Calls", url: '/myfollowupcall' },
              { title: 'Common Calls', url: '/commoncall' },
          
            ],
            
         },
          
            
          
           
         { title: 'My Visits', icon: 'briefcase',
         arrow:'chevron-forward-outline',
         arrow2: 'chevron-down-outline',
         children: [
           { title: 'My Assigned Visits', url: '/myassignedvisits' },
           { title: "My FollowUp Visits", url: '/myfollowupvisits' },
           { title: 'Common Visits', url: '/commonvisit' },
        
         ],
        },
        
         { title: 'My Leads', icon: 'cube',arrow:'chevron-forward-outline',
         arrow2: 'chevron-down-outline',
            children: [
              { title: 'Followup Leads', url: 'followup-leads' },
              { title: "Express Leads", url: 'express-leads' },
              { title: 'RTGS/NEFT', url: 'rtgs-neft' },
          
            ],
            
         },
         { title: 'My Monthly Planner', icon: 'flash-off-sharp',arrow:'chevron-forward-outline',
         arrow2: 'chevron-down-outline',
            children: [
              { title: 'Monthly Telecalls', url: 'monthlytelecals' },
              { title: "Monthly Visits", url: 'monthlyvisits' },
              
          
            ],
            
         },
         { title: 'Potential Star', url: '/potentialstar', icon: 'star' },
        
         { title: 'My Diary', url: '/mydiary', icon: 'book' },
         { title: 'My Planner', url: '/myplanner', icon: 'build' },
         { title: 'Branch Business Summary', url: '/newsummary', icon: 'aperture' },
         { title: 'Goal Sheet', url: '/goalsheet', icon: 'aperture' },
         { title: 'Performance Dashboard', icon: 'clipboard', url:'/performancedashboard'},
        
        
         { title: 'Heat map', url: '/heatmapstaff', icon: 'compass' },
         { title: 'Exception Report', url: '/exceptionreport', icon: 'logo-dropbox' },
         { title: 'My wish List',icon: 'apps',arrow:'chevron-forward-outline',
         arrow2: 'chevron-down-outline',
         children: [
           { title: 'Add Customer', url: 'mywishaddcustomer' },
           { title: "Primary Customer", url: 'mywishprimarycustomer' },
           { title: 'Secondary Customer', url: 'mywishsecondarycustomer' },
           { title: 'FollowUp', url: 'mywishfollowup' },
           { title: 'Conversions', url: 'mywishconversions' },
          //  { title: 'Other Accounts', url: 'otheraccounts' },
         ]},
         
         { title: 'Insurance',icon: 'medical',arrow:'chevron-forward-outline',
         arrow2: 'chevron-down-outline',
         children: [
           { title: 'Add Insurance', url: 'addinsurance' },
           { title: "Insurance Customer", url: 'insurancecustomer' }
         ]},
         { title: 'Insurance Status History', url: '/insurancehistory', icon: 'file-tray-stacked' },
         { title: 'Diary Calendar Distribution', url: '/diarycalenderdistribution', icon: 'calendar' },
         { title: 'OtherLink', url: 'mylink', icon: 'link' },
        //  { title: 'Unit NewVisit Report', url: 'uvrnewreport', icon: 'cog' },
         { title: 'Unit Visit Report', url: 'unitvisitreport', icon: 'cog' }
        //  { title: 'Logout', url: 'login', icon: 'person' },
        // { title: 'Potential Star', url: '/potentialstar', icon: 'star' },
           
          ];
        }
      
      else
      
      {
        // this.openpopup();
       this.appPages = [
          // {title:'circular', url:'/pfdshow',icon:'disc' },
          {title :'Posters',url: '/poster', icon: 'newspaper'},
        { title: 'Notification', url: '/notification', icon: 'information-circle' },
        { title: 'User Profile', url: '/userprofile', icon: 'person' },
        { title: 'Entry Screen', url: '/entryscreen', icon: 'call' },
        { title: 'My Customers',icon: 'people',
        arrow:'chevron-forward-outline',
     arrow2: 'chevron-down-outline',
        children: [
          { title: 'My Star Customers', url: 'mystarcustomers' },
          { title: "'0' Star Customers", url: 'zerostarcustomers' },
          { title: 'My SMA Customers', url: 'mysmacustomers' },
          { title: 'My NPA Customers', url: 'mynpacustomers' },
          { title: 'Demand Collection', url: 'demandcollection' },
          { title: 'Other Accounts', url: 'otheraccounts' },
        ]},
        { title: 'My Calls', icon: 'call',
        arrow:'chevron-forward-outline',
     arrow2: 'chevron-down-outline',
        children: [
          { title: 'My Assigned Calls', url: '/myassignedcall' },
          { title: "My FollowUp Calls", url: '/myfollowupcall' },
          { title: 'Common Calls', url: '/commoncall' },
      
        ],
        
     },
      
        
      
       
     { title: 'My Visits', icon: 'briefcase',
     arrow:'chevron-forward-outline',
     arrow2: 'chevron-down-outline',
     children: [
       { title: 'My Assigned Visits', url: '/myassignedvisits' },
       { title: "My FollowUp Visits", url: '/myfollowupvisits' },
       { title: 'Common Visits', url: '/commonvisit' },
    
     ],
    },
    
     { title: 'My Leads', icon: 'cube',arrow:'chevron-forward-outline',
     arrow2: 'chevron-down-outline',
        children: [
          { title: 'Followup Leads', url: 'followup-leads' },
          { title: "Express Leads", url: 'express-leads' },
          { title: 'RTGS/NEFT', url: 'rtgs-neft' },
      
        ],
        
     },
     { title: 'My Monthly Planner', icon: 'flash-off-sharp',arrow:'chevron-forward-outline',
     arrow2: 'chevron-down-outline',
        children: [
          { title: 'Monthly Telecalls', url: 'monthlytelecals' },
          { title: "Monthly Visits", url: 'monthlyvisits' },
          
      
        ],
        
     },
     { title: 'Potential Star', url: '/potentialstar', icon: 'star' },
    
     { title: 'My Diary', url: '/mydiary', icon: 'book' },
     { title: 'My Planner', url: '/myplanner', icon: 'build' },
     { title: 'Goal Sheet', url: '/goalsheet', icon: 'aperture' },
     { title: 'Performance Dashboard', icon: 'clipboard', url:'/performancedashboard'},
    
    
     { title: 'Heat map', url: '/heatmapstaff', icon: 'compass' },
     { title: 'Exception Report', url: '/exceptionreport', icon: 'logo-dropbox' },
     { title: 'My wish List',icon: 'apps',arrow:'chevron-forward-outline',
     arrow2: 'chevron-down-outline',
     children: [
       { title: 'Add Customer', url: 'mywishaddcustomer' },
       { title: "Primary Customer", url: 'mywishprimarycustomer' },
       { title: 'Secondary Customer', url: 'mywishsecondarycustomer' },
       { title: 'FollowUp', url: 'mywishfollowup' },
       { title: 'Conversions', url: 'mywishconversions' },
      //  { title: 'Other Accounts', url: 'otheraccounts' },
     ]},
     
     { title: 'Insurance',icon: 'medical',arrow:'chevron-forward-outline',
     arrow2: 'chevron-down-outline',
     children: [
       { title: 'Add Insurance', url: 'addinsurance' },
       { title: "Insurance Customer", url: 'insurancecustomer' }
     ]},
     { title: 'Diary Calendar Distribution', url: '/diarycalenderdistribution', icon: 'calendar' },
     { title: 'OtherLink', url: 'mylink', icon: 'link' },
    //  { title: 'Unit NewVisit Report', url: 'uvrnewreport', icon: 'cog' },
     { title: 'Unit Visit Report', url: 'unitvisitreport', icon: 'cog' }
    //  { title: 'Logout', url: 'login', icon: 'person' },
    // { title: 'Potential Star', url: '/potentialstar', icon: 'star' },
       
      ];
      }
    }
  // }
    
    
    );
 
   debugger
   





    this.appVersion.getAppName();
    this.appVersion.getPackageName();
   let data = this.appVersion.getVersionCode();
   console.log(data)
    this.appVersion.getVersionNumber().then(version => {
      // this.versionNumber = version;
      console.log(version+ "APP P num")
      });
    console.log(this.appVersion.getVersionCode() + "APP P CODE")
    console.log(this.appVersion.getAppName() + "APP A NAME")
    console.log(this.appVersion.getPackageName() + "APP P NAME")
    
if(this.Branchcode == "" || this.Branchcode == null || this.Branchcode == undefined){
  console.log('1')
  this.interval = setInterval(() => {
    this.Branchcode =  window.localStorage['branchCode']
    this.Username =  window.localStorage['userName']
if( window.localStorage['userType'] == '17'){
  this.utype="(Manager)"
}else if(window.localStorage['userType'] == '11'){
  this.utype="(Officer)"
}else if(window.localStorage['userType'] == '4'){
  this.utype="(Staff)"
}
else if(window.localStorage['userType'] == '14'){
  this.utype=""
}
else{
  this.utype="(Co-Ordinator)"
}

    // BM Login >> 17 >> Manager
    // BDM Login >> 11 >> Officer
    // RM Login >> 4 >> Staff
    // RDM Login >> 14 >> RDM
    // Co-Ordinate >> 21 >> Co-Ordinate

        // clearInterval(this.interval)
      }, 2000);
     debugger

  // setTimeout(() => {
  //   this.Branchcode =  window.localStorage['branchCode']
  //   this.Username =  window.localStorage['userName']
  // }, 2000);
}else{
  debugger
  console.log('2')
  clearInterval(this.interval)
  this.Branchcode =  window.localStorage['branchCode'],
    this.Username =  window.localStorage['userName']
}


    
    
 

    console.log(new Date().toISOString())

   

    // this.router.navigate(['login']);
     this.router.navigate(['startuppage'])



    
 this.Date = moment().format('YYYY-MM-DD');
 console.log(this.Date)
//  for(var i=1; i<=4; i++){
//   console.log("*".repeat(i));
// }
 }
 sect(ttogle){
   debugger

 }


 
 async enablefinger(){
   debugger
if(this.ttogle=='true' || this.ttogle == true){
  const alert:any = await this.alert.create({
    // header: "App Exit",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Do you Want to Disable Finger print?",
    buttons: [{ text     : 'Yes',
   
    
    handler: () => {
      this.ttogle='false'
      // this.showFingerprintAuthDlg()
      window.localStorage['biomatric']='No'
    }
  },{
    text:'No',
    handler:()=>{
      debugger
      this.ttogle='true'
      if( window.localStorage['biomatric'] == 'biometric_success'){
        window.localStorage['biomatric'] = 'biometric_success'
      }else{
      this.showFingerprintAuthDlg()
      }
    }

  }
 ]
  });
  await alert.present()
}
else{

  const alert:any = await this.alert.create({
    // header: "App Exit",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Do you Want to Enable Finger print?",
    buttons: [{ text     : 'Yes',
   
    
    handler: () => {
      this.ttogle='true'
      this.showFingerprintAuthDlg()
    }
  },{
    text:'No',
    handler:()=>{
      debugger
      this.ttogle='false'
      window.localStorage['biomatric']='No'
    }

  }
 ]
  });
  await alert.present()
}
  
 }


 public showFingerprintAuthDlg() {
  debugger
      this.faio.isAvailable().then((result: any) => {
        debugger
        console.log(result)
  
        this.faio.show({
          cancelButtonTitle: 'Cancel',
          description: "",
          disableBackup: true,
          title: '',
          fallbackButtonTitle: 'FB Back Button',
          subtitle: ''
        })
          .then((result: any) => {
            debugger
            console.log(result)
            //biometric_success
            window.localStorage['biomatric']=result
            // this.logoutlogin()
            this.alertService.presentAlert("","Successfully updated")
            // alert("Successfully Authenticated!")
          })
          .catch((error: any) => {
            debugger
            console.log(error.message)
            this.ttogle='false'
            window.localStorage['biomatric']='No'
            // when cancel button click->BIOMETRIC_DISMISSED
            // this.alertService.presentAlert("",error.message)
            // alert("Match not found!")
          });
  
      })
        .catch((error: any) => {
          debugger
          // biomatric not enroled
         
          if(error.message == 'BIOMETRIC_NOT_ENROLLED'){
            this.ttogle='false'
            window.localStorage['biomatric']='No'
            this.alertService.presentAlert("", 'Biometric login not supported in your Device ')
          }else
          {
            this.ttogle='false'
            window.localStorage['biomatric']='No'
            this.alertService.presentAlert("",error.message)
          }
         
        });
    }

    //login page with finger
    public showFingerprintAuthDlg1() {
      debugger
          this.faio.isAvailable().then((result: any) => {
            debugger
            console.log(result)
      
            this.faio.show({
              cancelButtonTitle: 'Cancel',
              description: "",
              disableBackup: true,
              title: '',
              fallbackButtonTitle: 'FB Back Button',
              subtitle: ''
            })
              .then((result: any) => {
                debugger
                console.log(result)
                //biometric_success
                window.localStorage['biomatric']=result
                this.doLogin()
                // this.alertService.presentAlert("","Successfully updated")
                // alert("Successfully Authenticated!")
              })
              .catch((error: any) => {
                debugger
                console.log(error.message)
                // when cancel button click->BIOMETRIC_DISMISSED
                // this.alertService.presentAlert("",error.message)
                // alert("Match not found!")
              });
      
          })
            .catch((error: any) => {
              debugger
              // biomatric not enroled
              this.alertService.presentAlert("",error.message)
              console.log(error.message)
            });
        }





        doLogin() {
          debugger
       
      
      this.gpslocation1()
          // this.getGeolocation()
        }
        gpslocation1(){
          debugger
          this.loader.presentLoading('')
          this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION).then(
            result => {
              debugger
              this.loader.dismissLoading()
              if (result.hasPermission) {
        
                //If having permission show 'Turn On GPS' dialogue
                this.askToTurnOnGPS1();
              } else {
        
                //If not having permission ask for permission
                this.requestGPSPermission1();
              }
            },
            err => {
              this.loader.dismissLoading()
              this.alertService.presentAlert("",err);
            }
          );
        }
        askToTurnOnGPS1() {
          debugger
          this.LocationAccuracy.request(this.LocationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
            (res:any) => {
              debugger
              var xyz=res
              this.authService.uvrlocationarray.push(xyz.code)
              // window.localStorage['errcode']=xyz.code
              // this.alertService.presentAlert('', "location enabled")
              // When GPS Turned ON call method to get Accurate location coordinates
              this.getGeolocation()
            },
            err =>{ 
              debugger
              console.log(err)
              this.authService.uvrlocationarray.push(err.code)
              // window.localStorage['errcode']=err.code
              this.logoutlogin()
              // this.alertService.presentAlert('Error', err.message)
              // this.alertService.presentAlert("","Please Enable Location")
              // alert('Error requesting location permissions ' + JSON.stringify(error))
            }
          );
        }
        getGeolocation() {
          debugger
      this.loader.presentLoading('')
          navigator.geolocation.getCurrentPosition((resp) => {
            debugger
            this.loader.dismissLoading()
            this.latitude = resp.coords.latitude;
            this.longitude = resp.coords.longitude;
            this.accuracy = resp.coords.accuracy;
            this.timestamp = resp.timestamp;
      
            window.localStorage['latitude'] = this.latitude
            window.localStorage['longitude'] = this.longitude
            window.localStorage['accuracy'] = this.accuracy
      window.localStorage['timestamp']=this.timestamp
      
            // this.doLogingeo()
            // this.getGeoencoder(resp.coords.latitude, resp.coords.longitude);
            this.logoutlogin()
      
          },err=>{
            debugger
            this.loader.dismissLoading()
            this.alertService.presentAlert("",err.message)
            this.showFingerprintAuthDlg1()
          })
      
      
        }
        requestGPSPermission1() {
          debugger
          this.LocationAccuracy.canRequest().then((canRequest: boolean) => {
            debugger
            if (canRequest) {
              console.log("4");
            } else {
              
              this.askToTurnOnGPS1();
            }
          });
        }






    logoutlogin(){
      debugger
      this.authService.getversion().then((resp) => {
        debugger
        this.loader.dismissLoading()
        console.log(resp);
        var response = JSON.parse(resp.data)
        let live_version_resp: any = JSON.parse(response);
        console.log(live_version_resp);
        let live_version: any = parseFloat(live_version_resp.Table[0].Version);
        localStorage.setItem('live_ver', live_version);
        console.log(parseFloat(live_version), parseFloat(localStorage.getItem('ver')));
        var app_version = parseFloat(localStorage.getItem('ver'));
  
       
          if(1== 1)
         {
          console.log("version matched");
  
  
         let userCode= window.localStorage['empusercode']
         
         let Pwd= window.localStorage['password']
    var obj = {
            strUserCode: userCode,
            strPassword: Pwd,
            
          }
  
      
          this.authService.login(obj).then((resp) => {
            console.log(resp);
            debugger
            // this.loader.dismissLoading()
            var response = JSON.parse(resp.data);
            this.mydata = response;
            console.log(this.mydata);
            
            debugger
  

  
  
            
  
              if (1 == 1)  {
                window.localStorage['userID'] = this.mydata[0].UserId;
                window.localStorage['branchID'] = this.mydata[0].BranchId;
                window.localStorage['branchCode'] = this.mydata[0].BranchCode;
                window.localStorage['userCode'] = this.mydata[0].UserCode;
                this.footername = window.localStorage['userCode'];
                window.localStorage['userName'] = this.mydata[0].UserName;
                this.username = window.localStorage['userName'];
                window.localStorage['userType'] = this.mydata[0].UserType;
                window.localStorage['BranchDescription'] = this.mydata[0].BranchDescription;
                window.localStorage['mobile'] = this.mydata[0].mobile;
                // this.branchposition = false;
  
                debugger
  this.authService.userlogininfo(window.localStorage['userID'],window.localStorage.deviceID,window.localStorage['logintype']).then((res:any)=>{
  
  })
  
                this.authService.updateversion(this.mydata[0].BranchId, this.mydata[0].UserId, localStorage.getItem('ver')).then((resp) => {
                  console.log(resp)
                })
                  this.loader.dismissLoading()
                this.popupshow()
  
              } else {
                if (this.mydata[0].DeviceId == '' || this.mydata[0].DeviceId ==null) {
                  this.loader.dismissLoading()
                  // this.checkdeviceid()
  
                } else {
                  this.loader.dismissLoading()
                  this.alertService.presentAlert('Login Failed', 'Invalid Device');
                  // this.getcaptcha()
                }
              }
            
          }, (err) => {
            debugger
            this.loader.dismissLoading()
            console.log(err)
            this.alertService.presentAlert("", err.error)
          })
        } else {
  
          console.log("version mismatched");
          
          this.mismatched()
          // this.alertService.presentAlert('Login Failed', 'Your App has been outdated. Please download and install the latest app to continue using Telesmart. ');
        }
  
      }, (err) => {
        debugger
        this.loader.dismissLoading()
        console.log(err);
  
        this.alertService.presentAlert("",err.error)
      })
    }
    async mismatched() {
      const alert = await this.alert.create({
        header: 'Your App has been outdated. Please download and install the latest app to continue using Telesmart. ',
        cssClass: 'alertHeader',
        // subHeader: 'Subtitle',
        message: '',
        buttons: [{
          text: 'Proceed',
  
  
          handler: () => {
  
            window.open('https://cityunionbank.com/telesmart/', '_system');
  
  
  
  
          }
        },
  
  
        ]
      });
      await alert.present()
  
    }
    popupshow(){
      debugger
         
            this.authService.Getmobileappnotificationlogin().then((res)=>{
              debugger
            this.authService.notifyarray.push('1')
      
      if(JSON.parse(res.data) == 'No record'){
        this.menuCtrl.enable(true)
        this.logindata = {}
        this.authService.notifyarray=[]
        this.authService.setData(this.mydata[0].UserType);
        if (window.localStorage['userType'] == 17) {
          // $state.go('app.newsummary');
          this.router.navigate(['/newsummary']);
      
        } else if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
         
          this.router.navigate(['/regionsummary']);
      
        } else if(window.localStorage['userType'] == 30){
          this.router.navigate(['/advancecommitmentsummary']);
        }
        else {
          this.router.navigate(['/myplanner']);
          
        }
      } else{
        this.notifyjson=JSON.parse(JSON.parse(res.data))
            
        let date=this.datepipe.transform(new Date(), 'YYYY-MM-dd')
        this.notifydate = this.datepipe.transform( this.notifyjson[0].ExpiryDate,'YYYY-MM-dd')
        
        
        if(this.notifydate<date){
        // hide notification
       
      
        this.menuCtrl.enable(true)
        this.logindata = {}
        this.authService.notifyarray=[]
        this.authService.setData(this.mydata[0].UserType);
        if (window.localStorage['userType'] == 17) {
          // $state.go('app.newsummary');
          this.router.navigate(['/newsummary']);
      
        } else if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
         
          this.router.navigate(['/regionsummary']);
      
        } else if(window.localStorage['userType'] == 30){
          this.router.navigate(['/advancecommitmentsummary']);
        }
        else {
          this.router.navigate(['/myplanner']);
          
        }
      
      
      
        console.log("date expiry")
        }else{
          this.menuCtrl.enable(true)
        this.logindata = {}
        this.authService.notifyarray=[]
        this.authService.setData(this.mydata[0].UserType);
        if (window.localStorage['userType'] == 17) {
          // $state.go('app.newsummary');
          this.router.navigate(['/newsummary']);
      
        } else if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
         
          this.router.navigate(['/regionsummary']);
      
        } else if(window.localStorage['userType'] == 30){
          this.router.navigate(['/advancecommitmentsummary']);
        }
        else {
          this.router.navigate(['/myplanner']);
          
        }
      
          if(this.notifyjson[0].Content == undefined){
            this.notifycontent=''
            this.modalp()
          }else{
            this.notifycontent=this.notifyjson[0].Content
            this.modalp()
          }
        
         
         
        }
      }
      
          
            })
          
          
           
           }

           async modalp (){
            debugger
            const modal = await this.modalController.create({
             component: TrialnotifyPage,
             componentProps: { },
             cssClass: "image-popup-modal-css"
           });
           return await modal.present();
             // console.log("12",item);
         
             // this.branchdata = item;
             // this.branchid = item.BranchID;
             // console.log("branchData",this.branchdata)
             // this.RDMbranchEmployees.show();
         
           }

// Sessiontime out start
sessionout()
{
 
 }




// sessiontime out end
   




 async openpopup(){
  const modal = await this.modalController.create({
    component: NotificationpopupPage,
    componentProps: {
      'model_title': "Nomadic model's reveberation"
    }
  });
  // modal.onDidDismiss().then((modelData) => {
  //   if (modelData !== null) {
  //     this.modelData = modelData.data;
  //     console.log('Modal Data : ' + modelData.data);
  //   }
  // });
  return await modal.present();
}
 async backmethod(){
   debugger
  const alert:any = await this.alert.create({
    header: "App Exit",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Do you Want to Exit ?",
    buttons: [{ text     : 'Yes',
   
    
    handler: () => {
      // this.router.navigate(['login']);
      navigator["app"].exitApp()
      this.service.getcaptcha().then((resp: any) => {
        debugger
        this.captchares = JSON.parse(JSON.parse(resp.data))
      })
    }
  },{
    text:'No',
    handler:()=>{

    }

  }
 ]
  });
  await alert.present()
 }

 async rootcheck(){
  const alert:any = await this.alert.create({
    header: "",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Your Device Rooted",
    buttons: [{ text     : 'Okay',
   
    
    handler: () => {
      navigator["app"].exitApp()
    }
  },
 ]
  });
  await alert.present()
 }

gpslocation(){
  this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION).then(
    result => {
      debugger
      if (result.hasPermission) {

        //If having permission show 'Turn On GPS' dialogue
        this.askToTurnOnGPS();
      } else {

        //If not having permission ask for permission
        this.requestGPSPermission();
      }
    },
    err => {
      this.alertService.presentAlert("",err);
    }
  );
}

 async presentAlert() {
   debugger
  const alert = await this.alert.create({
    // header: "Logout",
    cssClass:'alertHeader',
    // subHeader: 'Subtitle',
    message: "Are you sure you want to logout?",
    buttons: [{
      text: 'CANCEL',
      // type: 'button button-clear button-assertive'
  },
  { text     : 'Ok',
   
    
    handler: () => {
        console.log('Confirm Logout: ok');
        this.logoutnow()
    }
  },]
  });

  await alert.present();
}

requestGPSPermission() {
  debugger
  this.LocationAccuracy.canRequest().then((canRequest: boolean) => {
    debugger
    if (canRequest) {
      console.log("4");
    } else {
      
      this.askToTurnOnGPS();
    }
  });
}
askToTurnOnGPS() {
  debugger
  this.LocationAccuracy.request(this.LocationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
    () => {
      debugger
      // When GPS Turned ON call method to get Accurate location coordinates
      // this.getGeolocation()
    },
    error =>{ 
      this.alertService.presentAlert("","Please Enable Location")
      // alert('Error requesting location permissions ' + JSON.stringify(error))
    }
  );
}



logoutnow(){
  debugger
  // this.clearInterval()
this.menu.close();
  
this.menu.enable(false);
  // 
  this.idle.stop()
  this.service.notifyarray=[]
 debugger
  

           debugger
        //   var test =  AuthService.logout(window.localStorage['userCode'],localStorage.getItem('Token'));

          this.service.logout(window.localStorage['userCode'],localStorage.getItem('Token')).then((response:any)=> {
             debugger
            this.resptest = JSON.parse(response.data);
            window.localStorage['logintype']=""
             window.localStorage['userCode']="";
             window.localStorage['BranchDescription']="";
             window.localStorage['branchCode']="";
             window.localStorage['branchDesc']="";
             window.localStorage['branchID']="";
             window.localStorage['managermenu']="";
             window.localStorage['staffmenu']="";
             window.localStorage['userID']="";
             window.localStorage['userCode']="";
             if( window.localStorage['biomatric'] != 'biometric_success'){
              window.localStorage['userName']=""
             }
            //  window.localStorage['userName']="";
             window.localStorage['userType']="";
             window.localStorage['CRMCallID']="";
              window.localStorage['trackinglocation']="";
             window.localStorage['LEADCRMCallID']="";
             debugger
            //  window.localStorage.clear();


          
         
           
           
            window.localStorage['mobile'] = "";



             sessionStorage.clear();          
             this.service.uvrlocationarray=[]
             this.service.catchlocationarray=[]
             this.service.geoarray=[]
            //  $ionicHistory.clearCache();
            //  $ionicHistory.clearHistory();
          
             // if(ionic.Platform.platform() == 'android'){
                debugger
                //    cordova.getAppVersion.getVersionNumber().then((version)=> {
                //       debugger
                //       localStorage.setItem('ver',version);
                //      this.app_ver = localStorage.getItem('ver');
                //       $('.version').text(version);
                //       console.log('menuversion',version);
                // });
                this.appVersion.getAppName();
this.appVersion.getPackageName();
this.appVersion.getVersionCode();
this.appVersion.getVersionNumber();
console.log(this.appVersion.getVersionCode() + "APP P CODE")
console.log(this.appVersion.getAppName() + "APP A NAME")
console.log(this.appVersion.getPackageName() + "APP P NAME")
console.log(this.appVersion.getVersionNumber() + "APP VERSION NUMBER")
                // }
                debugger
            // var permissions = cordova.plugins.permissions;
            // permissions.hasPermission(permissions.RECEIVE_SMS, checkPermissionCallback, null);
            // debugger
            // window.localStorage.deviceID = device.uuid;
            // $state.go('login');

            // window.cache.clear() ,
            // window.cookies.clear()if(//biometric_success
if( window.localStorage['biomatric'] == 'biometric_success'){
// this.router.navigate(['login']);
//  this.showFingerprintAuthDlg1()
this.router.navigate(['startuppage'])
}else{
    // this.router.navigate(['login']);
    this.router.navigate(['startuppage'])
}
// this.router.navigate(['startuppage'])

           
           //   if( resp == "Session Cleared") {
                
           //   }
           //   console.log(resp);
          });
      
           debugger
           // if(this.resp == "Session Cleared") {
            
           // }
      
        //  }
    //  }]
//  });

}



}
