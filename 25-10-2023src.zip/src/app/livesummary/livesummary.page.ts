import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import Chart from 'chart.js/auto';
import { AlertServiceService } from '../service/alert-service.service';
@Component({
  selector: 'app-livesummary',
  templateUrl: './livesummary.page.html',
  styleUrls: ['./livesummary.page.scss'],
})
export class LivesummaryPage implements OnInit {
  livebranch:any
  isshowdrop:boolean=false
  Chart:any;
  livebusiness: any;
  livetarget: any;
  live3103: any;
  liveyesterday: any;
  difflivebusiness: any;
  difflive3103: any;
  diiyesterday: any;
  isdownarrow:boolean=false
  isuparrow:boolean=false
  isdownarrow2:boolean=false
  isuparrow2:boolean=false
  isdownarrow3:boolean=false
  isuparrow3:boolean=false
  date: any;
  totaldifflive3103: any;
  depositason: string;
  advanceason: string;
  deposityesterday: string;
  deposit3103: string;
  advance3103: string;
  deposittarget: string;
  advancetarget: string;
  advanceyesterday: string;
  ansdeposit: string;
  ansadvance: string;
  ansyesterday: string;
  currentdate:any
  abc:any;
  getlivesummary: any;
  dataaa: any;
  isrecord:boolean=false
  updatedate: any;
  datetarget: any;
  constructor(private apiservice:ApiServiceService,private alert:AlertServiceService) { }

  ngOnInit() {
   this.getlivesummary=[]
if(window.localStorage['userType'] == 14){
this.apiservice. getrdmrolebranchwisebybranch(window.localStorage['userID']).then((res:any)=>{
  debugger
  this.getlivesummary=JSON.parse(JSON.parse(res.data))
})
}else{
    this.apiservice.getlivecobranchwise().then((res:any)=>{
      debugger
      this.getlivesummary=JSON.parse(JSON.parse(res.data))

    })
  }
  }
  selectbranch(data:any){
    debugger

    this.dataaa=data

if(this.dataaa == '' || this.dataaa == undefined){
  this.isrecord=true
  this.isshowdrop=false
this.alert.presentAlert("","Please Select Branch")
return false
}else{

    this.isshowdrop=true
    
    if(this.dataaa == '0'){
      // this.abc.destroy();
      this.getbusinesswisesummary()

    }else{
      // this.abc.destroy();

if(window.localStorage['branchID'] == '32'){
  this.getbusinesswisesummaryindividuals()
}else{

if(window.localStorage['userType'] == 14){
// this.getrdmrolebranchwisebybranch(this.dataaa)
this.getbusinesswisesummaryindividuals()
}else{
  this.getbusinesswisesummary()
      // this.getbusinesswisesummaryindividuals()
}
  }  }
  }

   


  }
  getbusinesswisesummary(){
    debugger
    if(this.dataaa == '0'){
      if(window.localStorage['userType'] == "14"){
        var userid =window.localStorage['userID']
      }else{
        userid=0
      }
      
    }else{
      userid=this.dataaa
  // var userid= window.localStorage['userID'];
      
  }
   var branchid= window.localStorage['branchID'] ;
    this.apiservice.getbusinesswisesummary(userid,branchid).then((res:any)=>{
      debugger
    let arraysummary=JSON.parse(JSON.parse(res.data));
    if(arraysummary.length == 0){
      this.isrecord=true
      this.isshowdrop=false
    }else{
      this.isrecord=false
      this.isshowdrop=true
      const now = new Date();
    this.currentdate=now.toLocaleString()
    let updatedate=arraysummary[0].LUPDATE
    this.updatedate= updatedate.replace('T',' ')
    this.depositason=parseFloat(arraysummary[0].depositason).toFixed(2)
    this.advanceason=parseFloat(arraysummary[0].advanceason).toFixed(2)
    this.livebusiness=parseFloat(arraysummary[0].livebusiness).toFixed(2)
    this.liveyesterday=parseFloat(arraysummary[0].liveyesterday).toFixed(2)
    this.deposityesterday=parseFloat(arraysummary[0].deposityesterday).toFixed(2)
    this.advanceyesterday=parseFloat(arraysummary[0].advanceyesterday).toFixed(2)
    
    this.deposit3103=parseFloat(arraysummary[0].deposit3103).toFixed(2)
    this.advance3103=parseFloat(arraysummary[0].advance3103).toFixed(2)
    this.live3103=parseFloat(arraysummary[0].live3103).toFixed(2)
    this.deposittarget=parseFloat(arraysummary[0].deposittarget).toFixed(2)
    this.advancetarget=parseFloat(arraysummary[0].advancetarget).toFixed(2)
    this.livetarget=parseFloat(arraysummary[0].livetarget).toFixed(2)
this.date=arraysummary[0].date
    this.difflivebusiness= parseFloat(this.depositason)-parseFloat(this.deposityesterday)
   this.ansdeposit= parseFloat(this.difflivebusiness).toFixed(2)
   this.difflive3103= parseFloat(this.advanceason)-parseFloat(this.advanceyesterday)
   this.ansadvance= parseFloat(this.difflive3103).toFixed(2)
  //  this.totaldifflive3103= parseFloat(this.difflive3103).toFixed(2)
    this.diiyesterday=parseFloat(this.livebusiness)-parseFloat(this.liveyesterday)
    this.ansyesterday= parseFloat(this.diiyesterday).toFixed(2)
// let asas="700"
if(parseFloat(this.deposityesterday) < parseFloat(this.depositason)){
this.isdownarrow=false
// this.isuparrow=false
}else{
  this.isdownarrow=true
// this.isuparrow=true
}

if(parseFloat(this.advanceyesterday) < parseFloat(this.advanceason)){
  this.isdownarrow2=false
  // this.isuparrow2=false
  }else{
    this.isdownarrow2=true
  // this.isuparrow2=true
  }
  
  if(parseFloat(this.liveyesterday) < parseFloat(this.livebusiness)){
    this.isdownarrow3=false
    // this.isuparrow3=false
    }else{
      this.isdownarrow3=true
    // this.isuparrow3=true
    }
    // var ctx = document.getElementById("myChart");

    var data = {
      labels: ["DEPOSIT", "ADVANCES", "BUSINESS"],
      datasets: [{
        label: "Live",
        backgroundColor: "red",
        data: [this.depositason,this.advanceason,this.livebusiness],
        // yAxisID: "y-axis-gravity"
      }, 
      
       {
        label: this.date,
        backgroundColor: "green",
        data: [this.deposit3103,this.advance3103,this.live3103],
        // yAxisID: "y-axis-gravity"
      },
      {
        label: "Target"+this.datetarget,
        backgroundColor: "blue",
        data: [this.deposittarget,this.advancetarget,this.livetarget],
        // yAxisID: "y-axis-gravity"
      }]
    };
    debugger
    if(this.abc ){
      this.abc.destroy();
    }
    // this.abc.destroy();
    
   this. abc= new Chart('canvas', {
      type: 'bar',
      
   
      data:data,
      options: {
       
        plugins: {
          legend: {
            display: false,
          },
          
        },
        scales: {
          x: {
            ticks: {
              // autoSkip:true,
              display: true,
              
            },
          },
          y: {
            ticks: {
              display: true,
            },
          },
        },
      },
    });
    // this.abc.draw(data,options)
    debugger
    console.log("datata",this.abc)
      
    }}
    )
  }
 
  getrdmrolebranchwisebybranch(id:any){
    debugger
  this.apiservice.getrdmrolebranchwisebybranch(id).then((res:any)=>{
    debugger
  let arraysummary=JSON.parse(JSON.parse(res.data));
  if(arraysummary == 0){
    this.isrecord=true
    this.isshowdrop=false
  }else{
    this.isrecord=false
    this.isshowdrop=true
    const now = new Date();
    this.currentdate=now.toLocaleString()
    
  this.depositason=parseFloat(arraysummary[0].depositason).toFixed(2)
  this.advanceason=parseFloat(arraysummary[0].advanceason).toFixed(2)
  this.livebusiness=parseFloat(arraysummary[0].livebusiness).toFixed(2)
  this.liveyesterday=parseFloat(arraysummary[0].liveyesterday).toFixed(2)
  this.deposityesterday=parseFloat(arraysummary[0].deposityesterday).toFixed(2)
  this.advanceyesterday=parseFloat(arraysummary[0].advanceyesterday).toFixed(2)
  
  this.deposit3103=parseFloat(arraysummary[0].deposit3103).toFixed(2)
  this.advance3103=parseFloat(arraysummary[0].advance3103).toFixed(2)
  this.live3103=parseFloat(arraysummary[0].live3103).toFixed(2)
  this.deposittarget=parseFloat(arraysummary[0].deposittarget).toFixed(2)
  this.advancetarget=parseFloat(arraysummary[0].advancetarget).toFixed(2)
  this.livetarget=parseFloat(arraysummary[0].livetarget).toFixed(2)
this.date=arraysummary[0].date
  this.difflivebusiness= parseFloat(this.depositason)-parseFloat(this.deposityesterday)
 this.ansdeposit= parseFloat(this.difflivebusiness).toFixed(2)
 this.difflive3103= parseFloat(this.advanceason)-parseFloat(this.advanceyesterday)
 this.ansadvance= parseFloat(this.difflive3103).toFixed(2)
//  this.totaldifflive3103= parseFloat(this.difflive3103).toFixed(2)
  this.diiyesterday=parseFloat(this.livebusiness)-parseFloat(this.liveyesterday)
  this.ansyesterday= parseFloat(this.diiyesterday).toFixed(2)
// let asas="700"
if(parseFloat(this.deposityesterday) < parseFloat(this.depositason)){
this.isdownarrow=false
// this.isuparrow=false
}else{
this.isdownarrow=true
// this.isuparrow=true
}

if(parseFloat(this.advanceyesterday) < parseFloat(this.advanceason)){
this.isdownarrow2=false
// this.isuparrow2=false
}else{
  this.isdownarrow2=true
// this.isuparrow2=true
}

if(parseFloat(this.liveyesterday) < parseFloat(this.livebusiness)){
  this.isdownarrow3=false
  // this.isuparrow3=false
  }else{
    this.isdownarrow3=true
  // this.isuparrow3=true
  }
  // var ctx = document.getElementById("myChart");

  var data = {
    labels: ["DEPOSIT", "ADVANCES", "BUSINESS"],
    datasets: [{
      label: "Live",
      backgroundColor: "red",
      data: [this.depositason,this.advanceason,this.livebusiness],
      // yAxisID: "y-axis-gravity"
    }, 
    
     {
      label: this.date,
      backgroundColor: "green",
      data: [this.deposit3103,this.advance3103,this.live3103],
      // yAxisID: "y-axis-gravity"
    },
    {
      label: "Target"+this.datetarget,
      backgroundColor: "blue",
      data: [this.deposittarget,this.advancetarget,this.livetarget],
      // yAxisID: "y-axis-gravity"
    }]
  };
  debugger
  // this.abc.destroy();
  if(this.abc){
    this.abc.destroy();
  }
  
 this. abc= new Chart('canvas', {
    type: 'bar',
    
 
    data:data,
    options: {
     
      plugins: {
        legend: {
          display: false,
        },
        
      },
      scales: {
        x: {
          ticks: {
            // autoSkip:true,
            display: true,
            
          },
        },
        y: {
          ticks: {
            display: true,
          },
        },
      },
    },
  });
  // this.abc.draw(data,options)
  debugger
  console.log("datata",this.abc)
  
    
  }
})
  }

  getbusinesswisesummaryindividuals(){
    debugger
  this.apiservice.getbusinesswisesummaryindividuals(this.dataaa).then((res:any)=>{
    debugger
  let arraysummary=JSON.parse(JSON.parse(res.data));
  if(arraysummary == 0){
    this.isrecord=true
    this.isshowdrop=false
  }else{
    this.isrecord=false
    this.isshowdrop=true
    const now = new Date();
    this.currentdate=now.toLocaleString()
    let updatedate=arraysummary[0].LUPDATE
    this.updatedate= updatedate.replace('T',' ')
  this.depositason=parseFloat(arraysummary[0].depositason).toFixed(2)
  this.advanceason=parseFloat(arraysummary[0].advanceason).toFixed(2)
  this.livebusiness=parseFloat(arraysummary[0].livebusiness).toFixed(2)
  this.liveyesterday=parseFloat(arraysummary[0].liveyesterday).toFixed(2)
  this.deposityesterday=parseFloat(arraysummary[0].deposityesterday).toFixed(2)
  this.advanceyesterday=parseFloat(arraysummary[0].advanceyesterday).toFixed(2)
  
  this.deposit3103=parseFloat(arraysummary[0].deposit3103).toFixed(2)
  this.advance3103=parseFloat(arraysummary[0].advance3103).toFixed(2)
  this.live3103=parseFloat(arraysummary[0].live3103).toFixed(2)
  this.deposittarget=parseFloat(arraysummary[0].deposittarget).toFixed(2)
  this.advancetarget=parseFloat(arraysummary[0].advancetarget).toFixed(2)
  this.livetarget=parseFloat(arraysummary[0].livetarget).toFixed(2)
this.date=arraysummary[0].date
this.datetarget=arraysummary[0].datetarget
  this.difflivebusiness= parseFloat(this.depositason)-parseFloat(this.deposityesterday)
 this.ansdeposit= parseFloat(this.difflivebusiness).toFixed(2)
 this.difflive3103= parseFloat(this.advanceason)-parseFloat(this.advanceyesterday)
 this.ansadvance= parseFloat(this.difflive3103).toFixed(2)
//  this.totaldifflive3103= parseFloat(this.difflive3103).toFixed(2)
  this.diiyesterday=parseFloat(this.livebusiness)-parseFloat(this.liveyesterday)
  this.ansyesterday= parseFloat(this.diiyesterday).toFixed(2)
// let asas="700"
if(parseFloat(this.deposityesterday) < parseFloat(this.depositason)){
this.isdownarrow=false
// this.isuparrow=false
}else{
this.isdownarrow=true
// this.isuparrow=true
}

if(parseFloat(this.advanceyesterday) < parseFloat(this.advanceason)){
this.isdownarrow2=false
// this.isuparrow2=false
}else{
  this.isdownarrow2=true
// this.isuparrow2=true
}

if(parseFloat(this.liveyesterday) < parseFloat(this.livebusiness)){
  this.isdownarrow3=false
  // this.isuparrow3=false
  }else{
    this.isdownarrow3=true
  // this.isuparrow3=true
  }
  // var ctx = document.getElementById("myChart");

  var data = {
    labels: ["DEPOSIT", "ADVANCE", "BUSINESS"],
    datasets: [{
      label: "Live",
      backgroundColor: "red",
      data: [this.depositason,this.advanceason,this.livebusiness],
      // yAxisID: "y-axis-gravity"
    }, 
    
     {
      label: this.date,
      backgroundColor: "green",
      data: [this.deposit3103,this.advance3103,this.live3103],
      // yAxisID: "y-axis-gravity"
    },
    {
      label: "Target",
      backgroundColor: "blue",
      data: [this.deposittarget,this.advancetarget,this.livetarget],
      // yAxisID: "y-axis-gravity"
    }]
  };
  debugger
  // this.abc.destroy();
  if(this.abc){
    this.abc.destroy();
  }
  
 this. abc= new Chart('canvas', {
    type: 'bar',
    
 
    data:data,
    options: {
     
      plugins: {
        legend: {
          display: false,
        },
        
      },
      scales: {
        x: {
          ticks: {
            // autoSkip:true,
            display: true,
            
          },
        },
        y: {
          ticks: {
            display: true,
          },
        },
      },
    },
  });
  // this.abc.draw(data,options)
  debugger
  console.log("datata",this.abc)
  
    
  }
})
  }
}
