import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LivesummaryPage } from './livesummary.page';

const routes: Routes = [
  {
    path: '',
    component: LivesummaryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LivesummaryPageRoutingModule {}
