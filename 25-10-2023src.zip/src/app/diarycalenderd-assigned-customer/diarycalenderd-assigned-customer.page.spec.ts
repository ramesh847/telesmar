import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DiarycalenderdAssignedCustomerPage } from './diarycalenderd-assigned-customer.page';

describe('DiarycalenderdAssignedCustomerPage', () => {
  let component: DiarycalenderdAssignedCustomerPage;
  let fixture: ComponentFixture<DiarycalenderdAssignedCustomerPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DiarycalenderdAssignedCustomerPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DiarycalenderdAssignedCustomerPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
