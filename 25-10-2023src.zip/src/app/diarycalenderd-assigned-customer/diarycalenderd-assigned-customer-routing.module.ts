import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DiarycalenderdAssignedCustomerPage } from './diarycalenderd-assigned-customer.page';

const routes: Routes = [
  {
    path: '',
    component: DiarycalenderdAssignedCustomerPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DiarycalenderdAssignedCustomerPageRoutingModule {}
