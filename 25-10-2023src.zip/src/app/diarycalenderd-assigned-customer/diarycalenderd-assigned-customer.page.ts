import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import { DatePipe } from '@angular/common';
import { AlertServiceService } from 'src/app/service/alert-service.service';
import { Router } from '@angular/router';
import { ToastServiceService } from '../service/toast-service.service';
import { Idle,DEFAULT_INTERRUPTSOURCES} from '@ng-idle/core';
@Component({
  selector: 'app-diarycalenderd-assigned-customer',
  templateUrl: './diarycalenderd-assigned-customer.page.html',
  styleUrls: ['./diarycalenderd-assigned-customer.page.scss'],
  providers: [DatePipe,Idle]
})
export class DiarycalenderdAssignedCustomerPage implements OnInit {
  startDate: any;
  endDate: any;
  FiYear: any;
  data: any = {};
  relativeList: any =[];
  rel: any = {};
  data1: any = {};
  datafinresp: any;
  dataresp: any =[];
  datarespending: any =[];
  dataresTable1: any;
  custID: any;
  custMobile: any;
  customerType: any;
  dataloan: any=[];
  filtered: any;
  datarespending1: any;
  updateScreen: boolean = false;
  radioTitle: string;
  radioItems: Array<string>;
  model   = {option: 'option3'};
  dataresplength: any;
  idleState: string;
  constructor(private apiService: ApiServiceService, private datepipe: DatePipe,private router : Router, 
     private alertService: AlertServiceService,private loader:ToastServiceService,private idle:Idle) {  // sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
          // (this.idleState = countdown.toString() )
      );
  }

  ngOnInit() {
    debugger
    this.startDate = '';
    this.endDate = '';
    this.FiYear = '';
    this.getFinanciallist();
    this.data.diarygiven = '';
    this.data.calendargiven = '';
    this.data.paymentBroch = '';
    this.data.CustFeedback = '';
    // this.RNPartAModel();
    this.radioTitle = 'Radio Button in Angular';
    this.radioItems = ['option1', 'option2', 'option3'];
    // this.reset()
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }
  getFinanciallist() {
    // this.showspin();
    debugger
    this.loader.presentLoading('')
    this.apiService.getFinancialdata().then(response => {
      debugger
      this.loader.dismissLoading()
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      this.datafinresp = res;
      debugger
      this.datafinresp = this.datafinresp.Table[0];
      debugger
      console.log(this.datafinresp)
      var stDate = new Date(this.datafinresp.Start_Dt);
      this.startDate = this.datepipe.transform(stDate, 'MM-dd-yyyy');
      var endDate = new Date(this.datafinresp.End_Dt);
      this.endDate = this.datepipe.transform(endDate, 'MM-dd-yyyy');
      this.FiYear = this.datafinresp.FI_YEAR;
      console.log(this.startDate);
      this.getAssignedlist();
    })

  }

  getAssignedlist() {
    debugger
    // this.showspin();
    var userid = window.localStorage['userID'];
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    if (this.data.customerid == undefined) {
      var custID = 0;
    } else {
      custID = this.data.customerid;
    }
    this.loader.presentLoading('')
    this.apiService.getassignedGrid(userid, branchid, userType, this.startDate, this.endDate, custID).then(response => {
      debugger
      this.loader.dismissLoading()
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      this.dataresp = res;
      debugger
      this.dataresp = this.dataresp.Table;
      this.dataresplength=this.dataresp.length
      debugger
      console.log(this.dataresp)
    })

  }

  goToMyplannerPage1(){
    
    this.updateScreen=false
   
  }
  // this.doRefresh() {
  //   this.getFinanciallist();
  //   this.dataresp =[];
  //   this.data.customerid = undefined;
  //   console.log('Refreshing!');
  //   $timeout(function() {
  //   this.$broadcast('scroll.refreshComplete');
  //   }, 1000);
  // };

  RNPartAModel(custID) {
   
    // this.relativeList =[];
    console.log("Openmodel")
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    this.apiService.getproductAvail(userid, branchid, userType, custID).then(response => {
      // this.RNPartAaction.show();
      var res = JSON.stringify(response.data)
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      console.log(res);
      this.datarespending1 = res;
      this.datarespending = res;
      console.log(this.datarespending);
      debugger
      this.datarespending = this.datarespending.Table;
      console.log(this.datarespending);
      debugger
      this.dataresTable1 = this.datarespending1.Table1[0];
      debugger
      console.log(this.datarespending)
      this.custID = this.datarespending[0].CBSCustomerId;
      debugger
      this.custMobile = this.datarespending[0].Mobile;
      // this.customerType =this.datarespending[0].Table1[0].CustomerType;
      console.log(this.custID)
    })

    this.getLoanFacility();

    this.data.mobileNo = "N";
    this.data.emailId = "N";
    this.data.panNo = "N";
    this.data.netBanking = "N";
    this.data.mobileBanking = "N";
    this.data.debit = "N";
    this.data.aadhar = "N";
    this.data.gas = "N";
    this.data.creditCard = "N";
    this.data.mutual = "N";
    this.data.insur = "N";
    this.data.health = "N";
    this.data.group = "N";
    this.data.pos = "N";
    this.data.bharat = "N";
    this.data.fastag = "N";
    this.data.gold = "N";
    this.data.demat = "N";
    this.data.asba = "N";
    this.data.fd = "N";
    this.data.locker = "N";
  }

  getLoanFacility() {
    debugger
    this.updateScreen = true;
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    this.apiService.getloan().then(response => {
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      debugger
      res = JSON.parse(res);
      this.dataloan = res;
      debugger
    })

  }
  closeRNPartAModal() {
    this.data = {};
    this.relativeList = {};
    // this.RNPartAaction.hide();

  };

  // $ionicModal.fromTemplateUrl('RNPartA.html', {
  //   scope: this,
  //   animation: 'slide-in-up'
  // }).then(function (modal) {
  //   // this.RNPartAaction = modal;
  // });




  insertRelative() {
    debugger
    // this.relativeList=[];
    // this.rel.name = this.data1.name;
    // this.rel.mobile = this.data1.leadMobile;
    // this.rel.age = this.data1.age;
    //  this.relativeList.push(this.rel);

    //  console.log(this.relativeList)
    // this.showspin();
    if (this.data1.name == undefined) {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Name");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Name</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var name = this.data1.name;
    }

    if (this.data1.leadMobile == undefined) {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Mobile No");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Mobile No</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var leadmobile = this.data1.leadMobile;
    }

    if (this.data1.age == undefined) {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Age");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Age</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var age = this.data1.age;
    }

    if (this.data1.docAttach == undefined) {
      var docAttach = 'N';
    } else {
      docAttach = this.data1.docAttach;
    }
    var staus = 'A';
    var mode = 'Insert';
    var rowid = null
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];

    this.apiService.saveleadcust(branchid, userid, this.custID, name, leadmobile, age, docAttach, staus, mode, rowid).then(response => {
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      this.alertService.presentAlert('Success',"Saved Successfully");
      // var alertPopup = $ionicPopup.alert({
      //   title: 'Success',
      //   template: 'Saved Successfully',
      //   onTap: function (e) {
      //   }
      // });
      this.getRelative();
      this.data1 = {};
    })
  }

  getRelative() {
    // this.relativeList = {};
    // this.showspin();
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];

    this.apiService.getleadcust(this.custID, this.customerType).then(response => {
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      res = JSON.parse(res);
      res = JSON.parse(res);
      this.relativeList = res;
      this.relativeList = this.relativeList.Table;
    })

  }

  deleteLead(item) {
    // this.showspin();

    var name = item.NAME;
    var leadmobile = item.MOBILE;
    var age = item.AGE;
    var docAttach = item.DOC;
    var staus = 'I';
    var mode = 'Delete';
    var rowid = item.Row_Id;
    var custId = item.Customer_Id;
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];

    this.apiService.saveleadcust(branchid, userid, custId, name, leadmobile, age, docAttach, staus, mode, rowid).then(response => {
      var res = JSON.stringify(response.data);
      this.alertService.presentAlert('Success',"Deleted Successfully");
      // var alertPopup = $ionicPopup.alert({
      //   title: 'Success',
      //   template: 'Deleted Successfully',
      //   onTap: function (e) {
      //   }


      // });
      this.getRelative();
      // alertPopup.then(function (res) {
      //   this.getRelative();
      // });
    })


  }


  calendarEntrySave() {
    // this.showspin();
    // this.updateScreen = false;
    console.log(this.custID);
    var userid = window.localStorage['userID'];;
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    var CustomerID = this.custID;
    if (this.data.facility == undefined) {
      var loanreq = 'N';
      var loantype = null;
    } else {
      var loanreq = 'Y';
      var loantype = this.data.facility;
    }
    if (this.data.amount == undefined) {
      var loanamount = 0;
    } else {
      loanamount = this.data.amount;
    }

    if (this.data.remarks == undefined) {
      var remarks = null;
    } else {
      var remarks = this.data.remarks;
    }
debugger
    if (this.data.diarygiven == undefined || this.data.diarygiven == "") {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the No of Diary Given");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Diary Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var diarygiven = this.data.diarygiven;
    }
    debugger
    if (this.data.mangementBroch == undefined) {
      // this.hidespin();
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Diary Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // return false;
      var managementbrochure = 'N';
    } else {
      var managementbrochure = 'Y';
    }
    debugger
    if (this.data.calendargiven == undefined || this.data.calendargiven == "") {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the No of Calendar Given");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Calendar Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var calendargiven = this.data.calendargiven;
    }
    debugger
    if (this.data.paymentBroch == undefined) {
      // this.hidespin();
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the No of Diary Given</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      // return false;
      var paymentBrochure = 'N';
    } else {
      var paymentBrochure = 'Y';
    }

    if (this.data.CustFeedback == undefined || this.data.CustFeedback == "") {
      // this.hidespin();
      this.alertService.presentAlert('Warning',"Enter the Remarks");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Remarks</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    } else {
      var CustFeedback = this.data.CustFeedback;
    }

    var manageUser = 0;
debugger
    this.apiService.calendarDiaryEntry(branchid, userid, userType, CustomerID, this.data.mobileNo, this.data.emailId, this.data.panNo, this.data.netBanking, this.data.mobileBanking, this.data.debit, this.data.aadhar, this.FiYear, managementbrochure, paymentBrochure, manageUser).then(response => {
     debugger
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      res = JSON.parse(res);
      res = JSON.parse(res);
      // res = JSON.parse(res);
      res = res;
      // res = response.replace('-','');
      debugger
      this.apiService.calendarDiaryEntryData(CustomerID, this.data.creditCard, this.data.mutual, this.data.insur, this.data.health, this.data.group, this.data.pos, this.data.bharat, this.data.fastag, this.data.gold, this.data.demat, this.data.asba, this.data.fd, this.data.locker,loanreq, loantype, loanamount, remarks, diarygiven, calendargiven, CustFeedback)
      .then((response:any) =>{
        console.log(response.data);
        // this.hidespin();
        debugger
        response = JSON.parse(JSON.parse(response.data));
        if(response == 'S'){
          this.alertService.presentAlert('Success',"Saved Successfully");
          this.data = {};
          this.data1 = {};
          this.relativeList = {};
          this.updateScreen = false;
          this.getAssignedlist()
         
        
            
     
      }
      }) 
     
  
     
    })
  }

  sendSms(type) {
    // this.showspin();
    var userid = window.localStorage['userID'];
    var branchid = window.localStorage['branchID'];
    var userType = window.localStorage['userType'];
    if (type == 1) {
      var mode = 'SGB';
    } else if (type == 2) {
      mode = 'Demat';
    } else {
      mode = 'VKYC';
    }
    console.log(this.custMobile)
    this.apiService.DCDSmsSend(userid, this.custMobile, mode).then(response => {
      var res = JSON.stringify(response.data);
      res = JSON.parse(res);
      if (res == 'SMS Sent') {
        // var alertPopup = $ionicPopup.alert({
        //   title: 'Success',
        //   template: 'SMS Sent Successfully',
        //   onTap: function (e) {
        //   }
        // });
        this.alertService.presentAlert('Success',"SMS Sent Successfully");
        // alertPopup.then(function (res) {
        // });
      } else {
        // var alertPopup = $ionicPopup.alert({
        //   title: 'Alert',
        //   template: 'Mobile Number Not Updated',
        //   onTap: function (e) {
        //   }


        // });
        this.alertService.presentAlert('Alert',"Mobile Number Not Updated");
        // alertPopup.then(function (res) {
        // });
      }

    })
  }

  sendSmsVkyc(type) {
    // this.showspin();
    var userid = window.localStorage['userID'];
    if (this.data1.leadMobile == undefined) {
      this.alertService.presentAlert('Warning',"Enter the Lead Customer mobile Number");
      // var myPopup = $ionicPopup.show({
      //   template: '<center>Enter the Lead Customer mobile Number</center>',
      //   title: 'Alert',
      //   scope: this,
      //   buttons: [{
      //     text: 'OK',
      //     type: 'button button-clear button-assertive'
      //   }]
      // });
      return false;
    }
    var mode = 'VKYC';
    console.log(this.custMobile)
    this.apiService.DCDSmsSend(userid, this.data1.leadMobile, mode).then(response => {
      var res = JSON.parse(response.data);
      res = JSON.parse(res);
      if (res == 'SMS Sent') {
        this.alertService.presentAlert('Success',"SMS Sent Successfully");
        // var alertPopup = $ionicPopup.alert({
        //   title: 'Success',
        //   template: 'SMS Sent Successfully',
        //   onTap: function (e) {
        //   }
        // });

        // alertPopup.then(function (res) {
        // });
      }
    })

  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
}else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
    // this.router.navigateByUrl('/myplanner');
  }
}
