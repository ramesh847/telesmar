import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import { ExpressleadmodalPage } from '../modal/expressleadmodal/expressleadmodal.page';
import { ModalController } from '@ionic/angular';
import { EndcallmodalPage } from '../modal/expressleadmodal/endcallmodal/endcallmodal.page';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ToastServiceService } from '../service/toast-service.service';
import { AlertServiceService } from '../service/alert-service.service';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-express-leads',
  templateUrl: './express-leads.page.html',
  styleUrls: ['./express-leads.page.scss'],
  providers:[DatePipe,Idle]
})
export class ExpressLeadsPage implements OnInit {
  expressleadscreenlist: any = [];
  ExpresleadCount: any;
  leaditems: any;
  search:any={};
  customerName:any;
  leadType:any;
  mobile:any;
  accessResp: any;
  ClickAccess:boolean=false
  idleState: string;
  getnummmm:any
  constructor(public router:Router,private loader:ToastServiceService,
    private modalController:ModalController,private Apiservice:ApiServiceService,
    private datepipe:DatePipe,public alertservice:AlertServiceService,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
      this.idle.setIdle(5);
      // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
      this.idle.setTimeout(15*60);
      // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
      this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  
      this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
      this.idle.onTimeout.subscribe(() => {
        // this.idleState = "Timed out!";
        // this.timedOut = true;
        this.router.navigate(['sessionout'])
      });
      this.idle.onIdleStart.subscribe(
        () => (this.idleState = "")
      );
      this.idle.onTimeoutWarning.subscribe(
        countdown =>
          // (this.idleState = countdown.toString() )
          {
            let idleState = countdown
            let minutes = Math.floor((idleState)/ 60);
            let extraSeconds = (idleState) % 60;
           let minutes1 = minutes < 10 ? "0" + minutes : minutes;
           let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
           this.idleState=minutes1 +':'+ extraSeconds1
           console.log(this.idleState)
          }
      ); }

  ngOnInit() {
    
    this.display();
    this.leadtype();
    this.clickCallAccess()
    // this.reset()
  }
  clicknumberstar(num:any){
    debugger
   this.getnummmm= this.Apiservice.firstfivexxxx(num)
  }
reset(){
  this.idle.watch()
}
  followupleadRefresh(event) {
    debugger
    this.display()
    setTimeout(() => {
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  };

  leadtype(){
    debugger
    // this.loader.presentLoading('')
    this.Apiservice.getBusinessLeadType()
    .then((response:any) =>{
      debugger
      console.log(response);
      // this.loader.dismissLoading()
      response = JSON.parse(response.data);
     
     // console.log("---$scope.expressLeadscreen" );
    this.leaditems = JSON.parse(response)
      // console.log($scope.leaditems)


    })
   
  }
  searchexpressLead(leadType, customerName, mobile) {
    // $scope.showspin();
    debugger
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    var campID = ' ';
    var name = ' ';
   
    if(leadType == "" ||leadType == "undefined"||leadType == undefined){
      leadType= " ";
    }
    if(customerName == ""||customerName == "undefined"||customerName == undefined){
      customerName= " ";
    }
    if(mobile == ""||mobile == "undefined"||mobile == undefined){
      mobile= " ";
    }
    this.loader.presentLoading('')
    this.Apiservice.expressLeadscreen(customerName, branchid, leadType, mobile, userid)
      .then((response:any)=> {
        debugger
        this.loader.dismissLoading()
        // $scope.hidespin();
        console.log(response);
        response = JSON.parse(response.data);
        this.expressleadscreenlist = JSON.parse(response);
        this.ExpresleadCount = this.expressleadscreenlist.length;
        // console.log($scope.expressleadscreenlist)


      })
     
  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
}else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
  }
  clickCallAccess(){
    debugger
    var userid = window.localStorage['userID'];
    this.Apiservice.AccesstoClick(userid)
    .then((response:any)=> {
      debugger
      // console.log(response)
      this.accessResp= JSON.parse(JSON.parse(response.data))
      // $scope.hidespin($ionicLoading);
      if(this.accessResp == 'A'){
        // console.log($scope.accessResp);
        this.ClickAccess =true;
      }else{
        this.ClickAccess =false;
      }
     
    })
  }
  callNumber(items){
    debugger
    this.Apiservice.expressleadarray=[]
    this.Apiservice.expressleadarray.push(items)
    this.router.navigateByUrl('/expressleadcallconnect')
  }
display() {
    // this.showspin();
    var branchid = window.localStorage['branchID'];
  var userid = window.localStorage['userID'];
  var campID = ' ';
  var name = ' ';
  var mobile = ' ';
  this.loader.presentLoading('')
    this.Apiservice.expressLeadscreen(name, branchid, campID, mobile, userid).then((response:any)=> {
        // this.hidespin();
        
        this.loader.dismissLoading()
        console.log(response);
        var result = response.data;
        result = JSON.parse(result);
        result = JSON.parse(result);
        console.log("---this.expressLeadscreen",result );
        this.expressleadscreenlist = result;
        console.log("---resulScreen",this.expressleadscreenlist );

        this.ExpresleadCount = this.expressleadscreenlist.length;
        console.log(this.expressleadscreenlist)


      },err=>{
        this.loader.dismissLoading()
        this.alertservice.presentAlert("Error",err.status)
      })
      // .error(function(response) {
      //   this.hidespin();
      //   console.log(response);
      // });
  }
  async customerActionModal(item) {
    this.Apiservice.expressleadarray=[]
    this.Apiservice.expressleadarray.push(item,{close:"expresslead"})
    this.router.navigateByUrl('/expressleadmodal')
    // const modal = await this.modalController.create({
    // component: ExpressleadmodalPage,
    // componentProps: { Data: item }
    // });
    // return await modal.present();
   }
}
