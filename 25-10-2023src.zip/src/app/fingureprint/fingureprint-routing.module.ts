import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FingureprintPage } from './fingureprint.page';

const routes: Routes = [
  {
    path: '',
    component: FingureprintPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FingureprintPageRoutingModule {}
