import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { AlertServiceService } from '../service/alert-service.service';

@Component({
  selector: 'app-fingureprint',
  templateUrl: './fingureprint.page.html',
  styleUrls: ['./fingureprint.page.scss'],
})
export class FingureprintPage implements OnInit {

  constructor(private faio: FingerprintAIO,private alertservice:AlertServiceService,private router:Router
    ) { }

  ngOnInit() {
  }
  showFingeerprintAuthentication(){
    debugger
    this.showFingerprintAuthDlg()
  }
  public showFingerprintAuthDlg() {
debugger
    this.faio.isAvailable().then((result: any) => {
      debugger
      console.log(result)

      this.faio.show({
        cancelButtonTitle: 'Cancel',
        description: "",
        disableBackup: true,
        title: '',
        fallbackButtonTitle: 'FB Back Button',
        subtitle: ''
      })
        .then((result: any) => {
          debugger
          console.log(result)
          //biometric_success
          this.alertservice.presentAlert("",result)
          // alert("Successfully Authenticated!")
        })
        .catch((error: any) => {
          debugger
          console.log(error.message)
          // when cancel button click->BIOMETRIC_DISMISSED
          this.alertservice.presentAlert("",error.message)
          // alert("Match not found!")
        });

    })
      .catch((error: any) => {
        debugger
        // biomatric not enroled
        this.alertservice.presentAlert("",error.message)
        console.log(error.message)
      });
  }

  cancel(){
    debugger
    this.router.navigate(['notification']);
  }

}
