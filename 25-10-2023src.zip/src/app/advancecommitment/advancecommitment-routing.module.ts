import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdvancecommitmentPage } from './advancecommitment.page';

const routes: Routes = [
  {
    path: '',
    component: AdvancecommitmentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdvancecommitmentPageRoutingModule {}
