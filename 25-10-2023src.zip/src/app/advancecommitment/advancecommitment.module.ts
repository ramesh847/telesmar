import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdvancecommitmentPageRoutingModule } from './advancecommitment-routing.module';

import { AdvancecommitmentPage } from './advancecommitment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdvancecommitmentPageRoutingModule
  ],
  declarations: [AdvancecommitmentPage]
})
export class AdvancecommitmentPageModule {}
