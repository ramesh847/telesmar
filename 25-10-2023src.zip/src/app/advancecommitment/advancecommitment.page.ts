import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Idle,DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { AlertServiceService } from '../service/alert-service.service';
import { ApiServiceService } from '../service/api-service.service';

@Component({
  selector: 'app-advancecommitment',
  templateUrl: './advancecommitment.page.html',
  styleUrls: ['./advancecommitment.page.scss'],
  providers:[Idle]
})
export class AdvancecommitmentPage implements OnInit {
  advance:any={}
  userid: any;
  branchid: any;
  commitdate: any;
  postsenddate: any;
  issave:boolean
  datearray: any[]=[];
  splitdate: string;
  datevalidation: any;
  isdatewise:boolean=false
  rduserid: any;
  idleState: string;
  constructor(private router:Router,private alertService: AlertServiceService, 
    private service:ApiServiceService,public idle: Idle) { 
     // sets an idle timeout of 5 seconds, for testing purposes.
     this.idle.setIdle(5);
     // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
     this.idle.setTimeout(15*60);
     // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
     this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
 
     this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
     this.idle.onTimeout.subscribe(() => {
       // this.idleState = "Timed out!";
       // this.timedOut = true;
       this.router.navigate(['sessionout'])
     });
     this.idle.onIdleStart.subscribe(
       () => (this.idleState = "")
     );
     this.idle.onTimeoutWarning.subscribe(
       countdown =>
       {
        let idleState = countdown
        let minutes = Math.floor((idleState)/ 60);
        let extraSeconds = (idleState) % 60;
       let minutes1 = minutes < 10 ? "0" + minutes : minutes;
       let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
       this.idleState=minutes1 +':'+ extraSeconds1
       console.log(this.idleState)
       }
     );
  }

  ngOnInit() {
    debugger
    this.advance={}
    this.commitdate=''
    this.userid= window.localStorage['userID']
    this.branchid= window.localStorage['branchID']
    let bbid={
      branchid:this.branchid
    }
this.service.Saverdmuserid(bbid).then((res:any)=>{
  debugger
 this.rduserid= JSON.parse(res.data)[0].userid
})

    this.service.getrcommitmentdate().then((res:any)=>{
      debugger
for(let i=0;i<JSON.parse(res.data).length;i++){
  this.datearray.push(JSON.parse(res.data)[i].date)
}

      // this.datearray=JSON.parse(res.data).date
//     this.commitdate =JSON.parse(res.data)[0].cdate.slice(0,10)
// this.postsenddate=JSON.parse(res.data)[0].cdate
    })
    // this.reset()
  }
  reset() {
    this.idle.watch();
    // this.idleState = "Started.";
    //this.timedOut = false;
  }

getplan(date){
  debugger
  
if(date == '' || date == null || date == undefined ){
  this.issave=false
  this.advance={}
  this.isdatewise=false
}
else{
  // this.advance={}
  var vals = date.split('-');
  var day = vals[0];
  var month = vals[1];
  var year = vals[2];
this.splitdate=year+"-"+month+"-"+day
var xyzzz={
//  userid :this.userid,
           branchid :this.branchid,
           commentdate :this.splitdate+"T00:00:00"
}
  this.service.bmdatefilter(xyzzz).then((res:any)=>{
    debugger
    if(res.data == "No Record Found"){
      this.advance={}
      this.issave=false
      this.isdatewise=false
    }
//     this.datevalidation=JSON.parse(res.data).Table.length
//     if(this.datevalidation == '0'){
      
// this.issave=false
//     }
    else{
      this.advance={}
      this.issave=true
      this.isdatewise=true
      // this.alertService.presentAlert("",this.datevalidation)
      this.advance.count=JSON.parse(res.data).Table[0].New_customer_count
this.advance.amount=JSON.parse(res.data).Table[0].New_customer_amount
this.advance.ecount=JSON.parse(res.data).Table[0].Existing_customer_count
this.advance.eamount=JSON.parse(res.data).Table[0].Existing_customer_amount
this.advance.tcount=JSON.parse(res.data).Table[0].Total_Login_count
this.advance.tamount=JSON.parse(res.data).Table[0].Total_Login_amount
this.advance.ccount=JSON.parse(res.data).Table[0].CLOC_commit_count
this.advance.camount=JSON.parse(res.data).Table[0].CLOC_commit_amount
this.advance.availcount=JSON.parse(res.data).Table[0].availment_commit_count
this.advance.availamount=JSON.parse(res.data).Table[0].availment_commit_amount
    }
  })
}
 
}

  goToMyplannerPage(){
    this.router.navigate(['/newsummary'])
  }
  countmethod(){
    debugger
    if(this.advance.count=='' || this.advance.count==null || this.advance.count == undefined){
      // this.alertService.presentAlert("","Please Enter New Customer Count")
      this.advance.tcount=''

    }else if(this.advance.ecount=='' || this.advance.ecount==null || this.advance.ecount == undefined){
      this.advance.tcount=''
      // this.alertService.presentAlert("","Please Enter Existing Customer Count")
    }else{
      this.advance.tcount=parseFloat(this.advance.count)+parseFloat(this.advance.ecount)
    }
  }
  amountmethod(){
    debugger
    if(this.advance.amount=='' || this.advance.amount==null || this.advance.amount == undefined){
      // this.alertService.presentAlert("","Please Enter New Customer Amount")
      this.advance.tamount=''
    }else if(this.advance.eamount=='' || this.advance.eamount==null || this.advance.eamount == undefined){
      // this.alertService.presentAlert("","Please Enter Existing Customer Amount")
      this.advance.tamount=''
    }else{
      this.advance.tamount=parseFloat(this.advance.amount)+parseFloat(this.advance.eamount)
    }
  }

  countChange(event) {
    debugger
    event.target.value = event.target.value.replace(/[^0-9]*/g, '');
    console.log(event.target.value)
}

  advancesave(){
    debugger
if(this.commitdate=='' || this.commitdate==null || this.commitdate==undefined){
  this.alertService.presentAlert("","Please Select Commitment Date")
}else

    if(this.advance.count=='' || this.advance.count==null || this.advance.count == undefined){
      this.alertService.presentAlert("","Please Enter New Customer Count")

    }else if(this.advance.amount=='' || this.advance.amount==null || this.advance.amount == undefined){
      this.alertService.presentAlert("","Please Enter New Customer amount")
    } else if(this.advance.ecount=='' || this.advance.ecount==null || this.advance.ecount == undefined){
      this.alertService.presentAlert("","Please Enter Existing Customer Count")
    } else if(this.advance.eamount=='' || this.advance.eamount==null || this.advance.eamount == undefined){
      this.alertService.presentAlert("","Please Enter Existing Customer Amount")
    } else if(this.advance.ccount=='' || this.advance.ccount==null || this.advance.ccount == undefined){
      this.alertService.presentAlert("","Please Enter CLOC Commitment Count")
    } else if(this.advance.camount=='' || this.advance.camount==null || this.advance.camount == undefined){
      this.alertService.presentAlert("","Please Enter CLOC Commitment Amount")
    } else if(this.advance.availcount=='' || this.advance.availcount==null || this.advance.availcount == undefined){
      this.alertService.presentAlert("","Please Enter Availment Commitment Count")
    } else if(this.advance.availamount=='' || this.advance.availamount==null || this.advance.availamount == undefined){
      this.alertService.presentAlert("","Please Enter Availment Commitment Amount")
    } else{
var body={
  userid:this.userid,
  branchid:this.branchid,
  newcount:this.advance.count,
  newamount:this.advance.amount,
  excount:this.advance.ecount,
  examount:this.advance.eamount,
  totalcount:this.advance.tcount,
  totalamount:this.advance.tamount,
  cloccount:this.advance.ccount,
  clocamount:this.advance.camount,
  availcount:this.advance.availcount,
  availamount:this.advance.availamount,
  commentdate:this.splitdate+"T00:00:00",
  rdmuserid :this.rduserid
}
this.issave=true
this.service.advancecommitment(body).then((res:any)=>{
  debugger
//   this.issave=false
//  if( JSON.parse(res.data)=="Successfully inserted"){
//    this.issave=false
//    this.advance={}
//    this.commitdate=''
//    this.alertService.presentAlert("","Saved Successfully")
//  }else{
  this.issave=false
  this.advance={}
  this.commitdate=''
   this.alertService.presentAlert("",JSON.parse(res.data))
//  }
},err=>{
  this.issave=false
  this.advance={}
  this.commitdate=''
  this.alertService.presentAlert("","Please Try After Some Time")
})
    }
  }
}
