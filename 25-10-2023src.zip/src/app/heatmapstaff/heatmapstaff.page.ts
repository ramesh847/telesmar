import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from '../service/api-service.service';
import {Router } from '@angular/router';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
@Component({
  selector: 'app-heatmapstaff',
  templateUrl: './heatmapstaff.page.html',
  styleUrls: ['./heatmapstaff.page.scss'],
  providers: [ApiServiceService,Idle]
})
export class HeatmapstaffPage implements OnInit {
  staffmapdata: any;
  enddate: any;
  startdate: any;
  table: boolean = false;
  card: boolean = true;
  staffmapdatalength: any;
  idleState: string;

  constructor(private apiService: ApiServiceService,private router:Router,private idle:Idle) {// sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(15*60);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => (this.idleState = ""));
    this.idle.onTimeout.subscribe(() => {
      // this.idleState = "Timed out!";
      // this.timedOut = true;
      this.router.navigate(['sessionout'])
    });
    this.idle.onIdleStart.subscribe(
      () => (this.idleState = "")
    );
    this.idle.onTimeoutWarning.subscribe(
      countdown =>
        // (this.idleState = countdown.toString() )
        {
          let idleState = countdown
          let minutes = Math.floor((idleState)/ 60);
          let extraSeconds = (idleState) % 60;
         let minutes1 = minutes < 10 ? "0" + minutes : minutes;
         let extraSeconds1 = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
         this.idleState=minutes1 +':'+ extraSeconds1
         console.log(this.idleState)
        }
    ); }

  ngOnInit() {
    debugger
    var branchid = window.localStorage['branchID'];
    var userid = window.localStorage['userID'];
    this.apiService.getstaffheatmap(userid, branchid).then(res => {
      debugger
      var response = JSON.stringify(res.data);
      response = JSON.parse(response);
      response = JSON.parse(response);
      response = JSON.parse(response);
      this.staffmapdata = response;
      this.staffmapdatalength=this.staffmapdata.length
      console.log( this.staffmapdata)
    });

    this.apiService.AssigneDdate().then(response => {
      debugger
      var resp = JSON.stringify(response.data);
      resp = JSON.parse(resp);
      resp = JSON.parse(resp);
      resp = JSON.parse(resp);
      console.log(resp)
      this.enddate = resp[0]['EndDate'];
      console.log(this.enddate)
      this.startdate = resp[0]['StartDate'];
      console.log(this.startdate)
    })
// this.reset()
  }
  reset(){
    this.idle.watch()
  }
  tableshow() {
    debugger
    this.table = true;
    this.card = false;
  }
  cardshow() {
    debugger
    this.table = false;
    this.card = true;
  }
  goToMyplannerPage() {
    if (window.localStorage['userType'] == 14 || window.localStorage['userType'] == 26) {
      this.router.navigate(['/regionsummary']);
}else
    if(window.localStorage['userType']=='17')
  { this.router.navigate(['/newsummary']);}else{
    this.router.navigateByUrl('/myplanner');
  }
    // this.router.navigateByUrl('/myplanner');
  } 
}




