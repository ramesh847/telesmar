import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HeatmapstaffPageRoutingModule } from './heatmapstaff-routing.module';

import { HeatmapstaffPage } from './heatmapstaff.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HeatmapstaffPageRoutingModule
  ],
  declarations: [HeatmapstaffPage],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HeatmapstaffPageModule {}
